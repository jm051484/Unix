<!DOCTYPE html>
<?php
include('components/header.php');
include('components/bodytop.php');
?>

<div class="wrapper">

<?php
include('components/nav.php');
include("components/sidebar.php");
?>	
   <div class="content-wrapper">
    <section class="content-header">
     <h1>Register<small>Account Creation</small></h1>
      <ol class="breadcrumb">
       <li><a href="profile.php"><i class="fa fa-dashboard"></i> Home</a></li>
        <li class="active">Register</li>
       </ol>
      </section>
     <br>
     <div class="content">
      <div class="row">
      <div class="col-xs-12">
       <div class="alert bg-red alert-dismissible">
   <h5><i class="icon fa fa-exclamation-triangle"></i> Sorry youre out of credits, Please contact your Administrator to recharge</h5>
      <a href="profile.php" class="badge badge-primary" >Go back</a>
   </div>
   </div>
   </div>
   </div>
   </div>
   
<?php 

include("components/js.php");

?>

<script>

$("#profile_form").submit(function(event){

	event.preventDefault();

	remove_alert_bg();

	$('#error-alert').addClass("bg-primary");

	$('#error-alert').fadeIn();

	$('#alert-message').text(" Please wait...");

		$.ajax({

			url: "app/account/create_account.php", data: $('#profile_form').serialize(), type: "POST",  dataType: 'json',

			success: function (result) {

						console.log(result.status +- " " +- result.message);

						if (result.status!=1) { 

							remove_alert_bg();

							$('#error-alert').addClass("alert-danger");

							$('#alert-message').text(result.message);

							setTimeout(function () { $('#error-alert').fadeOut()}, 3000);

						}else{

							remove_alert_bg();

							$('#error-alert').addClass("alert-success");

							$('#alert-message').text(result.message);

							//setTimeout(function () { window.location.assign("index.php");}, 1000);

							setTimeout(function () { $('#error-alert').fadeOut()}, 3000);

							$("#profile_form")[0].reset();

						}

					}

		});

		

	console.log('clicked');

});



function remove_alert_bg(){

	$('#error-alert').removeClass("alert-success");

	$('#error-alert').removeClass("alert-primary");

	$('#error-alert').removeClass("alert-danger");

}	





</script>

<?php
	include('components/footer.php');
?>
<div class="control-sidebar-bg"></div>
</div>
</body>



</html>
   
   
   
   