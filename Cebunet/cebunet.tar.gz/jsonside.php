<!DOCTYPE html>
<html>

<?php
include('components/header.php');
include('components/bodytop.php');
?>
    <div class="wrapper">

        <?php

        header("Cache-Control: no-store, no-cache, must-revalidate, max-age=0");
        header("Cache-Control: post-check=0, pre-check=0", false);
        header("Pragma: no-cache");
        ?>


<?php
include("components/nav.php");
include("components/sidebar.php");

$myFile = "manifest.json";

if(!isset($_SESSION['user'])){
    header("location: login.php");
}
$get_id=0;
if(isset($_GET['user'])){
    $get_id = $db -> escape($_GET['user']);
    if($db -> select("SELECT `user_id` FROM `users` WHERE `user_id`=$get_id") == ""){
        header("location: profile.php");
    }
}else{
    $get_id = $current_uid;
}

$profile_info = $db -> select_row("SELECT * FROM `users` WHERE `user_id`=$get_id");
//print_r($profile_info);
$dur = $db -> calc_time($profile_info[0]['duration']);
//print_r($dur);
$duration = $dur['days'] . " day(s), " . $dur['hours'] . " hour(s) and " . $dur['minutes'] . " minute(s)";

$status = $db -> select_row("SELECT is_active FROM `users` WHERE `user_id`=$get_id");


$date = date_create(date('Y-m-d H:i:s'));
date_add($date, date_interval_create_from_date_string($profile_info[0]['duration'].' seconds'));
$expiration = date_format($date, 'm/d')."/".substr(date_format($date, 'Y'),2,2);

$premium_status="Active";
if($profile_info[0]['duration']==0){
    $premium_status="Inactive";
    $expiration="--";
}

$con_status="Connected";
if($profile_info[0]['is_active']==1){
    $con_status="Disconnected";
}

$user_rank="";
if($profile_info[0]['is_reseller']==1){
    $user_rank="Reseller";
}elseif($profile_info[0]['is_reseller']==3){
    $user_rank="Sub Admin";
}elseif($profile_info[0]['is_reseller']==2){
    $user_rank="SubRS";
}else{
    $user_rank="Client";
}
if($get_id==1 || $profile_info[0]['is_admin']=='Admin'){
    $user_rank="Admin";
}


?>

<div class="content-wrapper">
    <section class="content-header">
        <h1>
            Json Editor
            <small>Edit Json for Online Update</small>
        </h1>
        <ol class="breadcrumb">
            <li><a href="#"><i class="fa fa-dashboard"></i> Home</a></li>
            <li class="active">JsonEditor</li>
        </ol>
    </section>

    <!-- Main content -->
    <section class="content">
        <!-- Info boxes -->
        <?php
        if($_SERVER['REQUEST_METHOD'] == 'POST' && !empty($_POST['jsontext'] || !empty($_POST['androidjsontext'])))  { ?>
            <div class="row">
                <div class="col-xs-12" id="message">
                    <div class="alert alert-info alert-dismissible">
                        <button type="button" class="close" data-dismiss="alert" aria-hidden="true">×</button>
                        File Successfully Saved!
                    </div>
                </div>
            </div>
            <?php
        }
        ?>
        <!-- Info boxes -->



        <div class="row">
            <div class="col-xs-12">
                <!-- Custom Tabs -->
                <div class="nav-tabs-custom">
                    <ul class="nav nav-tabs">
                        <li class="active"><a href="#tab_1" data-toggle="tab">PC Json Editor</a></li>
                        <li><a href="#tab_2" data-toggle="tab">Android Json Editor</a></li>
                        <li class="pull-right"><a href="#" class="text-muted"><i class="fa fa-gear"></i></a></li>
                    </ul>
                    <div class="tab-content">
                        <div class="tab-pane active" id="tab_1">
                            <div class="box-body">
                                <div class="col-xs-12">
                                    <form role="form" action="jsonside.php" method="POST">

                                        <div class="form-group">
                                            <label>PC Json Editor</label>
                                            <textarea name="jsontext" type="text" class="form-control" rows="5" style="resize:none; height:25em;">
                                        <?php

                                        $file = fopen("gui/pc-updates/data.json", "r") or die("Unable to open file!");
                                        $a = fread($file,filesize("gui/pc-updates/data.json"));
                                        fclose($file);

                                        echo $a;


                                        ?>
                                    </textarea>

                                        </div>

                                        <div>
                                            <button value="Save data" type="submit" name="submit" class="btn btn-success pull-right" onclick="window.location.reload(true);">Save Changes</button>

                                        </div>

                                        <?php
                                        if (isset($_POST['submit'])) {
                                            $var1 = $_POST['jsontext'];
                                            $myFile2 = "gui/pc-updates/data.json";
                                            $filehandle = fopen($myFile2, "w+") or die("Can't open file.");
                                            fwrite($filehandle, $var1);
                                            fclose($filehandle);



                                        }
                                        ?>



                                </div>
                            </div>
                        </div>
                        <!-- /.tab-pane -->
                        <div class="tab-pane" id="tab_2">
                            <div class="box-body">
                                <div class="col-xs-12">
                                    <form role="form" action="jsonside.php" method="POST">

                                        <div class="form-group">
                                            <label>Android Json Editor</label>
                                            <textarea name="androidjsontext" type="text" class="form-control" rows="5" style="resize:none; height:25em;">
                                        <?php

                                        $afile = 'android-updates.json';
                                        $aorig = file_get_contents($afile);
                                        $aa = htmlentities($aorig);

                                        echo $aa;


                                        ?>
                                    </textarea>

                                        </div>

                                        <div>
                                            <button value="Save data" type="submit" name="submit" class="btn btn-success pull-right">Save Changes</button>

                                        </div>

                                        <?php
                                        if (isset($_POST['submit'])) {
                                            $avar1 = $_POST['androidjsontext'];
                                            $amyFile2 = "android-updates.json";
                                            $afilehandle = fopen($amyFile2, "w+") or die("Can't open file.");
                                            fwrite($afilehandle, $avar1);
                                            fclose($afilehandle);
                                        }
                                        ?>



                                </div>
                            </div>
                        </div>
                        <!-- /.tab-pane -->
                        <!-- /.tab-pane -->
                    </div>
                    <!-- /.tab-content -->
                </div>
                <!-- nav-tabs-custom -->
            </div>
            <!-- /.col -->
        </div>
<!-- /.row -->



</div>	<!--/.main-->

<?php
include('components/footer.php');
include("components/js.php");
?>
<div class="control-sidebar-bg"></div>
</div>
</body>

</html>