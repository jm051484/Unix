<!DOCTYPE html>

<html>



<?php

include('components/header.php');
include('components/bodytop.php');
?>


<div class="wrapper">
<?php



if(!isset($_SESSION['user'])){

	header("location: login.php");

}

$message="";

if($_SESSION['user']['rank']=="Admin"){

	if(isset($_POST['submit'])){

		foreach($_POST as $key => $value){

			$db -> sql_query("UPDATE `settings` SET `value`='". $db -> escape(($value)) ."' WHERE `name`='".$db -> escape($key)."'");

			//echo($data);

			//echo $key .":".$value;

		}

		$message="<div class='alert bg-success'role='alert' id='error-alert'>

									<span class='glyphicon glyphicon-exclamation-sign'></span><span id='alert-message2'> Site Updated</span></a>

								</div>";

	}

}else{

	header("location: index.php");

}

$variable= $db -> site_settings();



include('components/nav.php');

include("components/sidebar.php");

//$current_uid= $_SESSION['user']['id'];







?>	

<style>

a, a:hover, a:focus{

	color: <?php echo $variable['link_color'];?>;

}

.navbar-brand span {

    color: <?php echo $variable['brand_color'];?> !important;

}

</style>

	

	<div class="content-wrapper">
        <div class="content">
        <section class="content-header">
            <h1>
                Settings
                <small>Site Config</small>
            </h1>
            <ol class="breadcrumb">
                <li><a href="#"><i class="fa fa-dashboard"></i> Home</a></li>
                <li class="active">Site config</li>
            </ol>
        </section>

		
        <br>

		<div class="row">

			<div class="col-lg-12">

				<div class="box">

					<div class="box-header">Variables Configuration</div>

					<div class="box-body">

						<div class="col-md-12">

							<form id="site_config" role="form" method="POST">

								<?php

								$get_variable = $db -> return_result("SELECT * FROM `settings`");

								foreach($get_variable as $setting){

									echo "<div class='form-group'>";

									echo "	<label>{$setting['title']}</label>";

									echo "	<input class='form-control' name=\"".htmlspecialchars($setting['name'])."\" placeholder=\"".($setting['placeholder'])."\" value=\"".htmlspecialchars($setting['value'])."\">";

									echo "</div>";

								}

								?>

								<input type="submit" name="submit" class="btn btn-primary btn-block"></input>

						<br />

						<br />

						<?php echo $message;?>

						</div>

					</div>

				</div>

			</div><!-- /.col-->

		</div><!-- /.row -->

		

		
        </div>
		

	</div>	<!--/.main-->



<?php 

include("components/js.php");

?>

<?php
include('components/footer.php');
?>
    <div class="control-sidebar-bg"></div>
</div>
</body>



</html>

