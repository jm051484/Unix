<?php

//ini_set('memory_limit','16M');
//ini_set('max_execution_time', 300);
ob_start();

session_start();

include_once('cfg.php');

$db = new db();

$variable = $db -> site_settings();

ob_flush();

ob_end_flush();
