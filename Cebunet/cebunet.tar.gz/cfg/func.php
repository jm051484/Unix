<?php

class functions{

	/**

     * Query the database

     *

     * @param $query The query string

     * @return mixed The result of the mysqli::query() function

     */

    public function sql_query($query) {

        // Connect to the database

        $connection = $this -> connect();



        // Query the database

        $result = $connection -> query($query);



        return $result;

    }



    /**

     * Fetch rows from the database (SELECT query)

     *

     * @param $query The query string

     * @return output

     */

    public function select($query) {

        $result = $this -> sql_query($query);

        if($result === false) {

            return false;

        }

		$row = $this -> index_arr_values($result -> fetch_assoc());

        return $row[0];

    }

	

	/**

     * Fetch rows from the database (SELECT query)

     *

     * @param $query The query string

     * @return bool False on failure / array Database rows on success

     */

    public function select_row($query) {

        $rows = array();

        $result = $this -> sql_query($query);

        if($result === false) {

            return false;

        }

        while ($row = $result -> fetch_assoc()) {

            $rows[] = $row;

        }

        return $rows;

    }

	

	public function return_result($query){

		$result = $this -> sql_query($query);

		$output=array();

		while ($row = $result->fetch_assoc()) {

			array_push($output,$row);

		}

		return $output;

	}

    



    /**

     * Quote and escape value for use in a database query

     *

     * @param string $value The value to be quoted and escaped

     * @return string The quoted and escaped string

     */

    public function escape($value) {

        $connection = $this -> connect();

        return  $connection -> real_escape_string($value);

    }

	

	/**

	* Return the values of associative array as indexed array

	*

	*@param associative array

	*@return indexed array

	*/

	public function index_arr_values($value){

		return array_values($value);

	}

	

	/**

	* Return the keys of associative array as indexed array

	*

	*@param associative array

	*@return indexed array

	*/

	public function index_arr_keys($value){

		return array_keys($value);

	}



	/**

	Get Client's IP

	*/

	function getClientIP() {

		if (isset($_SERVER)) {

			if (isset($_SERVER["HTTP_X_FORWARDED_FOR"])){

				return $_SERVER["HTTP_X_FORWARDED_FOR"];

			}

			if (isset($_SERVER["HTTP_CLIENT_IP"])){

				return $_SERVER["HTTP_CLIENT_IP"];

			}

			return $_SERVER["REMOTE_ADDR"];

		}

		if (getenv('HTTP_X_FORWARDED_FOR')){

			return getenv('HTTP_X_FORWARDED_FOR');

		}

		if (getenv('HTTP_CLIENT_IP')){

			return getenv('HTTP_CLIENT_IP');

		}

		return getenv('REMOTE_ADDR');

	}

	

	/**

	* Set Session For User Login

	*/

	

	function setLogin($uid){

		$user_info = $this -> select_row("SELECT * FROM `users` WHERE `user_id`=$uid");

		$_SESSION['user']['id'] = $uid;

		$_SESSION['user']['user_name'] = $user_info[0]['user_name'];

		if($user_info[0]['is_reseller']==1){

		$_SESSION['user']['rank']="Reseller";

		}elseif($user_info[0]['is_reseller']==2){

			$_SESSION['user']['rank']="Sub Reseller";

					}elseif($user_info[0]['is_reseller']==3){

		$_SESSION['user']['rank']="Sub Admin";

		}elseif($user_info[0]['is_admin']==1 || $user_info[0]['user_rank']=='Admin'){

            $_SESSION['user']['rank']="Admin";

        }else{

			$_SESSION['user']['rank']="Client";

		}

		$this ->sql_query("UPDATE users SET `ipaddress`='".$this -> getClientIP()."', `lastlogin`=NOW() WHERE `user_id`='$uid'");

		

		

	}

	

	/**

	* Calculate time

	*/

	function calc_time($seconds) {

		$hours=0;

		$minutes=0;

		$days = (int)($seconds / 86400);

		$seconds -= ($days * 86400);

		if ($seconds) {

			$hours = (int)($seconds / 3600);

			$seconds -= ($hours * 3600);

		}

		if ($seconds) {

			$minutes = (int)($seconds / 60);

			$seconds -= ($minutes * 60);

		}

		$time = array('days'=>(int)$days,

				'hours'=>(int)$hours,

				'minutes'=>(int)$minutes,

				'seconds'=>(int)$seconds);

		return $time;

	}

	

	/**

	* Generate Code

	*/

	function ran_code($x) {

		$pwd="";

		$chars = "ABCDEFGHIJKLMNOPQRSTUVWXYZ0123456789";

		srand((double)microtime()*1000000);

		$i = 0;

		while ($i <= $x)

		{

			$num = rand() % 33;

			$tmp = substr($chars, $num, 1);

			$pwd = $pwd . $tmp;

			$i++;

		}

		return $pwd;

	}

	

	

	/**

	* Get site settings

	*/

	function site_settings(){

		$variable = $this -> return_result("SELECT * FROM `settings`");

		$settings= array();

		foreach($variable as $setting){

			$settings =array($setting['name']=>$setting['value']) +$settings;

		}

		return $settings;

	}

}

?>