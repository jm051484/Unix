<?php
include('cfg/db.php');

function login_request($username, $password){
    global $db;
    $username = $db -> escape($username);
    $password = $db -> escape($password);

    $query = "SELECT COUNT(*) FROM `users` WHERE `user_name`='$username' AND `user_pass`='$password'";
    $get_result = $db -> select($query);

    if($get_result != 0){
        $_query = "SELECT duration, vip_duration FROM `users` WHERE `user_name`='$username' AND `user_pass`='$password'";
        $uid = $db -> sql_query($_query) -> fetch_row();
    } else {
        $uid = 0;
    }
    return $uid;
}

function get_user_data($uid) {
    $data = array(
        'premium' => $uid[0],
        'vip' => $uid[1],
        'private' => 0
    );
    return $data;
}

if (isset($_GET["username"], $_GET["password"])){
    $login_data = [$_GET["username"], $_GET["password"]];
    $login = login_request($login_data[0], $login_data[1]);
    $error_array = ['error' => "username/password"];

    if($login != 0) {
        $data = get_user_data($login);
    } else {
        $data = $error_array;
    }
    echo json_encode($data);
}