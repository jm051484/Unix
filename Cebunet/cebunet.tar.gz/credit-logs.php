<!DOCTYPE html>
<html>

<?php
include('components/header.php');
include('components/bodytop.php');
?>

<div class="wrapper">
    <?php
    include('components/nav.php');
    include("components/sidebar.php");

    if(!isset($_SESSION['user'])){
        header("location: login.php");
    }

    ?>

    <div class="content-wrapper">

        <section class="content-header">
            <h1>
                Voucher/Credit
                <small>Credit Logs</small>
            </h1>
            <ol class="breadcrumb">
                <li><a href="profile.php"><i class="fa fa-dashboard"></i> Home</a></li>
                <li class="active">Credit Logs</li>
            </ol>
        </section>

        <div class="content">


            <div class="row">
                <div class="col-lg-12">
                    <div class="box box-warning">
                        <div class="box-header">Credits Logs</div>
                        <div class="box-body table-responsive">
                            <table class="table table-bordered table-hover dataTable" data-toggle="table" id="voucher-data" data-url="app/credits/logs.php"  data-show-refresh="true" data-show-toggle="true" data-show-columns="true" data-search="true" data-select-item-name="toolbar1" data-pagination="true" data-sort-name="name" data-sort-order="desc">
                                <thead>
                                <tr>
                                    <!--th data-field="state" data-checkbox="true" >Item ID</th-->
                                    <th data-field="id" data-sortable="true" style="width:10px;">Log ID</th>
                                    <th data-field="time_stamp"  data-sortable="true">Time Stamp</th>
                                    <th data-field="credits" data-sortable="true">Credits Used</th>
                                    <th data-field="receiver" data-sortable="true">Receiver</th>
                                    <th data-field="reseller" data-sortable="true">Reseller</th>
                                </tr>
                                </thead>
                            </table>
                        </div>
                    </div>
                </div>
            </div><!--/.row-->
        </div>
    </div>	<!--/.main-->
    <?php
    include('components/footer.php');
    ?>
    <?php
    include("components/js.php");
    ?>

    <script src="js/bootstrap-table.js"></script>
    <div class="control-sidebar-bg"></div>
</div>
</body>
<script>

    $("#top_up_form").submit(function(event){
        event.preventDefault();
        remove_alert_bg();
        $('#error-alert').addClass("bg-primary");
        $('#error-alert').fadeIn();
        $('#alert-message').text(" Please wait...");
        $.ajax({
            url: "app/voucher/top_up.php", data: $('#top_up_form').serialize(), type: "POST",  dataType: 'json',
            success: function (result) {
                console.log(result.status + " " + result.message);
                if (result.status!=1) {
                    remove_alert_bg();
                    $('#error-alert').addClass("alert-danger");
                    $('#alert-message').text(result.message);
                    setTimeout(function () { $('#error-alert').fadeOut()}, 5000);
                }else{
                    refresh_data();
                    $('#top_up').val('');
                    remove_alert_bg();
                    $('#error-alert').addClass("alert-success");
                    $('#alert-message').text(result.message);
                    //setTimeout(function () { window.location.assign("index.php");}, 1000);
                    setTimeout(function () { $('#error-alert').fadeOut()}, 5000);
                }
            }
        });

        console.log('clicked');
    });

    function remove_alert_bg(){
        $('#error-alert').removeClass("alert-success");
        $('#error-alert').removeClass("alert-primary");
        $('#error-alert').removeClass("alert-danger");
    }

    $("#generate_form").submit(function(event){
        event.preventDefault();
        remove_alert_bg2();
        $('#error-alert2').addClass("bg-primary");
        $('#error-alert2').fadeIn();
        $('#alert-message2').text(" Generating Voucher Key Please wait...");
        $.ajax({
            url: "app/voucher/generate.php" ,data: $('#generate_form').serialize(), type: "POST",  dataType: 'json',
            success: function (result) {
                console.log(result.status + " " + result.message);
                if (result.status!=1) {
                    remove_alert_bg();
                    $('#error-alert2').addClass("alert-danger");
                    $('#alert-message2').text(result.message);
                    setTimeout(function () { $('#error-alert').fadeOut()}, 5000);
                }else{
                    refresh_data();
                    $('#generated').val(result.code);
                    remove_alert_bg();
                    $('#error-alert2').addClass("alert-success");
                    $('#alert-message2').text(result.message);
                    //setTimeout(function () { window.location.assign("index.php");}, 1000);
                    setTimeout(function () { $('#error-alert').fadeOut()}, 5000);
                }
            }
        });

        console.log('clicked');
    });

    function remove_alert_bg2(){
        $('#error-alert2').removeClass("alert-success");
        $('#error-alert2').removeClass("alert-primary");
        $('#error-alert2').removeClass("alert-danger");
    }

    setTimeout(function () {
        set_touch();
    }, 1000);

    function refresh_data(){
        $('#voucher-data').bootstrapTable('refresh');
    }
    function set_touch(){
        $('#voucher-data').find('tr').click( function(){
            var row = $(this).find('td:first').text();
            $('#top_up').val(row);
        });
    }

    $( document ).ready(function() {
        set_touch();
    });



</script>
</html>
