<header class="main-header bg-info">
<a href="profile.php" class="logo">
      <!-- mini logo for sidebar mini 50x50 pixels -->
      <span class="logo-mini"><img class="navbar-brand" src="https://i.ibb.co/y0wx1tB/ae53092820f6f093253a7ba44d18e10d-0.png"></span>
      <!-- logo for regular state and mobile devices -->
      <span class="logo-lg">Cebunet <b>VPN</b></span>
    </a>
    <!-- Header Navbar: style can be found in header.less -->
    <nav class="navbar navbar-static-top">
      <!-- Sidebar toggle button-->
      <a href="#" class="sidebar-toggle" data-toggle="push-menu" role="button">
        <span class="sr-only">Toggle navigation</span>
      </a>

      <div class="navbar-custom-menu">
        <ul class="nav navbar-nav">

            <?php
            $get_id = $current_uid;
            if($current_rank=="Admin" || "Sub Admin" || "SubRS" || "Reseller") {
                $name_info = $db->select_row("SELECT `full_name` FROM `users` WHERE `user_id`=$get_id");
                $cur_name = $name_info[0]['full_name'];
            } else {
        	}
            ?>
          <li class="dropdown user user-menu">
            <a href="#" class="dropdown-toggle" data-toggle="dropdown">
              <img src="images/logo.jpg" class="user-image" alt="User Image">
              <span class="hidden-xs"><?php echo $current_user; ?></span>
            </a>
            <ul class="dropdown-menu">
              <!-- User image -->
              <li class="user-header">
                <img src="images/logo.jpg" class="img-circle" alt="User Image">

                <p>
                <?php
                if ($current_rank=="Guest") {
         echo '<html><script type="text/javascript">window.location.href="login.php"</script></html>';
         }
         ?>
                
                  <?php echo $cur_name; echo "-" .$current_rank; ?>
                  

                    <?php

                    if($current_rank=="Admin" || "Sub Admin" || "SubRS" || "Reseller") {
                        $get_id = $current_uid;
                        $profile_info = $db->select_row("SELECT `lastlogin` FROM `users` WHERE `user_id`=$get_id");
                    }
                    ?>
                    <small>Last login: <?php echo $profile_info[0]['lastlogin']; ?> </small>
                </p>
              </li>
              <!-- Menu Footer-->
              <li class="user-footer">
                <div class="pull-left">
                  <a href="profile.php" class="btn btn-default btn-flat">My Profile</a>
                </div>
                <div class="pull-right">
                  <a href="logout.php" class="btn btn-default btn-flat">Logout</a>
                </div>
              </li>
            </ul>
          </li>

			</div>
</header><!-- /.container-fluid -->