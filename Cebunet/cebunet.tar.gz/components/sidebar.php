<?php
$get_id = $current_uid;
$name_info = $db->select_row("SELECT `full_name` FROM `users` WHERE `user_id`=$get_id");
$cur_name = $name_info[0]['full_name'];
?>

<aside class="main-sidebar">

    <section class="sidebar">
                <!--li role="presentation" class="divider"></li-->


                <div class="user-panel">
                    <div class="pull-left image">
                    <img src="https://i.ibb.co/xGLmqzs/logo.jpg" class="img-circle" alt="User Image">
                    </div>
                    <div class="pull-left info">
                        <p><?php echo $cur_name; ?></p>
                        <a href="#"><i class="fa fa-circle text-success"></i> Active</a>
                    </div>
                </div>

                <ul class="sidebar-menu" data-widget="tree">
                    <li class="header">MAIN NAVIGATION</li>

                    <?php
                    if($current_rank=="Guest"){
                        header("location: login.php");?>
                        <?php
                    }else{ ?>

                    <?php $cur_path = basename($_SERVER['PHP_SELF']); ?>



                    <li <?php if ($cur_path == 'profile.php'){ echo "class=\"active\""; } ?>>
                        <a href="profile.php"><i class="fa fa-dashboard"></i> <span>My Profile</span>
                        </a>
                    </li>

                    <?php
                    $profile_info = $db -> select_row("SELECT * FROM `users` WHERE `user_id`=$get_id");

                    if($current_rank=="Admin" || $profile_info[0]['is_admin']==1){
                        ?>

                        <li <?php if ($cur_path == 'register.php'){ echo "class=\"active\""; } ?>><a href="register.php"><span class="fa fa-pencil"></span> Create User</a></li>

                        <li class="treeview">
                            <a href="">
                                <i class="fa fa-globe"></i> <span>Administration</span>
                                <span class="pull-right-container">
              <i class="fa fa-angle-left pull-right"></i>
            </span>
                            </a>
                            <ul class="treeview-menu">
                                <li <?php if ($cur_path == 'settings.php'){ echo "class=\"active\""; } ?>><a href="settings.php"><span class="fa fa-wrench"></span> Site Config</a></li>
                                <?php if ($_SESSION['user']['id']==1 && $_SESSION['user']['rank']=="Admin") {?>
                                <li <?php if ($cur_path == 'users2.php?user=reseller'){ echo "class=\"active\""; } ?>>
                                <a href="users2.php?user=reseller"><i class="fa fa-circle-o"></i> <span>All Resellers List</span></a></li>
                                 <?php } ?>
                                <?php if ($_SESSION['user']['id']==1 && $_SESSION['user']['rank']=="Admin") {?>
                                <li <?php if ($cur_path == 'credits.php'){ echo "class=\"active\""; } ?>><a href="credits.php"><span class="fa fa-credit-card"></span> Credits Management</a></li>
                                 <?php } ?>
                                <li <?php if ($cur_path == 'users.php?user=client'){ echo "class=\"active\""; } ?>><a href="users.php?user=client"><span class="fa fa-star-o"></span>Premium Users</a></li>
                                <li <?php if ($cur_path == 'vip-users.php?user=client'){ echo "class=\"active\""; } ?>><a href="vip-users.php?user=client"><span class="fa fa-star"></span>VIP Users</a></li>
                                <li <?php if ($cur_path == 'clients.php'){ echo "class=\"active\""; } ?>><a href="clients.php"><span class="fa fa-eye"></span> Client Monitoring</a></li>
                                <?php if ($_SESSION['user']['id']==1 && $_SESSION['user']['rank']=="Admin") {?>
                                <li <?php if ($cur_path == 'users.php'){ echo "class=\"active\""; } ?>><a href="users.php"><span class="fa fa-list-alt"></span> Users List</a></li>
                                <?php } ?>
                                <li <?php if ($cur_path == 'rank.php'){ echo "class=\"active\""; } ?>><a href="rank.php"><span class="fa fa-sort-numeric-desc"></span> Resellers Ranking</a></li>
                                <li <?php if ($cur_path == 'vouchers.php'){ echo "class=\"active\""; } ?>><a href="vouchers.php"><i class="fa fa-star-o"></i><span>Premium Voucher</span></a></li>
                                <li <?php if ($cur_path == 'vip-vouchers.php'){ echo "class=\"active\""; } ?>><a href="vip-vouchers.php"><i class="fa fa-star"></i><span>VIP Voucher</span></a></li>
                
                                <li <?php if ($cur_path == 'private.php'){ echo "class=\"active\""; } ?>><a href="private.php"><i class="fa fa-star-o"></i><span>Private Voucher</span></a></li>
                            
                                 <?php if ($_SESSION['user']['id']==1 && $_SESSION['user']['rank']=="Admin") {?>
                                <li <?php if ($cur_path == 'jsonside.php'){ echo "class=\"active\""; } ?>><a href="jsonside.php"><span class="fa fa-pencil"></span> Json Config Editor</a></li>
                                 <?php } ?>
                                 <li <?php if ($cur_path == 'custom_duration.php'){ echo "class=\"active\""; } ?>><a href="custom_duration.php"><span class="fa fa-android"></span>Self Reload</a>
                            </ul>
                        </li>

                        <?php
                    }elseif($current_rank=="Reseller" || $current_rank=="Sub Reseller" || $current_rank=="Sub Admin"){
                    ?>


                    <li <?php if ($cur_path == 'register.php'){ echo "class=\"active\""; } ?>><a href="register.php"><span class="fa fa-pencil"></span> Create User</a></li>

                    <li class="treeview">
                        <a href="#">
                            <i class="fa fa-gear"></i> <span>Generate Voucher</span>
                            <span class="pull-right-container">
                                        <small class="label pull-right bg-red">3</small>
                                    </span>
                        </a>
                        <ul class="treeview-menu">
                            <li <?php if ($cur_path == 'vouchers.php'){ echo "class=\"active\""; } ?>>
                                <a href="vouchers.php">
                                    <i class="fa fa-certificate"></i>
                                    <span>Premium Voucher</span>
                                </a>
                            </li>

                            <li <?php if ($cur_path == 'vip-vouchers.php'){ echo "class=\"active\""; } ?>>
                                <a href="vip-vouchers.php">
                                    <i class="fa fa-certificate"></i>
                                    <span>VIP Voucher</span>
                                    
                                 </a>
                            </li>    
                                 <li <?php if ($cur_path == 'private.php'){ echo "class=\"active\""; } ?>><a href="private.php"><i class="fa fa-star-o"></i><span>Private Voucher</span></a></li>
                                </a>
                            </li>
                        </ul>

                    </li>


                    <li class="treeview">
                        <a href="">
                            <i class="fa fa-globe"></i> <span>Administration</span>
                            <span class="pull-right-container">
              <i class="fa fa-angle-left pull-right"></i>
            </span>
                        </a>
                        <ul class="treeview-menu">
                            <li <?php if ($cur_path == 'users.php?user=client'){ echo "class=\"active\""; } ?>><a href="users.php?user=client"><span class="fa fa-list-alt"></span>My Premium Users</a></li>
                            <li <?php if ($cur_path == 'vip-users.php?user=client'){ echo "class=\"active\""; } ?>><a href="vip-users.php?user=client"><span class="fa fa-list-alt"></span>My VIP Users</a></li>

                            <li <?php if ($cur_path == 'clients.php'){ echo "class=\"active\""; } ?>><a href="clients.php"><span class="fa fa-eye"></span> Client Monitoring</a></li>
                            <li <?php if ($cur_path == 'custom_duration.php'){ echo "class=\"active\""; } ?>><a href="custom_duration.php"><span class="fa fa-eye"></span>Self Reload</a>
                                <?php
                                }
                                $msg_unread="";
                                $msg_unread_count = $db -> select("SELECT COUNT(*) FROM `messages` WHERE `is_unread`=1 AND `user_id_to`=".$_SESSION['user']['id']);
                                if($msg_unread_count > 0){
                                    $msg_unread="<span class=\"pull-right-container\">
                                        <small class=\"label pull-right bg-green\">New</small>
                                    </span>";
                                }
                                ?>
                            <li <?php if ($cur_path == 'support.php'){ echo "class=\"active\""; } ?>>
                                <a href="support.php"><i class="fa fa-inbox"></i> <span>Contact Support<?php echo $msg_unread ?></span>
                                </a>
                            </li>
                            
                            <li <?php if ($cur_path == 'users.php?user=subadmin'){ echo "class=\"active\""; } ?>>
                                <a href="users.php?user=subadmin"><i class="fa fa-anchor"></i> <span>Sub Admin List</span>
                                </a>
                            </li>  
                            <li <?php if ($cur_path == 'users.php?user=reseller'){ echo "class=\"active\""; } ?>>
                                <a href="users.php?user=reseller"><i class="fa fa-circle-o"></i> <span>My Resellers List</span>
                                </a>
                            </li>
                            <li <?php if ($cur_path == 'users.php?user=sub'){ echo "class=\"active\""; } ?>>
                                <a href="users.php?user=sub"><i class="fa fa-circle-o"></i> <span>My Sub-Resellers List</span>
                                </a>
                                
                            </li>

                                </a>
                            </li>

                            <?php if($current_rank=="Admin" || $profile_info[0]['is_admin']==1) { ?>
                            <li <?php if ($cur_path == 'credit-logs.php'){ echo "class=\"active\""; } ?>><a href="credit-logs.php"><span class="fa fa-book"></span> Credits Log</a></li>
                            <?php } ?>
                            <?php
                        if($current_rank == "Reseller" || $current_rank == "Admin" || $current_rank == "Sub Admin" || $current_rank == "Sub Reseller" ){
                            ?>
                            <li <?php if ($cur_path == 'expired-users.php'){ echo "class=\"active\""; } ?>><a href="expired-users.php"><span class="fa fa-book"></span> Expired Premium Users</a></li>
                            <?php } ?>
                            
                            <li <?php if ($cur_path == 'expired-users2.php'){ echo "class=\"active\""; } ?>><a href="expired-users2.php"><span class="fa fa-book"></span> Expired VIP Users</a></li>
                            

                            <!--li><a href="#"><span class="glyphicon glyphicon-signal"></span> Server Status</a></li-->
                        </ul>
                    </li>

                </ul>
    </section>

</aside>
    <div class="control-sidebar-bg"></div>

<?php
}
?>
