<!DOCTYPE html>
<html>

<?php
include('components/header.php');
include('components/bodytop.php');
?>

<div class="wrapper">
<?php
include('components/nav.php');
include("components/sidebar.php");

$delete_message="";
$get_type="";
if(isset($_GET['user'])){
	switch($db -> escape($_GET['user'])){
		case "sub":
			$get_type="?user=sub";
			break;
		case "reseller":
			$get_type="?user=reseller";
			break;
		case "subadmin":
			$get_type="?user=subadmin";
			break;
		case "client":
			if($current_rank=="Reseller" || $current_rank=="Admin" || $current_rank=="Sub Reseller" || $current_rank=="Sub Admin" ){
			}else{
				header("location: users.php?user=reseller");
			}
			$get_type="?user=client";
			break;
		case "all":
			if($current_rank<>"Admin"){
				header("location: users.php?user=reseller");
			}
		default:
			header("location: users.php?user=reseller");
	}

	if(isset($_GET['delete'])){
		if($_GET['id']<>1){
			if($_GET['delete']==0){
				if( $db -> select("SELECT `upline` FROM `users` WHERE `user_id`=".$db -> escape($_GET['id'])) == $_SESSION['user']['id'] || $_SESSION['user']['rank']=="Admin"){
					$db -> sql_query("DELETE FROM `users` WHERE `user_id`=".$db -> escape($_GET['id']));
					if(isset($_GET['users'])){
						header("location: users.php?user=".$db -> escape($_GET['user'])."&delete=1");
					}else{
						header("location: users.php?delete=1");
					$delete_message="alert('Unauthorized Action.');";
					}
					
				}else{
				}
			}elseif($_GET['delete']==1){
				$delete_message="alert('User Deleted!');";
			}
		}else{
			$delete_message="alert('Action Denied!');";
		}
	}
}else{
	if($current_rank<>"Admin"){
		header("location: users.php?user=reseller");
	}else{
		if(isset($_GET['delete'])){
			if($_GET['delete']==1){
				$delete_message="alert('User Deleted!');";
			}
		}
	}
}
?>	
	
	<div class="content-wrapper">
        <div class="content">
            <section class="content-header">
                <h1>
                    VIP Users
                    <small>VIP Users Monitoring</small>
                </h1>
                <ol class="breadcrumb">
                    <li><a href="#"><i class="fa fa-dashboard"></i> Dashboard</a></li>
                    <li class="active">Vip-Users</li>
                </ol>
            </section>
		<?php
		$users = "";
		if(isset($_GET['user'])){
			if($_GET['user']=="reseller"){
				$users="Reseller ";
			}elseif($_GET['user']=="client"){
				$users="Client ";
			}elseif($_GET['user']=="sub"){
				$users="Sub Reseller ";
			}elseif($_GET['user']=="subadmin"){
				$users="Sub Admin ";
			}else{
				$users="All ";
			}
		}else{
			$users="All ";
		}
		?>
		<br>
		
		<div class="row">
			<div class="col-lg-12">
				<div class="box">
					<div class="box-header">Users List</div>
					<div class="box-body table-responsive">
						<table class="table table-bordered table-hover dataTable-responsive" data-toggle="table" data-url="app/vip-users/list.php<?php echo $get_type;?>"  data-show-refresh="true" data-show-toggle="true" data-show-columns="true" data-search="true" data-select-item-name="toolbar1" data-pagination="true" data-sort-name="name" data-sort-order="desc">
						    <thead>
						    <tr>
						        <!--th data-field="state" data-checkbox="true" >Item ID</th-->
						        <th data-field="user_name" data-sortable="true">Username</th>
						        <th data-field="full_name"  data-sortable="true">Name</th>
						        <th data-field="type" data-sortable="true">User Type</th>
						        <th data-field="status" data-sortable="true">VIP Status</th>

						        <?php if(isset($_GET['user'])){
									if($_GET['user']=="reseller" || $_GET['user']=="sub" || $_GET['user']=="SubAdmin"){
								?>
								<th data-field="credits" data-sortable="true">Credits</th>
								<?php }else{
								if($_SESSION['user']['rank']=="Admin"){
								?>
									<th data-field="dur" data-sortable="true">Duration</th>
								<?php }} }else{
								?>
									<th data-field="dur" data-sortable="true">Duration</th>
								<?php }?>
						        <th data-field="payment" data-sortable="true">Payment Method</th>
						        <th data-field="contact" data-sortable="true">Contact</th>
						        <th data-field="action" data-sortable="true">Action</th>
						    </tr>
						    </thead>
						</table>
					</div>
				</div>
			</div>
		</div><!--/.row-->	
		
	</div>	<!--/.main-->
    </div>
<?php 
include("components/js.php");
?>
<?php
include('components/footer.php');
?>
	<script src="js/bootstrap-table.js"></script>
    <div class="control-sidebar-bg"></div>
    </div>
</div>
</body>
<script>
function view_profile(id){
	window.location="vip-status.php?user="+id;
}

function edit_user(id){
	window.location="account.php?user="+id;
}


function credit_user(id){
	window.location="credits.php?user="+id;
}

function monitor_user(id){
	window.location="clients.php?id="+id;
}

function delete_user(id){
	var r = confirm('Delete User?');
	if (r == true) { 
		window.location="users.php?user=client&id="+id+"&delete=0";
	}
}
setTimeout(function () { <?php echo $delete_message;?>}, 1000);
</script>
</html>
