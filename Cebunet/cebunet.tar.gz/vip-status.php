<!DOCTYPE html>
<html>

<?php
include('components/header.php');
include('components/bodytop.php');
?>

<div class="wrapper">
<?php
include('components/nav.php');
include('components/sidebar.php');
//$current_uid= $_SESSION['user']['id'];
if(!isset($_SESSION['user'])){
	header("location: index.php");
}
$get_id=0;
if(isset($_GET['user'])){
	$get_id = $db -> escape($_GET['user']);
	if($db -> select("SELECT `user_id` FROM `users` WHERE `user_id`=$get_id") == ""){
		header("location: profile.php");
	}
}else{
	$get_id = $current_uid;
}

	$profile_info = $db -> select_row("SELECT * FROM `users` WHERE `user_id`=$get_id");
	//print_r($profile_info);
	$dur = $db -> calc_time($profile_info[0]['vip_duration']);
	//print_r($dur);
	$duration = $dur['days'] . " day(s), " . $dur['hours'] . " hour(s) and " . $dur['minutes'] . " minute(s)";

	$date = date_create(date('Y-m-d H:i:s'));
	date_add($date, date_interval_create_from_date_string($profile_info[0]['duration'].' seconds'));
	$expiration = date_format($date, 'm/d')."/".substr(date_format($date, 'Y'),2,2);

	$VIP_status="Active";
	if($profile_info[0]['vip_duration']==0){
		$VIP_status="Inactive";
		$expiration="--";
	}
	$user_rank="";
	if($profile_info[0]['is_reseller']==1){
		$user_rank="Reseller";
	}elseif($profile_info[0]['is_reseller']==3){
		$user_rank="Sub Admin";		
	}elseif($profile_info[0]['is_reseller']==2){
		$user_rank="SubRS";
	}else{
		$user_rank="Client";
	}
	if($get_id==1 || $profile_info[0]['is_admin']==1){
		$user_rank="Admin";
	}


?>

<div class="content-wrapper">

    <div style="padding: 20px 30px; background: rgb(18, 108, 243); z-index: 999999; font-size: 16px; font-weight: 600;"><a class="pull-right" href="#" data-toggle="tooltip" data-placement="left" title="" style="color: rgb(255, 255, 255); font-size: 20px;" data-original-title="Never show me this again!">×</a><a href="vip-status.php" style="color: rgba(255, 255, 255, 0.9); display: inline-block; margin-right: 10px; text-decoration: none;"> Attention, Please do not use our vip server upon using it, Thanks.</a><a class="btn btn-default btn-sm" href="profile.php" style="margin-top: -5px; border: 0px; box-shadow: none; color: rgb(243, 156, 18); font-weight: 600; background: rgb(255, 255, 255);">Okay!</a></div>

    <section class="content-header">
        <h1>
            Profile
            <small>VIP Profile</small>
        </h1>
        <ol class="breadcrumb">
            <li><a href="profile.php"><i class="fa fa-dashboard"></i> Dashboard</a></li>
            <li class="active">VIP-Status</li>
        </ol>
    </section>

    <!-- Main content -->
    <section class="content">

        <!-- USER PANEL STATUS -->
        <div class="row">
            <div class="col-lg-3 col-xs-6">
                <!-- small box -->
                <div class="small-box bg-aqua">
                    <div class="inner">
                        <h4><?php echo $profile_info[0]['credits'];?></h4>

                        <p>Credits</p>
                    </div>
                    <div class="icon">
                        <i class="ion ion-ios-gear-outline"></i>
                    </div>
                    <a href="#" class="small-box-footer">More info <i class="fa fa-arrow-circle-right"></i></a>
                </div>
            </div>
            <!-- ./col -->
            <div class="col-lg-3 col-xs-6">
                <!-- small box -->
                <div class="small-box bg-green">
                    <div class="inner">
                        <h4><?php echo $VIP_status;?></h4>

                        <p>VIP</p>
                    </div>
                    <div class="icon">
                        <i class="fa fa-rocket"></i>
                    </div>
                    <a href="#" class="small-box-footer">More info <i class="fa fa-arrow-circle-right"></i></a>
                </div>
            </div>
            <!-- ./col -->
            <div class="col-lg-3 col-xs-6">
                <!-- small box -->
                <div class="small-box bg-purple">
                    <div class="inner">
                        <h4><?php echo $expiration;?></h4>

                        <p>Expiration</p>
                    </div>
                    <div class="icon">
                        <i class="fa fa-clock-o"></i>
                    </div>
                    <a href="#" class="small-box-footer">More info <i class="fa fa fa-arrow-circle-right"></i></a>
                </div>
            </div>
            <!-- ./col -->
            <div class="col-lg-3 col-xs-6">
                <!-- small box -->
                <div class="small-box bg-red">
                    <div class="inner">
                        <h4><?php echo $user_rank;?></h4>

                        <p>User Type</p>
                    </div>
                    <div class="icon">
                        <i class="ion-ios-people-outline"></i>
                    </div>
                    <a href="#" class="small-box-footer">More info <i class="fa fa-arrow-circle-right"></i></a>
                </div>
            </div>
            <!-- ./col -->
        </div>
        <!-- /.row -->
        <!-- /. USER PANEL STATUS -->


		<div class="row">
			<div class="col-lg-12">
				<div class="box">
					<div class="box-header">Account Info</div>
					<div class="box-body">
						<div class="col-xs-6">
							<form role="form">
								
								<div class="form-group">
									<label>Full Name</label>
									<input class="form-control" readonly value="<?php echo ($profile_info[0]['full_name']);?>">
								</div>
								
								<div class="form-group">
									<label>Email</label>
									<input class="form-control" type="email" readonly value="<?php echo ($profile_info[0]['user_email']);?>">
								</div>
								<div class="form-group">
									<label>Address</label>
									<input class="form-control" type="text" readonly value="<?php echo ($profile_info[0]['location']);?>">
								</div>
								<div class="form-group">
									<label>Mode of Payment (Reseller)</label>
									<input class="form-control" type="text" readonly value="<?php echo ($profile_info[0]['payment']);?>">
								</div>
								<div class="form-group">
									<label>Contact Info</label>
									<input class="form-control" type="text" readonly value="<?php echo ($profile_info[0]['contact']);?>">
								</div>
						</div>
						<div class="col-md-6">
								<div class="form-group">
									<label>Reseller</label>
									<input type="text" class="form-control" readonly value="<?php echo ($db -> select("SELECT `full_name` FROM `users` WHERE `user_id`=".$profile_info[0]['upline']));?>">
								</div>
								<div class="form-group">
									<label>VIP Duration</label>
									<input type="text" class="form-control" readonly value="<?php echo $duration;?>">
								</div>
						</div>
					</div>
				</div>
			</div><!-- /.col-->
		</div><!-- /.row -->
		
		
		
	</div>	<!--/.main-->

<?php 
include("components/js.php");
?>
<?php
include('components/footer.php');
?>
    <div class="control-sidebar-bg"></div>
</div>
</body>

</html>
