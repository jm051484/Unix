<?php
include_once("cfg/db.php");
if($variable['is_maintenance']<>"1"){
	$db->sql_query("UPDATE `users` SET `duration`=`duration` - 1800 WHERE user_id > 1 AND duration > 0 and frozen = 0");
}
echo $variable['is_maintenance'];
?>