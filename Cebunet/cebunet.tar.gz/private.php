<!DOCTYPE html>
<html>

<?php
include('components/header.php');
?>
<body class="hold-transition skin-yellow sidebar-mini">
<div class="wrapper">
<?php
include('components/nav.php');
include("components/sidebar.php");

if(!isset($_SESSION['user'])){
	header("location: login.php");
}

?>	
	
	<div class="content-wrapper">

        <section class="content-header">
            <h1>
                Private Voucher
                <small>Private Account Voucher</small>
            </h1>
            <ol class="breadcrumb">
                <li><a href="profile.php"><i class="fa fa-dashboard"></i> Home</a></li>
                <li class="active">Private</li>
            </ol>
        </section>

        <br>

        <div class="content">
            
            <?php if ($current_rank == "Admin") { ?>

         <div class="row">
            <div class="col-lg-6">
                <div class="box">
                    <div class="box-header">Generate Voucher</div>
                    <div class="box-body">

                        <?php
                        if($current_rank == "Admin"){
                            ?>
                            <form id="generate_form" role="form">
                                <div class="form-group">
                                    <label>Generate Voucher Code</label>
                                    <input class="form-control" placeholder="Generated Code Goes Here" id="generated" value="">
                                </div>
                                <?php
                                if( $current_rank == "Admin" && $_SESSION['user']['id']==1){
                                    ?>

                                    <div class="form-group">
                                        <label>Custom Duration</label>
                                        <select class="form-control" name="custom" onchange="$('#custom').toggle();">
                                            <option value="0">No</option>
                                            <option value="1">Yes</option>
                                        </select>
                                    </div>
                                    <div id="custom" style="display:none">
                                        <div class="form-group">
                                            <label>Custom Days</label>
                                            <input class="form-control" placeholder="Days" id="days" name="days" type="number" value="0">
                                        </div>
                                        <div class="form-group">
                                            <label>Custom Hours</label>
                                            <input class="form-control" placeholder="Hours" id="hours" name="hours" type="number" value="0">
                                        </div>
                                        <div class="form-group">
                                            <label>Custom Minutes</label>
                                            <input class="form-control" placeholder="Minutes" id="minutes" name="minutes" type="number" value="0">
                                        </div>
                                    </div>

                                    <?php
                                }
                                ?>
                                <button type="submit" class="btn btn-success">Generate</button>
                                <button type="button" onclick="$('#top_up').val($('#generated').val())" id="copy_button" class="btn btn-warning">Copy and Paste Code to top up</button>
                                <br /><br />
                                <div class="alert bg-primary" role="alert" id="error-alert2" style="display:none;">
                                    <span class="fa fa-exclamation-circle"></span><span id="alert-message2"> </span></a>
                                </div>
                            </form>
                            <?php
                        }
                        ?>
                    </div>
                </div>
            </div>



			<div class="col-lg-6">
				<div class="box">
					<div class="box-header">Top-up Voucher</div>
					<div class="box-body">
					
							<form id="top_up_form" role="form">
								<div class="form-group">
									<label>Top Up Voucher Code</label>
									<input class="form-control" placeholder="Enter Voucher Code" name="code_name" id="top_up" value="" required>
								</div>
								<?php
							if($current_rank == "Reseller" || $current_rank == "Admin" || $current_rank == "Sub Admin" || $current_rank == "Sub Reseller" ){
								?>
								<div class="form-group">
									<label>Apply to client?</label>
									<select class="form-control" name="custom" onchange="$('#client_top_up').toggle();">
										<option value="0">Self Reload</option>
										<option value="1">Apply to Client/s</option>
									</select>
								</div>

                                <?php
                                if ($current_rank=="Admin"){
                                ?>
                                    <div id="client_top_up" style="display:none">
                                        <div class="form-group">
                                            <label>Choose client</label>
                                            <select class="form-control selectpicker" name="client" data-live-search="true">
                                                <?php
                                                $clients = $db -> return_result("SELECT * FROM `users` ORDER BY `user_name`");
                                                //print_r($clients);
                                                foreach($clients as $data){
                                                    echo "<option value='{$data['user_id']}'>".$data['user_name'] . " : " . $data['full_name']."</option>";
                                                }
                                                ?>
                                            </select>
                                        </div>
                                    </div>

                                    <?php }else{ ?>

								<div id="client_top_up" style="display:none">
									<div class="form-group">
										<label>Choose client</label>
										<select class="form-control selectpicker" name="client" data-live-search="true">
										<?php
										$clients = $db -> return_result("SELECT * FROM `users` WHERE `upline`=$current_uid ORDER BY `user_name`");
										//print_r($clients);
										foreach($clients as $data){
											echo "<option value='{$data['user_id']}'>".$data['user_name'] . " : " . $data['full_name']."</option>";
										}
										?>
										</select>
									</div>
								</div>
								
								<?php 
								}}
								?>
								<button type="submit" class="btn btn-primary">Top Up</button>
								<br /><br />
								<div class="alert bg-primary" role="alert" id="error-alert" style="display:none;">
									<span class="glyphicon glyphicon-exclamation-sign"></span><span id="alert-message"> </span></a>
								</div>
							</form>

                    </div>
                </div>
            </div>

		</div><!--/.row-->
            <div class="row">
                <div class="col-lg-12">
                    <div class="box">
                        <div class="box-header">Voucher List</div>
                        <div class="box-body table-responsive">
                            <table class="table table-bordered table-hover dataTable" data-toggle="table" id="voucher-data" data-url="app/private/list_voucher.php"  data-show-refresh="true" data-show-toggle="true" data-show-columns="true" data-search="true" data-select-item-name="toolbar1" data-pagination="true" data-sort-name="name" data-sort-order="desc">
                                <thead>
                                <tr>
                                    <!--th data-field="state" data-checkbox="true" >Item ID</th-->
                                    <th data-field="code_name" data-sortable="true">Voucher Code</th>
                                    <th data-field="is_used"  data-sortable="true">Used</th>
                                    <th data-field="date_used" data-sortable="true">Date Used</th>
                                    <th data-field="time_stamp" data-sortable="true">Time Stamp</th>
                                    <th data-field="duration" data-sortable="true">Duration (H:M:S)</th>
                                    <th data-field="reseller" data-sortable="true">Reseller</th>
                                    <th data-field="client" data-sortable="true">Client</th>
                                </tr>
                                </thead>
                            </table>
                            </div>
                    </div>
                </div>
            </div><!--/.row-->
        </div>
        
        
	</div>	<!--/.main-->
	
	
	
<?php
include('components/footer.php');
?>

<?php } ?>

<?php 
include("components/js.php");
?>

<div class="modal" role="dialog" tabindex="-1" id="showinfo">
            <div class="modal-dialog">
                <div class="modal-content">
                    <div class="modal-header">
                        <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                            <span aria-hidden="true">&times;</span></button>
                        <h4 class="modal-title">Hello <?php echo $current_user; ?></h4>
                    </div>
                    <div class="modal-body">
                        <p>
                        <b>You are unauthorized to access this page</b> <br style="white-space: normal;">
                        Admin Access only! Thanks
                        </p>
                    </div>
                    <div class="modal-footer">
                        <button class="btn btn-primary" onclick="javascript:history.go(-1)" data-dismiss="modal">Okay</button>
                    </div>
                </div>
                <!-- /.modal-content -->
            </div>
            <!-- /.modal-dialog -->
        </div>

<?php if($current_rank == "Client" || $current_rank == "Sub Admin" || $current_rank == "Reseller" || $current_rank == "Sub Reseller") { ?>

<script>
    $(window).load(function(){        
       $('#showinfo').modal('show');
    }); 
</script>

<?php } else { } ?>

	<script src="js/bootstrap-table.js"></script>
    <div class="control-sidebar-bg"></div>
</div>
</body>
<script>
$("#top_up_form").submit(function(event){
	event.preventDefault();
	remove_alert_bg();
	$('#error-alert').addClass("bg-primary");
	$('#error-alert').fadeIn();
	$('#alert-message').text(" Please wait...");
		$.ajax({
			url: "app/private/top_up.php", data: $('#top_up_form').serialize(), type: "POST",  dataType: 'json',
			success: function (result) {
						console.log(result.status + " " + result.message);
						if (result.status!=1) { 
							remove_alert_bg();
							$('#error-alert').addClass("alert-danger");
							$('#alert-message').text(result.message);
							setTimeout(function () { $('#error-alert').fadeOut()}, 5000);
						}else{
							refresh_data();
							$('#top_up').val('');
							remove_alert_bg();
							$('#error-alert').addClass("alert-success");
							$('#alert-message').text(result.message);
							//setTimeout(function () { window.location.assign("index.php");}, 1000);
							setTimeout(function () { $('#error-alert').fadeOut()}, 5000);
						}
					}
		});
		
	console.log('clicked');
});

function remove_alert_bg(){
	$('#error-alert').removeClass("alert-success");
	$('#error-alert').removeClass("alert-primary");
	$('#error-alert').removeClass("alert-danger");
}	

$("#generate_form").submit(function(event){
	event.preventDefault();
	remove_alert_bg2();
	$('#error-alert2').addClass("bg-primary");
	$('#error-alert2').fadeIn();
	$('#alert-message2').text(" Generating Voucher Key Please wait...");
		$.ajax({
			url: "app/private/generate.php" ,data: $('#generate_form').serialize(), type: "POST",  dataType: 'json',
			success: function (result) {
						console.log(result.status + " " + result.message);
						if (result.status!=1) { 
							remove_alert_bg();
							$('#error-alert2').addClass("alert-danger");
							$('#alert-message2').text(result.message);
							setTimeout(function () { $('#error-alert').fadeOut()}, 5000);
						}else{
							refresh_data();
							$('#generated').val(result.code);
							remove_alert_bg();
							$('#error-alert2').addClass("alert-success");
							$('#alert-message2').text(result.message);
							//setTimeout(function () { window.location.assign("index.php");}, 1000);
							setTimeout(function () { $('#error-alert').fadeOut()}, 5000);
						}
					}
		});
		
	console.log('clicked');
});

function remove_alert_bg2(){
	$('#error-alert2').removeClass("alert-success");
	$('#error-alert2').removeClass("alert-primary");
	$('#error-alert2').removeClass("alert-danger");
}	

setTimeout(function () { 
	set_touch();
}, 1000);

function refresh_data(){
	$('#voucher-data').bootstrapTable('refresh');
}
function set_touch(){
	$('#voucher-data').find('tr').click( function(){
		var row = $(this).find('td:first').text();
		$('#top_up').val(row);
	});
}

$( document ).ready(function() {
	set_touch();
});
</script>
</html>
