<!DOCTYPE html>
<html>

<?php
include('components/header.php');
include('components/bodytop.php');
?>

<div class="wrapper">
<?php
include('components/nav.php');
include("components/sidebar.php");

$delete_message="";
$get_type="";
if(isset($_SESSION['user'])){
	if($current_rank == "Client" ){
		header("location: users.php?user=reseller");
	}
}else{
	header("location: users.php?user=reseller");
}
?>	
	
	<div class="content-wrapper">
        <section class="content-header">
            <h1>
                Json Editor
                <small>Edit Json for Online Update</small>
            </h1>
            <ol class="breadcrumb">
                <li><a href="#"><i class="fa fa-dashboard"></i> Home</a></li>
                <li class="active">JsonEditor</li>
            </ol>
        </section>
        <br>



		<?php
		$users = "";
		if(isset($_GET['user'])){
			if($_GET['user']=="reseller"){
				$users="Reseller ";
			}elseif($_GET['user']=="sub"){
				$users="Sub Reseller ";
			}elseif($_GET['user']=="client"){
				$users="Client ";
			}else{
				$users="All ";
			}
		}else{
			$users="All ";
		}
		?>



        <section class="content">
		<div class="row">


			<div class="col-lg-12">

				<div class="box box-warning">
					<?php
					$upline="";
					if(isset($_GET['id'])){
						$upline= $db -> select("SELECT CONCAT(' - ',`user_name`,' | ',`full_name`) FROM `users` WHERE `user_id`=".$db -> escape($_GET['id']));
					}
					?>
					<div class="box-header">Clients List <?php echo "$upline";?></div>
					<div class="box-body table-responsive">
					<?php
					$upline_id="";
						if($_SESSION['user']['rank']=="Admin"){
							if(isset($_GET['id'])){
								$upline_id="&upline=".$db -> escape($_GET['id']);
							}
						}
					?>

                        <button class="btn btn-danger btn-flat" onclick="history.go(-1);">Back </button>

						<table class="table table-bordered table-hover dataTable-responsive" data-toggle="table" data-url="app/users/list.php?user=client<?php echo $upline_id;?>"  data-show-refresh="true" data-show-toggle="true" data-show-columns="true" data-search="true" data-select-item-name="toolbar1" data-pagination="false" data-sort-name="name" data-sort-order="desc">
                            <thead>
						    <tr>
						        <th data-field="user_name" data-sortable="true">Username</th>
						        <th data-field="full_name"  data-sortable="true">Name</th>
                                <th data-field="type"  data-sortable="true">User Type</th>
								<th data-field="dur" data-sortable="true">Duration</th>
						        <th data-field="contact" data-sortable="true">Contact</th>
						        <th data-field="action" data-sortable="true">Action</th>
						    </tr>
						    </thead>

						</table>
					</div>
				</div>
			</div>
		</div><!--/.row-->	
		
	</div>	<!--/.main-->


<?php 
include("components/js.php");
?>
<?php
include('components/footer.php');
?>	
	<script src="js/bootstrap-table.js"></script>
    <div class="control-sidebar-bg"></div>
</div>
</body>
<script>
function view_profile(id){
	window.location="profile.php?user="+id;
}

function edit_user(id){
	window.location="account.php?user="+id;
}

function monitor_user(id){
	window.location="clients.php?id="+id;
}

function credit_user(id){
	window.location="credits.php?user="+id;
}

function delete_user(id){
	var r = confirm('Delete User?');
	if (r == true) { 
		window.location="users.php?user=client&id="+id+"&delete=0";
	}
}
setTimeout(function () { <?php echo $delete_message;?>}, 1000);
</script>
</html>
