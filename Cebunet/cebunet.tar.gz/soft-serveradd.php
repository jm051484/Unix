<!DOCTYPE html>
<html>

<?php
include('components/header.php');
include('components/bodytop.php');

error_reporting(-1);
ini_set('display_errors', 'On');

?>

<div class="wrapper">
<?php
include('components/nav.php');
include("components/sidebar.php");
?>

    <div class="content-wrapper">
        
            <section class="content-header">
                <h1>
                    Server
                    <small>Management</small>
                </h1>
                <ol class="breadcrumb">
                    <li><a href="#"><i class="fa fa-dashboard"></i> Home</a></li>
                    <li class="active">Soft-Servers</li>
                </ol>
            </section>
            
            <div class="content">

        <br>
        
      
		<div class="row">
		
		
		<div class="col-lg-12">
				<div class="box box-primary">
					<div class="box-header">Softether Server Management</div>

					<div class="box-body">
						<form id="server_form" role="form">
						
						<div class="col-xs-12">
								
								<div class="form-group">
									<label>Server IP Address</label>
									<div class="input-group">
                                        <span class="input-group-addon"><i class="fa fa-server"></i></span>
                                        <input name="server_ip" value="" class="form-control" placeholder="IP Address" required>
                                    </div>
                                </div>

                                <div class="form-group">
									<label>Server Location</label>
									<div class="input-group">
                                        <span class="input-group-addon"><i class="fa fa-flag"></i></span>
                                        <input name="server_location" value="" class="form-control" placeholder="Server Name" required>
                                    </div>
                                </div>

                                <div class="form-group">
									<label>Subscription Type</label>
									<select class="form-control" name="type">
										<option value="premium">Premium Server</option>
										<option value="vip">VIP Server</option>
									</select>

								</div>


								<button type="submit" class="btn btn-block btn-primary btn-flat">Add Server</button>

								<br /><br />

								<div class="alert bg-primary" role="alert" id="error-alert" style="display:none;">

									<span class="glyphicon glyphicon-exclamation-sign"></span><span id="alert-message"> </span></a>

								</div>
						</div>
						</form>
						</div>
						</div>
						</div><!-- /.col-->
		
		
				
			<div class="col-xs-12">
				<div class="box box-primary">
                    <div class="box-header">Softether Servers List</div>
					<div class="box-body table-responsive">
						<table class="table table-bordered table-hover dataTable-responsive" role="grid" data-toggle="table" data-url="app/soft/server_list.php"  data-show-refresh="true" data-show-toggle="true" data-show-columns="true" data-search="true" data-select-item-name="toolbar1" data-pagination="true" >
						    
						    <div class="alert bg-primary" role="alert" id="error-alert" style="display:none;">

									<span class="glyphicon glyphicon-exclamation-sign"></span><span id="alert-message"> </span></a>

								</div>
						    
						    <thead>
						    <tr>
						            <th data-field="name" data-sortable="true">Server Name</th>
						            <th class="text-center" data-field="server_ip" data-sortable="true">Server IP</th>
                                    <th data-field="type" data-sortable="true">Server Type</th>
                                    <th data-field="actions" data-sortable="true">Action</th>
						    </tr>
						    </thead>
						</table>
					</div>
					
				</div>
				
				
				
			</div>
		</div><!--/.row-->	
		
		
		
		
        </div>
	</div>	<!--/.main-->

<?php 
include("components/js.php");
?>

	<script src="js/bootstrap-table.js"></script>

<?php
include('components/footer.php');
?>
    <div class="control-sidebar-bg"></div>
</div>
</body>

<script>
function delete_server(id){
    var r = confirm('Are you sure you want to delete this server fro? It may take a few seconds.');
    if (r == true) {
      function remove_alert_bg(){
        $('#error-alert').removeClass("alert-success");
        $('#error-alert').removeClass("alert-primary");
        $('#error-alert').removeClass("alert-danger");
      }

        remove_alert_bg();
        $('#error-alert').addClass("bg-primary");
        $('#error-alert').fadeIn();
        $('#alert-message').text(" Deleting Account Please Wait...");
         
        $.ajax({
            beforeSend: function(xhr) {
                xhr.setRequestHeader("X-AUTH-TOKEN", "<?php echo $_SESSION['user']['token']; ?>")
            },
            type: 'POST',
            url: 'https://ayos-vpn.softetherapi.ml/api/1.0/server/delete_server',
            data: {server_ip: id},
            success: function (result) {
                        if (!result.success) { 
                            remove_alert_bg();
                            $('#error-alert').addClass("alert-danger");
                            $('#alert-message').text(' ' + result.error);
                            setTimeout(function () { $('#error-alert').fadeOut()}, 4000);
                        }else{
                            remove_alert_bg();
                            $('#error-alert').addClass("alert-success");
                            $('#alert-message').text(" " + result.success);
                            setTimeout(function () { $('#error-alert').fadeOut()}, 4000);
                        }

                    }
            
        })
    }
} 


$("#server_form").submit(function(event){

	event.preventDefault();

	remove_alert_bg();

	$('#error-alert').addClass("bg-primary");

	$('#error-alert').fadeIn();

	$('#alert-message').text(" Please wait...");

		$.ajax({
		    type: "POST",
		    beforeSend: function(xhr) {
			    xhr.setRequestHeader("X-AUTH-TOKEN", "<?php echo $_SESSION['user']['token']; ?>")
			},
			url: "https://ayos-vpn.softetherapi.ml/api/1.0/server/add_server",
			data: $('#server_form').serialize(), dataType: 'json',

			success: function (result) {
						console.log(result.status + " " + result.message);

						if (!result.success) { 

							remove_alert_bg();
							$('#error-alert').addClass("alert-danger");
							$('#alert-message').text(' ' + result.error);
							setTimeout(function () { $('#error-alert').fadeOut()}, 3000);

						}else{

							remove_alert_bg();
							$('#error-alert').addClass("alert-success");
				    		$('#alert-message').text(" " + result.success);
							setTimeout(function () { $('#error-alert').fadeOut()}, 3000);
							$("#server_form")[0].reset();

						}

					}

		});

		

	console.log('clicked');

});


function remove_alert_bg(){

	$('#error-alert').removeClass("alert-success");

	$('#error-alert').removeClass("alert-primary");

	$('#error-alert').removeClass("alert-danger");

}	


</script>
</html>