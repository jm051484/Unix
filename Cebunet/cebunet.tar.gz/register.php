<!DOCTYPE html>
<?php
include('components/header.php');
include('components/bodytop.php');
?>
<?php
$get_id=0;
if(isset($_GET['user'])){
	$get_id = $db -> escape($_GET['user']);
	if($db -> select("SELECT `user_id` FROM `users` WHERE `user_id`=$get_id") == ""){
		header("location: profile.php");
		}
}else{
	$get_id = $current_uid;
}
		
$profile_info = $db -> select_row("SELECT * FROM `users` WHERE `user_id`=$get_id");

$creds = $profile_info[0]['credits'];

if ($creds == 0) {
  echo '<script type="text/javascript">';
  echo 'window.location.href = "nocredits.php" ';
  echo '</script>';
  } else{
}
?>

<div class="wrapper">

<?php
include('components/nav.php');
include("components/sidebar.php");
?>	

   <div class="content-wrapper">
    <section class="content-header">
     <h1>Register<small>Account Creation</small></h1>
      <ol class="breadcrumb">
       <li><a href="profile.php"><i class="fa fa-dashboard"></i> Home</a></li>
        <li class="active">Register</li>
       </ol>
      </section>
     <br>
     <div class="content">
      <div class="row">
       <div class="col-lg-12">
        <div class="box box-primary">
         <div class="box-header">Account Form</div>
          <div class="box-body">
           <form id="profile_form" role="form">
            <div class="col-md-6">
             <div class="form-group">
              <label>Full Name</label>
               <div class="input-group">
               <span class="input-group-addon"><i class="fa fa-user"></i></span>
               <input name="full_name" value="" class="form-control" placeholder="Full Name" required>
              </div>
             </div>
            <div class="form-group">
            <label>Email</label>

                                    <div class="input-group">
                                        <span class="input-group-addon"><i class="fa fa-envelope"></i></span>
                                        <input type="email" name="email" value="" class="form-control" placeholder="Email" required>
                                    </div>

								</div>



								<div class="form-group">

									<label>Location</label>

									<div class="input-group">
                                        <span class="input-group-addon"><i class="fa fa-home"></i></span>
                                        <input name="location" value="PH" class="form-control" placeholder="Location">
                                    </div>

								</div>

								<div class="form-group">

									<label>Mode of Payment (Reseller)</label>

                                    <div class="input-group">
                                        <span class="input-group-addon"><i class="fa fa-dollar"></i></span>
                                        <input name="payment" value="" class="form-control" placeholder="Mode of Payment">
                                    </div>

								</div>

								<div class="form-group">

									<label>Contact Info</label>

                                    <div class="input-group">
                                        <span class="input-group-addon"><i class="fa fa-info"></i></span>
                                        <input name="contact" value="" class="form-control" placeholder="Contact Info">
                                    </div>

								</div>
		<?php
		if(isset($_SESSION['user'])) {
		if($_SESSION['user']['user_name']=="admin"){ ?>

								<div class="form-group">

									<label>User Type</label>

									<select class="form-control" name="type">
										<option value="0">Client</option>

										<option value="1">Reseller</option>
										<option value="2">Sub-Admin</option>

									</select>

								</div>

								<?php }}?>

						</div>

						<div class="col-md-6">

								<div class="form-group">

									<label>Username</label>

                                    <div class="input-group">
                                        <span class="input-group-addon"><i class="fa fa-user"></i></span>
                                        <input id="username" class="form-control" name="username" type="text" pattern="^[a-zA-Z][a-zA-Z0-9-_\.]{1,20}$" placeholder="Username" required>
                                    </div>



								

								</div>

								<div class="form-group">

									<label>Password</label>

                                    <div class="input-group">
                                        <span class="input-group-addon"><i class="fa fa-lock"></i></span>
                                        <input id="password" class="form-control" name="password" type="password" pattern="^\S{6,}$" onchange="this.setCustomValidity(this.validity.patternMismatch ? 'Must have at least 6 characters' : ''); if(this.checkValidity()) form.password_two.pattern = this.value;" placeholder="Password" required>
                                    </div>

								</div>

																

								<div class="form-group">

									<label>Confirm Password</label>

                                    <div class="input-group">
                                        <span class="input-group-addon"><i class="fa fa-check"></i></span>
                                        <input id="password_two" class="form-control" name="password_two" type="password" pattern="^\S{6,}$" onchange="this.setCustomValidity(this.validity.patternMismatch ? 'Please enter the same Password as above' : '');" placeholder="Verify Password" required>
                                    </div>



								</div>

								<button type="submit" class="btn btn-block btn-primary btn-flat">Create Account</button>

								<br /><br />

								<div class="alert bg-primary" role="alert" id="error-alert" style="display:none;">

									<span class="glyphicon glyphicon-exclamation-sign"></span><span id="alert-message"> </span></a>

								</div>

							

						</div>

						</form>	

					</div>

				</div>

			</div><!-- /.col-->

		</div><!-- /.row -->




    </div>
		

	</div>	<!--/.main-->


<?php 

include("components/js.php");

?>

<script>

$("#profile_form").submit(function(event){

	event.preventDefault();

	remove_alert_bg();

	$('#error-alert').addClass("bg-primary");

	$('#error-alert').fadeIn();

	$('#alert-message').text(" Please wait...");

		$.ajax({

			url: "app/account/create_account.php", data: $('#profile_form').serialize(), type: "POST",  dataType: 'json',

			success: function (result) {

						console.log(result.status + " " + result.message);

						if (result.status!=1) { 

							remove_alert_bg();

							$('#error-alert').addClass("alert-danger");

							$('#alert-message').text(result.message);

							setTimeout(function () { $('#error-alert').fadeOut()}, 3000);

						}else{

							remove_alert_bg();

							$('#error-alert').addClass("alert-success");

							$('#alert-message').text(result.message);

							//setTimeout(function () { window.location.assign("index.php");}, 1000);

							setTimeout(function () { $('#error-alert').fadeOut()}, 3000);

							$("#profile_form")[0].reset();

						}

					}

		});

	console.log('clicked');
});

function remove_alert_bg(){

	$('#error-alert').removeClass("alert-success");

	$('#error-alert').removeClass("alert-primary");

	$('#error-alert').removeClass("alert-danger");

}	

</script>

<?php
	include('components/footer.php');
?>
<div class="control-sidebar-bg"></div>
</div>
</body>

</html>