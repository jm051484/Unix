<!DOCTYPE html>

<html>



<?php

include('components/header.php');
include('components/bodytop.php');

?>

<body class="hold-transition skin-blue sidebar-mini">
<div class="wrapper">
<?php

include('components/nav.php');

include("components/sidebar.php");



if(!isset($_SESSION['user'])){

	header("location: login.php");

}





$get_id=0;

if($_SESSION['user']['rank']=="Admin"){

	if(isset($_GET['user'])){

		$get_id = $db -> escape($_GET['user']);

		if($db -> select("SELECT `user_id` FROM `users` WHERE `user_id`=$get_id") == ""){

			header("location: account.php");

		}else{

			if($db -> select("SELECT `upline` FROM `users` WHERE `user_id`=$get_id") <> $_SESSION['user']['id'] && $current_rank <> "Admin"){

				header("location: account.php");

			}

		}

	}else{

		$get_id = $current_uid;

	}

}elseif($_SESSION['user']['rank']=="Reseller"){

	if(isset($_GET['user'])){

		$get_id = $db -> escape($_GET['user']);

		if($db -> select("SELECT `user_id` FROM `users` WHERE `user_id`=$get_id") == ""){

			header("location: account.php");

		}else{

			if($db -> select("SELECT `upline` FROM `users` WHERE `user_id`=$get_id") <> $_SESSION['user']['id']){

				header("location: account.php");

			}

		}

	}else{

		$get_id = $current_uid;

	}

	}elseif($_SESSION['user']['rank']=="Sub Admin"){

	if(isset($_GET['user'])){

		$get_id = $db -> escape($_GET['user']);

		if($db -> select("SELECT `user_id` FROM `users` WHERE `user_id`=$get_id") == ""){

			header("location: account.php");

		}else{

			if($db -> select("SELECT `upline` FROM `users` WHERE `user_id`=$get_id") <> $_SESSION['user']['id'] && $current_rank <> "Sub Admin"){

				header("location: account.php");

			}

		}

	}else{

		$get_id = $current_uid;

	}

}else{

	header("location: account.php");

}

$profile_info = $db -> select_row("SELECT * FROM `users` WHERE `user_id`=$get_id");
	

$dur = $db -> calc_time($profile_info[0]['duration']);
	//print_r($dur);
	$premium_duration = $dur['days'] . " day(s), " . $dur['hours'] . " hour(s) and " . $dur['minutes'] . " minute(s)";

$vip_dur = $db -> calc_time($profile_info[0]['vip_duration']);
//print_r($dur);
$vip_duration = $vip_dur['days'] . " day(s), " . $dur['hours'] . " hour(s) and " . $dur['minutes'] . " minute(s)";

?>	

	

	<div class="content-wrapper">

        <section class="content-header">
            <h1>
                Duration
                <small>Duration Management</small>
            </h1>
            <ol class="breadcrumb">
                <li><a href="profile.php"><i class="fa fa-dashboard"></i> Home</a></li>
                <li class="active">Duration</li>
            </ol>
        </section>


		<br>

     <div class="content">
		<div class="row">

			<div class="col-lg-12">

				<div class="box">

					<div class="box-header">Custom Duration Form</div>

					<div class="box-body">

							<div class="col-md-6">

								<div class="form-group">

									<label>Full Name</label>

									<input class="form-control" placeholder="Enter Full Name" name="full_name" value="<?php echo htmlspecialchars($profile_info[0]['full_name']);?>" readonly>

								</div>

								

								<div class="form-group">

									<label>Email</label>

									<input class="form-control" type="email" name="email" placeholder="email@example.com" value="<?php echo htmlspecialchars($profile_info[0]['user_email']);?>" readonly>

								</div>

								<div class="form-group">

									<label>Contact Info</label>

									<input class="form-control" placeholder="Contact Info" name="contact" value="<?php echo htmlspecialchars($profile_info[0]['contact']);?>" readonly>

								</div>

								<!--button type="submit" class="btn btn-primary">Update Profile</button-->

							</div>
<div class="col-md-6">
								<form id="duration_form" role="form">
									<input type="hidden" name="user_id" value="<?php echo $get_id;?>" >
<div class="form-group">

										<label>Current duration</label>

										<input type="number" id current_duration" class="form-control" value="<?php echo htmlspecialchars($profile_info[0]['duration']);?>" readonly>

									</div>
							<div class="form-group">
                            <label>Current duration</label>
					        <input type="text" class="form-control" readonly value="<?php echo $premium_duration;?>">
							</div>
								<div class="form-group">
										<label>Select how many Days</label>
										<!--input class="form-control" id="duration"  name="duration" type="number" placeholder="Amount" required-->
									<select id="duration" class="form-control" name="duration" >
										<option value="86400">1 day</option>
										<option value="172800">2 days</option>
										<option value="259200">3 days</option>
										<option value="345600">4 days</option>
										<option value="432000">5 days</option>
										<option value="518400">6 days</option>
										<option value="604800">7 days</option>
										<option value="691200">8 days</option>
										<option value="777600">9 days</option>
										<option value="864000">10 days</option>
										<option value="1728000">20 days</option>
										<option value="2592000">30 days</option>
									</select>
									</div>
									<button type="submit" class="btn btn-primary">Add Duration</button>
									<br /><br />
								</form>	
							</div>
														<div class="col-md-6">
								<form id="vip_duration_form" role="form">
									<input type="hidden" name="user_id" value="<?php echo $get_id;?>" >
							    <div class="form-group">
								<label>Current vip duration</label>
								<input type="text" class="form-control" readonly value="<?php echo $vip_duration;?>">
									</div>
								<div class="form-group">
										<label>Select how many Days</label>
										<!--input class="form-control" id="duration"  name="duration" type="number" placeholder="Amount" required-->
									<select id="vip_duration" class="form-control" name="vip_duration" >
										<option value="86400">1 day</option>
										<option value="172800">2 days</option>
										<option value="259200">3 days</option>
										<option value="345600">4 days</option>
										<option value="432000">5 days</option>
										<option value="518400">6 days</option>
										<option value="604800">7 days</option>
										<option value="691200">8 days</option>
										<option value="777600">9 days</option>
										<option value="864000">10 days</option>
										<option value="1728000">20 days</option>
										<option value="2592000">30 days</option>
									</select>
									</div>
									<button type="submit" class="btn btn-primary">Add Duration</button>
									<br /><br />
									<div class="alert bg-primary" role="alert" id="error-alert" style="display:none;">
										<span class="glyphicon glyphicon-exclamation-sign"></span><span id="alert-message"> </span></a>
									</div>
								</form>	
								<div class="col-md-6">
								
								<div>
								    <a href="#" class="btn btn-flat btn-success" data-toggle="modal" data-target="#confirmation-form">
								        refresh</a>
								</div>

                            <div class="modal" role="dialog" tabindex="-1" id="confirmation-form">
                                <div class="modal-dialog">
                                    <div class="modal-content">
                                        <div class="modal-header">
                                            <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                                                <span aria-hidden="true">&times;</span></button>
                                            <h4 class="modal-title">Refresh Account</h4>
                                        </div>
                                        <div class="modal-body">
                                            <p>Click yes to refresh vpn user account from the database.</p>
                                        </div>
                                        <div class="modal-footer">
                                            <button class="btn btn-default pull-left" data-dismiss="modal">Close</button>
                                            <button class="btn btn-primary btn-ok" onclick="<?php $db -> sql_query ("UPDATE users SET is_active=1 WHERE `user_id`=$get_id"); ?>">Yes</button>
                                        </div>
                                    </div>
                                    <!-- /.modal-content -->
                                </div>
                                <!-- /.modal-dialog -->
                            </div>
								
						</div>
							</div>
					</div>
				</div>
			</div><!-- /.col-->
		</div><!-- /.row -->
		
		
		
	</div>	<!--/.main-->

<?php 
include("components/js.php");
?>

<script>
$("#duration_form").submit(function(event){
	event.preventDefault();
	remove_alert_bg();
	$('#error-alert').addClass("bg-primary");
	$('#error-alert').fadeIn();
	$('#alert-message').text(" Please wait...");
		$.ajax({
			url: "app/credits/add_duration.php", data: $('#duration_form').serialize(), type: "POST",  dataType: 'json',
			success: function (result) {
						console.log(result.status + " " + result.message);
						if (result.status!=1) { 
							remove_alert_bg();
							$('#error-alert').addClass("bg-danger");
							$('#alert-message').text(result.message);
							setTimeout(function () { $('#error-alert').fadeOut()}, 3000);
						}else{
							remove_alert_bg();
							$('#error-alert').addClass("bg-success");
							$('#alert-message').text(result.message);
							$('#current_duration').val(parseInt($('#current_duration').val())+parseInt($('#duration').val()));
							//setTimeout(function () { window.location.assign("index.php");}, 1000);
							setTimeout(function () { $('#error-alert').fadeOut()}, 3000);
						}
					}
		});
		
	console.log('clicked');
});

function remove_alert_bg(){
	$('#error-alert').removeClass("bg-success");
	$('#error-alert').removeClass("bg-primary");
	$('#error-alert').removeClass("bg-danger");
}	
</script>
<script>
$("#vip_duration_form").submit(function(event){
	event.preventDefault();
	remove_alert_bg();
	$('#error-alert').addClass("bg-primary");
	$('#error-alert').fadeIn();
	$('#alert-message').text(" Please wait...");
		$.ajax({
			url: "app/credits/add_vipduration.php", data: $('#vip_duration_form').serialize(), type: "POST",  dataType: 'json',
			success: function (result) {
						console.log(result.status + " " + result.message);
						if (result.status!=1) { 
							remove_alert_bg();
							$('#error-alert').addClass("bg-danger");
							$('#alert-message').text(result.message);
							setTimeout(function () { $('#error-alert').fadeOut()}, 3000);
						}else{
							remove_alert_bg();
							$('#error-alert').addClass("bg-success");
							$('#alert-message').text(result.message);
							$('#current_vip_duration').val(parseInt($('#current_vip_duration').val())+parseInt($('#vip_duration').val()));
							//setTimeout(function () { window.location.assign("index.php");}, 1000);
							setTimeout(function () { $('#error-alert').fadeOut()}, 3000);
						}
					}
		});
		
	console.log('clicked');
});

function remove_alert_bg(){
	$('#error-alert').removeClass("bg-success");
	$('#error-alert').removeClass("bg-primary");
	$('#error-alert').removeClass("bg-danger");
}	
</script>


	
</body>
</html>

							