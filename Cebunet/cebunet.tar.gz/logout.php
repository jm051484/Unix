<?php

include('cfg/db.php');



session_destroy();

header("location:login.php");


?>

