<?php
include_once("cfg/db.php");
if($variable['is_maintenance']<>"1"){
	$db->sql_query("UPDATE `users` SET `vip_duration`=`vip_duration` - 300 WHERE user_id > 1 AND vip_duration > 0 and frozen = 0");
}
echo $variable['is_maintenance'];
?>