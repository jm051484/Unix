<?php
error_reporting(E_ALL & ~E_NOTICE);

//Format:
//(1=>"ServerName","ServerAddress","ServerRootPassword","ExpirationDays"),

$server_lists_array=array(
  1=>array(1=>"SNL Server 01","104.248.150.185","SNL#Family#","5"),
  2=>array(1=>"Altaria Server","localhost","bonveio","5"),
  3=>array(1=>"Cannon Server","localhost","bonveio","5"),
  4=>array(1=>"Sven Server","localhost","bonveio","5"),
  5=>array(1=>"Google Server","localhost","bonveio","5"),
	);			


 // Squid Ports
$port_squid= '3128, 8080, 8888';	


for ($row = 1; $row < 101; $row++ )
	{
	if ( $_POST['server'] == $server_lists_array[$row][1] )
		{
		$hosts= $server_lists_array[$row][2];
		$root_pass= $server_lists_array[$row][3];
		$expiration= $server_lists_array[$row][4];
		break;
		}
	}
	
$error = false;
if (isset($_POST['user'])) 
	{
$username = trim($_POST['user']);
$username = strip_tags($username);
$username = htmlspecialchars($username);
$password1 = trim($_POST['password']);
$password1 = strip_tags($password1);
$password1 = htmlspecialchars($password1);
$cpassword = $_POST['confirmpassword'];
$cpassword = strip_tags($cpassword);
$cpassword = htmlspecialchars($cpassword);
$password1 = $_POST['password'];
$nDays = $expiration;
$datess = date('m/d/y', strtotime('+'.$nDays.' days'));
	$password = escapeshellarg( crypt($password1) );
		
	if (empty($username)) 
	  {
	$error = true;
	$nameError = "<div class='alert alert-dismissible bg-warning alert-warning white-text'>Please enter your username</div>";
	   }
	 else if (strlen($username) < 2)
			{
				$error = true;
				$nameError = "<div class='alert alert-dismissible bg-warning alert-warning white-text'>Username must have atleat 2 characters</div>";
			}
			
	if (empty($password1))
		{
			$error = true;
			$passError = "<div class='alert alert-dismissible bg-warning alert-warning white-text'>Please enter password.</div>";
		} 
		else if(strlen($password1) < 2) 
		
	{
	$error = true;
$passError = "<div class='alert alert-dismissible bg-warning alert-warning white-text'>Password must have atleast 2 characters.</div>";
	}
	if($password1 != $cpassword)
		{
		$error = true;
		$cpaseror = "<div class='alert alert-dismissible bg-warning alert-warning white-text'>Password Didn't match.</div>";
		} 
		
	if( !$error ) 
		{
	date_default_timezone_set('UTC');
	date_default_timezone_set("Asia/Manila"); 
	$my_date = date("Y-m-d H:i:s"); 
	$connection = ssh2_connect($hosts, 22);
	if (ssh2_auth_password($connection, 'paneladmin', $root_pass)) 
		$check_user = ssh2_exec($connection, "id -u $username");
				$check_user_error = ssh2_fetch_stream($check_user, SSH2_STREAM_STDERR);
stream_set_blocking($check_user_error, true);
stream_set_blocking($check_user, true);
$stream_check_user_error = stream_get_contents($check_user_error);
$stream_check_user = stream_get_contents($check_user);
   	if ( !empty($stream_check_user))
   					{
   		$ServerError = "<div class='alert alert-dismissible bg-danger alert-danger white-text'>Username Already Exists, Please try another username</div>";
   					}
   	elseif ( !empty($stream_check_user_error)) {
	$show = true;	 
     ssh2_exec($connection, "useradd -m $username -p $password -e $datess -s /usr/sbin/nologin");
			} 
			else {
						die('Connection Failed...');
					}	
			}   
	} 
?>

<!DOCTYPE html>
<head>

    <meta charset="utf-8">
  <meta http-equiv="X-UA-Compatible" content="IE=edge">
  <meta content="width=device-width, initial-scale=1, maximum-scale=1, user-scalable=no" name="viewport">
  <meta name="theme-color" content="#367fa9">
<title>SharingNoLimits VPN | SSH SSL Accounts</title>

<link rel="shortcut icon" href="images/favicon.ico">

  <link rel="stylesheet" href="bower_components/bootstrap/dist/css/bootstrap.min.css">
  <link rel="stylesheet" href="bower_components/font-awesome/css/font-awesome.min.css">
  <link rel="stylesheet" href="bower_components/Ionicons/css/ionicons.min.css">
  <link rel="stylesheet" href="dist/css/AdminLTE.min.css">
  <link rel="stylesheet" href="dist/css/skins/_all-skins.min.css">
  <!-- Morris chart -->
  <link rel="stylesheet" href="bower_components/morris.js/morris.css">
  <!-- jvectormap -->
  <link rel="stylesheet" href="bower_components/jvectormap/jquery-jvectormap.css">
  <!-- Date Picker -->
  <link rel="stylesheet" href="bower_components/bootstrap-datepicker/dist/css/bootstrap-datepicker.min.css">
  <!-- Daterange picker -->
  <link rel="stylesheet" href="bower_components/bootstrap-daterangepicker/daterangepicker.css">
  <!-- bootstrap wysihtml5 - text editor -->
  <link rel="stylesheet" href="plugins/bootstrap-wysihtml5/bootstrap3-wysihtml5.min.css">

  <!-- HTML5 Shim and Respond.js IE8 support of HTML5 elements and media queries -->
  <!-- WARNING: Respond.js doesn't work if you view the page via file:// -->
  <!--[if lt IE 9]>
  <script src="https://oss.maxcdn.com/html5shiv/3.7.3/html5shiv.min.js"></script>
  <script src="https://oss.maxcdn.com/respond/1.4.2/respond.min.js"></script>
  <![endif]-->
  <!-- Google Font -->
  <link rel="stylesheet" href="https://fonts.googleapis.com/css?family=Source+Sans+Pro:300,400,600,700,300italic,400italic,600italic">
<!--[if lt IE 9]>
<script src="js/html5shiv.js"></script>
<script src="js/respond.min.js"></script>
    <![endif]-->
</head>
<body class="hold-transition skin-blue sidebar-mini">
<div class="wrapper">

<header class="main-header bg-info">
<a href="profile.php" class="logo">
      <!-- mini logo for sidebar mini 50x50 pixels -->
      <span class="logo-mini"><img class="navbar-brand" src="images/logo.png"></span>
      <!-- logo for regular state and mobile devices -->
      <span class="logo-lg">SharingNoLimits <b>VPN</b></span>
    </a>
    <!-- Header Navbar: style can be found in header.less -->
    <nav class="navbar navbar-static-top">
      <!-- Sidebar toggle button-->
      <a href="#" class="sidebar-toggle" data-toggle="push-menu" role="button">
        <span class="sr-only">Toggle navigation</span>
      </a>
</header>
<!-- /.container-fluid -->

<aside class="main-sidebar">
<section class="sidebar">
<ul class="sidebar-menu" data-widget="tree">
<li class="header">MAIN NAVIGATION</li>

<!-- <small class="label pull-right bg-green">New</small> -->

<li><a href="profile.php"><i class="fa fa-dashboard"></i> <span>My Profile</span></a></li>
<li class="active"><a href="sshacount.php"><i class="fa fa-dashboard"></i> <span>My Profile</span></a></li>
                </ul>
    </section>
</aside>
    <div class="control-sidebar-bg"></div>

   <div class="content-wrapper">
    <section class="content-header">
     <h1>OpenSSH / SSL Servers<small>Create Account</small></h1>
      <ol class="breadcrumb">
       <li><a href="profile.php"><i class="fa fa-dashboard"></i> Home</a></li>
        <li class="active">SSH/SSL Create Account</li>
       </ol>
      </section>
      
     <br>

 <div class="content">
  <div class="row">
   <div class="col-md-6">

  <form method="post" action="sshaccount.php" autocomplete="off">

   <div class="box box-primary">
   <div class="box-header with-border">
   <h3 class="box-title">Select Server</h3>
  </div>
    <div class="box-body">

      <?php echo $ServerError; ?>
      <?php echo $cpaseror; ?>
      <?php echo $nameError; ?>
      <?php echo $passError; ?>
      
    <div class="form-group">
    <select class="form-control" name="server">
    <optgroup label="Sharing No Limits Server">
 <?php 
 for ($row = 1; $row < 101; $row++)
 { if ( !empty($server_lists_array[$row][1])) {
 echo '<option>';
 echo $server_lists_array[$row][1];
 echo '</option>';
 } else { break; } }
?>
   </optgroup>				
   </select>
   </div>
   </div></div>

   <div class="box box-primary">
   <div class="box-header with-border">
   <h3 class="box-title">Account Info</h3>
  </div>
    <div class="box-body">
  
  <div class="form-group">
  <div class="input-group has-feedback">
<span class="input-group-addon"><i class="fa fa-user"></i></span>
        <input type="text" name="user" id="username" class="form-control" placeholder="Username" value="<?php echo $username ?>" required>
      </div>
        </div>
<div class="form-group">
<div class="input-group has-feedback">
          <span class="input-group-addon"><i class="fa fa-lock"></i></span>
        <input type="text" name="password" class="form-control" id="password" placeholder="Password" required>
      </div>
</div>

<div class="form-group">
<div class="input-group has-feedback">
          <span class="input-group-addon"><i class="fa fa-lock"></i></span>
        <input type="text" name="confirmpassword" class="form-control" id="confirm" placeholder="Confirm Password" required>
      </div>
</div>

 <div class="box-footer">
          <button id="submit-login" type="submit" class="btn btn-primary btn-block pull-right">Create Account</button>
        </div>
</div>
</div>
   
   <?php
	if($show == true) {
echo '<div class="col-md-6"><div class="box box-info"> <div class="box-header with-border"> <h3 class="box-title">Account Successfully Created</h3> </div> <div class="box-body">';
  	echo "<p>Host: ";echo $hosts; echo "<br>";
	echo "Username: ";echo $username; echo "<br>";
	echo "Password: "; echo $password1; echo "<br>";
	echo "Proxy Port: "; echo $port_squid; echo "<br>";
	echo "SSH Port: "; echo $port_dropbear; echo "<br>";
	echo "SSL Port: "; echo $port_stunnel; echo "<br>";
	echo "Expiration: "; echo $expiration; echo " Days<br>";
	echo "Date Expired: ";echo $datess; echo "<br></p>";
    echo '</div><div class="box-footer"><button class="btn btn-primary" data-dismiss="modal">Okay</button></div></div></div></div>';
    }
?>

   </div></div>
   </div>
   </div>
   </div>
   
<?php include("components/js.php"); ?>
<script>
$("#profile_form").submit(function(event){
	event.preventDefault();
	remove_alert_bg();
	$('#error-alert').addClass("bg-primary");
	$('#error-alert').fadeIn();
	$('#alert-message').text(" Please wait...");
		$.ajax({
			url: "app/account/create_account.php", data: $('#profile_form').serialize(), type: "POST",  dataType: 'json',
			success: function (result) {
						console.log(result.status +-- " " +-- result.message);
						if (result.status!=1) { 
							remove_alert_bg();
							$('#error-alert').addClass("alert-danger");
							$('#alert-message').text(result.message);
							setTimeout(function () { $('#error-alert').fadeOut()}, 3000);
						}else{
							remove_alert_bg();
							$('#error-alert').addClass("alert-success");
							$('#alert-message').text(result.message);
							//setTimeout(function () { window.location.assign("index.php");}, 1000);
							setTimeout(function () { $('#error-alert').fadeOut()}, 3000);
							$("#profile_form")[0].reset();
						}
					}
		});
	console.log('clicked');
});
function remove_alert_bg(){
	$('#error-alert').removeClass("alert-success");
	$('#error-alert').removeClass("alert-primary");
	$('#error-alert').removeClass("alert-danger");
}
</script>
<?php
	include("components/footer.php");
?>
<div class="control-sidebar-bg"></div>
</div>
</body>
</html>