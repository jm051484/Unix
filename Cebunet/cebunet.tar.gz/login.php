<!DOCTYPE html>
<html>
<head>
  <link rel="shortcut icon" href="images/favicon/favicon.ico">
  <meta charset="utf-8">
  <meta http-equiv="X-UA-Compatible" content="IE=edge">
 <meta name="theme-color" content="#367fa9">
  <title>Cebunet VPN | Log in</title>
  <!-- Tell the browser to be responsive to screen width -->
  <meta content="width=device-width, initial-scale=1, maximum-scale=1, user-scalable=no" name="viewport">
  <!-- Bootstrap 3.3.7 -->
  <link rel="stylesheet" href="bower_components/bootstrap/dist/css/bootstrap.min.css">
  <!-- Font Awesome -->
  <link rel="stylesheet" href="bower_components/font-awesome/css/font-awesome.min.css">
  <!-- Ionicons -->
  <link rel="stylesheet" href="bower_components/Ionicons/css/ionicons.min.css">
  <!-- Theme style -->
  <link rel="stylesheet" href="dist/css/AdminLTE.min.css">
  <!-- iCheck -->
  <link rel="stylesheet" href="plugins/iCheck/square/blue.css">

  <!-- HTML5 Shim and Respond.js IE8 support of HTML5 elements and media queries -->
  <!-- WARNING: Respond.js doesn't work if you view the page via file:// -->
  <!--[if lt IE 9]>
  <script src="https://oss.maxcdn.com/html5shiv/3.7.3/html5shiv.min.js"></script>
  <script src="https://oss.maxcdn.com/respond/1.4.2/respond.min.js"></script>
  <![endif]-->

  <!-- Google Font -->
  
<?php
if(isset($_SESSION['user']))
{
    header("location: profile.php");
}
?>
<link rel="stylesheet" href="https://fonts.googleapis.com/css?family=Source+Sans+Pro:300,400,600,700,300italic,400italic,600italic">
</head>





<body class="hold-transition login-page">


<div class="login-box">

    <div class="login-logo">
    <a href="profile.php"><b>Cebunet </b>VPN</a>
  </div>

  <!-- /.login-logo -->
  <div class="login-box-body">
      
      <div class="alert bg-primary" role="alert" id="error-alert" style="display:none;">
          <span class="glyphicon glyphicon-exclamation-sign"> </span><span id="alert-message"> Please Login.</span></a>
      </div>

      <center><a href="profile.php"><img class="brand-img" src="https://i.ibb.co/xGLmqzs/logo.jpg" alt="express" width="95px" height="100px"></center></a>

    <p class="login-box-msg">Sign in to start your session</p>

    <form id="login_form">
        <div class="form-group">
      <div class="input-group has-feedback">
          <span class="input-group-addon"><i class="fa fa-user"></i></span>
        <input type="text" name="username" class="form-control" placeholder="Username" required>
      </div>
        </div>
      <div class="input-group has-feedback">
          <span class="input-group-addon"><i class="fa fa-lock"></i></span>
        <input type="password" name="password" class="form-control" id="password" placeholder="Password" required>
      </div>
      <div class="row">
        <div class="col-xs-8">
          <div class="checkbox icheck">
            <label>
              <input type="checkbox"> Remember Me
            </label>
          </div>
        </div>
        <!-- /.col -->
        <div class="col-xs-12">
          <button id="submit-login" type="submit" class="btn btn-primary btn-block btn-flat">Login</button>
        </div>

        <!-- /.col -->
      </div>

    </form>
    <br>



    Already Login? <a href="profile.php" class="text-center">Click Here</a>

  </div>
  <!-- /.login-box-body -->
</div>

<!-- /.login-box -->

<!-- jQuery 3 -->
<script src="bower_components/jquery/dist/jquery.min.js"></script>
<!-- Bootstrap 3.3.7 -->
<script src="bower_components/bootstrap/dist/js/bootstrap.min.js"></script>
<!-- iCheck -->
<script src="plugins/iCheck/icheck.min.js"></script>

<script>
  $(function () {
    $('input').iCheck({
      checkboxClass: 'icheckbox_square-blue',
      radioClass: 'iradio_square-blue',
      increaseArea: '20%' // optional
    });
  });
</script>

<script>
    $("#login_form").submit(function(event){
        event.preventDefault();
        remove_alert_bg();
        $('#error-alert').addClass("alert-primary");
        $('#error-alert').fadeIn();
        $('#alert-message').text(" Authenticating please wait...");
        $.ajax({
            url: "app/login/process_login.php", data: $('#login_form').serialize(), type: "POST",  dataType: 'json',
            success: function (result) {
                console.log(result.status + " " + result.message);
                if (result.status!=1) {
                    remove_alert_bg();
                    $('#error-alert').addClass("alert-danger");
                    $('#alert-message').text(result.message);
                    setTimeout(function () { $('#error-alert').fadeOut()}, 3000);
                }else{
                    remove_alert_bg();
                    $('#error-alert').addClass("alert-success");
                    $('#alert-message').text(result.message);
                    setTimeout(function () { window.location.assign("profile.php");}, 1000);
                    setTimeout(function () { $('#error-alert').fadeOut()}, 3000);
                }
            }
        });
        console.log('clicked');
    });
    function remove_alert_bg(){
        $('#error-alert').removeClass("alert-success");
        $('#error-alert').removeClass("alert-primary");
        $('#error-alert').removeClass("alert-danger");
    }
</script>


</body>
</html>
