<?php
header('Content-Type: application/json');
include_once("../../cfg/db.php");

$get_type="";
$actions="'N/A'";

if(isset($_GET['user'])){
	switch($_GET['user']){
		case "reseller":
			$get_type=" WHERE `is_reseller`=1 ";
			$actions = "CONCAT('<button class=\'btn btn-warning\' onclick=\"view_profile(\'',`user_id`,'\')\">View</button>')";
			break;
		case "reseller":
			$get_type=" WHERE `is_reseller`=1 and upline='".$_SESSION['user']['id']."'";
			$actions = "CONCAT('<button class=\'btn btn-warning\' onclick=\"view_profile(\'',`user_id`,'\')\">View</button>')";
			break;
					case "subadmin":
			$get_type=" WHERE `is_reseller`=3 ";
			$actions = "CONCAT('<button class=\'btn btn-warning\' onclick=\"view_profile(\'',`user_id`,'\')\">View</button>')";
			break;
		case "sub":
			if(isset($_SESSION['user'])){
				if($_SESSION['user']['rank']=="Reseller"){
					$get_type=" WHERE `is_reseller`=2 and upline='".$_SESSION['user']['id']."'";
				}else{
					$get_type=" WHERE `is_reseller`=2 ";
				}
				$actions = "CONCAT('<button class=\'btn btn-warning\' onclick=\"view_profile(\'',`user_id`,'\')\">View</button>')";
				if($_SESSION['user']['rank']=="Reseller" || $_SESSION['user']['rank']=="Sub Admin" || $_SESSION['user']['rank']=="Sub Reseller"){
					$get_type=$get_type." AND `upline`=" . $_SESSION['user']['id'];
					$actions = "CONCAT('<button class=\'btn btn-warning\' onclick=\"view_profile(\'',`user_id`,'\')\">View</button> ', ' <button class=\'btn btn-success\' onclick=\"edit_user(\'',`user_id`,'\')\">Edit</button> ', ' <button class=\'btn btn-danger\' onclick=\"delete_user(\'',`user_id`,'\')\">Delete</button> ') ";
				}
			}else{
				$get_type=" WHERE `is_reseller`=2 ";
			}
			
			//$get_type="";
			
			break;
		case "client":
			
			$get_type=" WHERE `is_reseller`=0";
			
			if($_SESSION['user']['rank']=="Reseller"){
				$get_type=$get_type." AND `upline`=" . $_SESSION['user']['id'];
				$actions = "CONCAT('<button class=\'btn btn-warning\' onclick=\"view_profile(\'',`user_id`,'\')\">View</button> ', ' <button class=\'btn btn-success\' onclick=\"edit_user(\'',`user_id`,'\')\">Edit</button> ', ' <button class=\'btn btn-danger\' onclick=\"delete_user(\'',`user_id`,'\')\">Delete</button> ') ";
			}
			if($_SESSION['user']['rank']=="Sub Admin"){
				$get_type=$get_type." AND `upline`=" . $_SESSION['user']['id'];
				$actions = "CONCAT('<button class=\'btn btn-warning\' onclick=\"view_profile(\'',`user_id`,'\')\">View</button> ', ' <button class=\'btn btn-success\' onclick=\"edit_user(\'',`user_id`,'\')\">Edit</button> ', ' <button class=\'btn btn-danger\' onclick=\"delete_user(\'',`user_id`,'\')\">Delete</button> ') ";
			}
			if($_SESSION['user']['rank']=="Sub Reseller"){
				$get_type=$get_type." AND `upline`=" . $_SESSION['user']['id'];
				$actions = "CONCAT('<button class=\'btn btn-warning\' onclick=\"view_profile(\'',`user_id`,'\')\">View</button> ', ' <button class=\'btn btn-success\' onclick=\"edit_user(\'',`user_id`,'\')\">Edit</button> ', ' <button class=\'btn btn-danger\' onclick=\"delete_user(\'',`user_id`,'\')\">Delete</button> ') ";
			}
			
			break;
		default:
	}
}
if(isset($_SESSION['user']['rank'])){
	if($_SESSION['user']['rank']=="Admin"){
		if(isset($_GET['user'])){
			if($_GET['user']=="reseller"){
				$monitoring = "";
				if(isset($_GET['monitor'])){
					if($_GET['monitor']==1){
						$monitoring = ", ";
					}
				}
				$actions = "CONCAT(' <button class=\'btn btn-info\' onclick=\"monitor_user(\'',`user_id`,'\')\">Monitor Clients</button> ','<button class=\'btn btn-warning\' onclick=\"view_profile(\'',`user_id`,'\')\">View</button> ', ' <button class=\'btn btn-success\' onclick=\"edit_user(\'',`user_id`,'\')\">Edit</button> ', ' <button class=\'btn btn-primary\' onclick=\"credit_user(\'',`user_id`,'\')\">Credit</button> ', ' <button class=\'btn btn-danger\' onclick=\"delete_user(\'',`user_id`,'\')\">Delete</button> ') ";

               }elseif($_GET['user']=="sub"){
				$actions = "CONCAT(' <button class=\'btn btn-info\' onclick=\"monitor_user(\'',`user_id`,'\')\">Monitor Clients</button> ','<button class=\'btn btn-warning\' onclick=\"view_profile(\'',`user_id`,'\')\">View</button> ', ' <button class=\'btn btn-success\' onclick=\"edit_user(\'',`user_id`,'\')\">Edit</button> ', ' <button class=\'btn btn-primary\' onclick=\"credit_user(\'',`user_id`,'\')\">Credit</button> ', ' <button class=\'btn btn-danger\' onclick=\"delete_user(\'',`user_id`,'\')\">Delete</button> ') ";
			}elseif($_GET['user']=="subadmin"){
				$actions = "CONCAT(' <button class=\'btn btn-info\' onclick=\"monitor_user(\'',`user_id`,'\')\">Monitor Clients</button> ','<button class=\'btn btn-warning\' onclick=\"view_profile(\'',`user_id`,'\')\">View</button> ', ' <button class=\'btn btn-success\' onclick=\"edit_user(\'',`user_id`,'\')\">Edit</button> ', ' <button class=\'btn btn-primary\' onclick=\"credit_user(\'',`user_id`,'\')\">Credit</button> ', ' <button class=\'btn btn-danger\' onclick=\"delete_user(\'',`user_id`,'\')\">Delete</button> ') ";
			}else{
			
				$actions = "CONCAT('<button class=\'btn btn-warning\' onclick=\"view_profile(\'',`user_id`,'\')\">View</button> ', ' <button class=\'btn btn-success\' onclick=\"edit_user(\'',`user_id`,'\')\">Edit</button> ', ' <button class=\'btn btn-danger\' onclick=\"delete_user(\'',`user_id`,'\')\">Delete</button> ') ";
				if(isset($_GET['user'],$_GET['upline'])){
					$get_type=" WHERE `is_reseller`=0 AND `upline`=". $db -> escape($_GET['upline']);
				}
			}
		}else{
			$actions = "CONCAT('<button class=\'btn btn-warning\' onclick=\"view_profile(\'',`user_id`,'\')\">View</button> ', ' <button class=\'btn btn-success\' onclick=\"edit_user(\'',`user_id`,'\')\">Edit</button> ', ' <button class=\'btn btn-danger\' onclick=\"delete_user(\'',`user_id`,'\')\">Delete</button> ') ";
		}

	}elseif($_SESSION['user']['rank']=="Reseller"){
		if(isset($_GET['user'])){
			if($_GET['user']=="reseller"){
				$monitoring = "";
				if(isset($_GET['monitor'])){
					if($_GET['monitor']==1){
						$monitoring = ", ";
					}
				}
				$actions = "'N/A'";
			}elseif($_GET['user']=="sub"){
				$actions = "CONCAT(' <button class=\'btn btn-info\' onclick=\"monitor_user(\'',`user_id`,'\')\">Monitor Clients</button> ','<button class=\'btn btn-warning\' onclick=\"view_profile(\'',`user_id`,'\')\">View</button> ', ' <button class=\'btn btn-success\' onclick=\"edit_user(\'',`user_id`,'\')\">Edit</button> ', ' <button class=\'btn btn-primary\' onclick=\"credit_user(\'',`user_id`,'\')\">Credit</button> ', ' <button class=\'btn btn-danger\' onclick=\"delete_user(\'',`user_id`,'\')\">Delete</button> ') ";
			}
		}else{
			$actions = "'N/A'";
		}


	}elseif($_SESSION['user']['rank']=="Sub Admin"){
		if(isset($_GET['user'])){
			if($_GET['user']=="SubAdmin"){
				$monitoring = "";
				if(isset($_GET['monitor'])){
					if($_GET['monitor']==1){
						$monitoring = ", ";
					}
				}
			}elseif($_GET['user']=="sub"){
				$actions = "CONCAT(' <button class=\'btn btn-info\' onclick=\"monitor_user(\'',`user_id`,'\')\">Monitor Clients</button> ','<button class=\'btn btn-warning\' onclick=\"view_profile(\'',`user_id`,'\')\">View</button> ', ' <button class=\'btn btn-success\' onclick=\"edit_user(\'',`user_id`,'\')\">Edit</button> ', ' <button class=\'btn btn-primary\' onclick=\"credit_user(\'',`user_id`,'\')\">Credit</button> ', ' <button class=\'btn btn-danger\' onclick=\"delete_user(\'',`user_id`,'\')\">Delete</button> ') ";

			}elseif($_GET['user']=="reseller"){
				$actions = "CONCAT(' <button class=\'btn btn-info\' onclick=\"monitor_user(\'',`user_id`,'\')\">Monitor Clients</button> ','<button class=\'btn btn-warning\' onclick=\"view_profile(\'',`user_id`,'\')\">View</button> ', ' <button class=\'btn btn-success\' onclick=\"edit_user(\'',`user_id`,'\')\">Edit</button> ', ' <button class=\'btn btn-primary\' onclick=\"credit_user(\'',`user_id`,'\')\">Credit</button> ', ' <button class=\'btn btn-danger\' onclick=\"delete_user(\'',`user_id`,'\')\">Delete</button> ') ";
			}
		}else{
			$actions = "'N/A'";
		}



	}elseif($_SESSION['user']['rank']=="Sub Reseller"){
		if(isset($_GET['user'])){
			if($_GET['user']=="client"){
				/*
				$monitoring = "";
				if(isset($_GET['monitor'])){
					if($_GET['monitor']==1){
						$monitoring = ", ";
					}
				}
				$actions = "'N/A'";
				
				$actions = "CONCAT(' <button class=\'btn btn-info\' onclick=\"monitor_user(\'',`user_id`,'\')\">Monitor Clients</button> ','<button class=\'btn btn-warning\' onclick=\"view_profile(\'',`user_id`,'\')\">View</button> ', ' <button class=\'btn btn-success\' onclick=\"edit_user(\'',`user_id`,'\')\">Edit</button> ', ' <button class=\'btn btn-primary\' onclick=\"credit_user(\'',`user_id`,'\')\">Credit</button> ', ' <button class=\'btn btn-danger\' onclick=\"delete_user(\'',`user_id`,'\')\">Delete</button> ') ";
				if(isset($_GET['user'],$_GET['upline'])){
					$get_type=" WHERE `is_reseller`=0 AND `upline`=". $db -> escape($_GET['upline']);
				}
				*/
			}
		}else{
			$actions = "'N/A'";
		}
	}
}else{
	$actions="'(Must be logged in)'";
}
$check = 'CONCAT(\'<input data-index="0" name="toolbar1" onclick="checkItem(\',`user_id`,\')" type="checkbox">\')';
//$query="SELECT `user_name`,`full_name`,IF(`is_reseller`=1,'Reseller','Client') as 'type',IF(`vip_duration`>0,'Active','Inactive') as 'status',`payment`,`contact`,(SELECT `full_name` FROM `users` as tb2 WHERE tb2.`user_id`= tb1.`upline`) as 'reseller',$actions as 'action' FROM `users` as tb1 WHERE $get_type";
//$check AS 'state',
$query="SELECT `user_name`,`full_name`,case `is_reseller`    when 0 then 'Client'    when 1 then 'Reseller'   when 2 then 'Sub Reseller'   when 3 then 'Sub Admin'end as 'type',IF(`vip_duration`>0,'Active','Inactive') as 'status',`payment`,`contact`,$actions as 'action',TIME_FORMAT(SEC_TO_TIME(`vip_duration`),'%H hour(s) %i min(s)') as 'dur',`vip_duration`,`credits` FROM `users` as tb1 $get_type ORDER BY `vip_duration`";
//echo $query;
echo json_encode($db -> return_result($query));
?>