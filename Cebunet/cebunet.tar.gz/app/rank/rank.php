<?php

header('Content-Type: application/json');

include_once("../../cfg/db.php");



if(isset($_SESSION['user']['rank'])){
    
    $profile_info = $db -> select_row("SELECT * FROM `users` WHERE `user_id`=$get_id");

	if($_SESSION['user']['rank']=="Admin" || $profile_info[0]['is_admin']==1){

		$query="SELECT `user_id`,`user_name`,`full_name`,

		(SELECT COUNT(*) FROM `users` as usr2 WHERE `upline`=usr1.`user_id` AND year(usr2.`regdate`)=year(NOW()) AND month(usr2.`regdate`)=month(NOW())) AS `referral`,

		(SELECT COUNT(vc2.`code_name`) FROM `vouchers` AS vc2 WHERE `reseller_id`= usr1.`user_id` AND MONTH(`time_stamp`) = MONTH(NOW())) AS 'generatedmonth',

		(SELECT COUNT(vc2.`code_name`) FROM `vouchers` AS vc2 WHERE `reseller_id`= usr1.`user_id` AND MONTH(`time_stamp`) = MONTH(NOW()) AND `is_used`=1) usedmonth,

		(SELECT COUNT(vc2.`code_name`) FROM `vouchers` AS vc2 WHERE `reseller_id`= usr1.`user_id` AND `is_used`=0) AS 'unused',

		`credits` FROM `users` as usr1 WHERE usr1.`is_reseller`=1 ORDER BY usedmonth ASC LIMIT 50";

		//echo $query;

		echo json_encode($db -> return_result($query));

	}

}else{

	$actions="'(Must be logged in)'";

}



?>