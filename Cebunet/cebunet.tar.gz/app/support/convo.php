<?php
header('Content-Type: application/json');
include_once("../../cfg/db.php");
$query="SELECT null";
$qry="";
if(isset($_SESSION['user']['id'])){
	if(isset($_GET['id'])){
		$user_id = $db->escape($_GET['id']);
		if($user_id <> ""){
			$query="SELECT id,(SELECT `user_name` FROM `users` WHERE `user_id`= A.`user_id_from`) as 'from',(SELECT `user_name` FROM `users` WHERE `user_id`= A.`user_id_to`) AS 'to',(SELECT `full_name` FROM `users` WHERE `user_id`= A.`user_id_from`) AS 'name',`content`,`timestamp`,`user_id_from`,`user_id_to` FROM `messages` AS A WHERE (A.`user_id_from`=".$user_id." AND A.`user_id_to`=1) OR (A.`user_id_from`=1 AND A.`user_id_to`=".$user_id.") ORDER BY `timestamp` ASC";
			//$query="SELECT * FROM `messages` WHERE (`user_id_from`=".$user_id." AND `user_id_to`=".$_SESSION['user']['id'] .") OR (`user_id_from`=".$_SESSION['user']['id']." AND `user_id_to`=".$user_id.") ORDER BY `timestamp` ASC";
			if($_SESSION['user']['id']==1){
				$qry="UPDATE `messages` SET `is_unread`=0 WHERE `user_id_to`=".$_SESSION['user']['id']." AND `user_id_from`=$user_id";
			}else{
				$qry="UPDATE `messages` SET `is_unread`=0 WHERE `user_id_to`=".$_SESSION['user']['id']." AND `user_id_from`=1";
			}
			$db -> sql_query($qry);
		}
	}
}
//echo $qry;
echo json_encode($db -> return_result($query));
?>