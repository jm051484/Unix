<?php
header('Content-Type: application/json');
include_once("../../cfg/db.php");
$return_arr["status"]=0;
if(isset($_SESSION['user'])){
	if(isset($_POST['code_name'])){
		$post_code_name = $db -> escape($_POST['code_name']);
		if($db -> select("SELECT COUNT(*) FROM `vouchers` WHERE `code_name`='$post_code_name'") ==1 && $db -> select("SELECT `is_used` FROM `vouchers` WHERE `code_name`='$post_code_name'")==0){
			$add_duration = $db -> select("SELECT `duration` FROM `vouchers` WHERE `code_name` = '$post_code_name'");
			
			$target = $_SESSION['user']['id'];
			if($_POST['custom']<>0){
				$target = $db -> escape($_POST['client']);
			}
			
			$db -> sql_query("UPDATE `users` SET `duration` = (`duration`+$add_duration) WHERE `user_id`=".$target);
			$db -> sql_query("UPDATE `vouchers` SET `is_used` = 1,`date_used`=NOW(),`user_id`=".$target." WHERE`code_name` = '$post_code_name'");
				
			$return_arr["status"]=1;
			$return_arr["message"]=" Top Up Successful.";
		}else{
			$return_arr["status"]=0;
			$return_arr["message"]=" Invalid Voucher.";
		}
	}
}else{
	$return_arr["status"]=0;
	$return_arr["message"]=" Unauthorized Action.";
}
echo json_encode($return_arr);
?>