<?php
header('Content-Type: application/json');
include_once("../../cfg/db.php");

if(isset($_SESSION['user'])){


    $used="<span class=\"label bg-green\">Used</span>";
    $notused="<span class=\"label bg-red\">Not Used</span>";

    if($_SESSION['user']['rank']=="Admin" && $_SESSION['user']['id']==1){
        $query="SELECT `code_name`,IF(`is_used`=1,'$used','$notused') as 'is_used',IF(`date_used`='','-',`date_used`) as 'date_used',`time_stamp` ,CONCAT(FLOOR(`duration`/86400),' day(s) ',sec_to_time(`duration`)) as 'duration',(SELECT `full_name` FROM `users` as tb2 WHERE tb2.`user_id`= tb1.`reseller_id`) as 'reseller', IF(`user_id`=0,'-',(SELECT `full_name` FROM `users` as tb2 WHERE tb2.`user_id`= tb1.`user_id`)) as 'client' FROM `vouchers` as tb1";
    }elseif($_SESSION['user']['rank']=="Reseller" || $_SESSION['user']['rank']=="Sub Reseller" || $_SESSION['user']['rank']=="Sub Admin") {
        $query = "SELECT `code_name`,IF(`is_used`=1,'Yes','No') as 'is_used',IF(`date_used`='','-',`date_used`) as 'date_used',`time_stamp` ,CONCAT(FLOOR(`duration`/86400),' day(s) ',sec_to_time(`duration`)) as 'duration',(SELECT `full_name` FROM `users` as tb2 WHERE tb2.`user_id`= tb1.`reseller_id`) as 'reseller', IF(`user_id`=0,'-',(SELECT `full_name` FROM `users` as tb2 WHERE tb2.`user_id`= tb1.`user_id`)) as 'client' FROM `vouchers` as tb1 WHERE `user_id`=" . $_SESSION['user']['id'] . " OR `reseller_id`=" . $_SESSION['user']['id'];
    }else{
        $query="SELECT `code_name`,IF(`is_used`=1,'Yes','No') as 'is_used',IF(`date_used`='','-',`date_used`) as 'date_used',`time_stamp` ,CONCAT(FLOOR(`duration`/86400),' day(s) ',sec_to_time(`duration`)) as 'duration',(SELECT `full_name` FROM `users` as tb2 WHERE tb2.`user_id`= tb1.`reseller_id`) as 'reseller', IF(`user_id`=0,'-',(SELECT `full_name` FROM `users` as tb2 WHERE tb2.`user_id`= tb1.`user_id`)) as 'client' FROM `vouchers` as tb1 WHERE `user_id`=" . $_SESSION['user']['id'];
    }

}else{
    $return_arr["message"]=" Unauthorized Action.";
}

echo json_encode($db -> return_result($query));
?>