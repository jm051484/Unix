<?php
header('Content-Type: application/json');
include_once("../../cfg/db.php");
$return_arr["code"]="";
$return_arr["status"]=0;
if(isset($_SESSION['user'])){
	if($_SESSION['user']['rank']=="Reseller" || $_SESSION['user']['rank']=="Admin" || $_SESSION['user']['rank']=="Sub Admin" || $_SESSION['user']['rank']=="Sub Reseller"){
		if($db -> select("SELECT `credits` FROM `users` WHERE `user_id`={$_SESSION['user']['id']}") > 0){
			
			$code1 = $db -> ran_code(2);
			sleep(3);
			$code2= '-' .$db -> ran_code(3);
			sleep(3);
			$code3= '-' .$db -> ran_code(2);
			sleep(3);
			$code4= '-' .$db -> ran_code(3);
			$code=$code1.$code2.$code3.$code4;
			
			$duration ="2592000";
			
			if($_POST['custom']==1){
				$duration= ($_POST['days'] * 86400) + (($_POST['hours'] * 3600)) + (($_POST['minutes'] * 60));
			}
			if($duration==0){
				$return_arr["code"]="";
				$return_arr["status"]=0;
				$return_arr["message"]=" Error, duration can't be 0.";
				echo json_encode($return_arr);
				exit();
			}
			
			$db -> sql_query("INSERT INTO `vouchers`(`code_name`,`user_id`,`reseller_id`,`is_used`,`duration`,`time_stamp`) VALUES('$code',0,{$_SESSION['user']['id']},0,$duration,NOW())");
			$db -> sql_query("UPDATE `users` SET `credits`=(`credits`-1) WHERE `user_id`={$_SESSION['user']['id']}");
			
			//$query="SELECT `code_name`,IF(`is_used`=1,'Yes','No') as 'is_used',IF(`date_used`='','-',`date_used`) as 'date_used',`time_stamp` ,sec_to_time(`duration`),(SELECT `full_name` FROM `users` as tb2 WHERE tb2.`user_id`= tb1.`reseller_id`) as 'reseller', IF(`user_id`=0,'-',(SELECT `full_name` FROM `users` as tb2 WHERE tb2.`user_id`= tb1.`user_id`)) as 'client' FROM `vouchers` as tb1 WHERE `user_id`=".$_SESSION['user']['id'] . " OR `reseller_id`=".$_SESSION['user']['id'] ;
			$return_arr["code"]=$code;
			$return_arr["status"]=1;
			$return_arr["message"]=" Voucher Generated.";
		}else{
			$return_arr["code"]="";
			$return_arr["status"]=0;
			$return_arr["message"]=" Insuficient Credits.";
		}
	}
	
}else{
	$return_arr["code"]="";
	$return_arr["status"]=0;
	$return_arr["message"]=" Unauthorized Action.";
}

echo json_encode($return_arr);
?>