<?php
include_once("../../cfg/db.php");
$return_arr["status"]=0;
$return_arr["message"]=" No Action.";
//if(isset($_SESSION['user'])){
	if(isset($_POST['full_name'],$_POST['email'],$_POST['location'],$_POST['payment'],$_POST['contact'],$_POST['username'],$_POST['password'],$_POST['password_two'])){
		$post_full_name = $db -> escape($_POST['full_name']);
		$post_email = $db -> escape($_POST['email']);
		$post_location = $db -> escape($_POST['location']);
		$post_payment = $db -> escape($_POST['payment']);
		$post_contact = $db -> escape($_POST['contact']);
		$post_username =$db -> escape($_POST['username']);
		$post_password =$db -> escape($_POST['password']);
		$post_password_two =$db -> escape($_POST['password_two']);
		
		$set_type="0";
		$set_type2="";
		if(isset($_SESSION['user'])){
			if($_SESSION['user']['rank']=="Admin"){
				if(isset($_POST['type'])){
					if($_POST['type']==1){
						$set_type="1";
						$set_type2="Reseller";
					}else{
						$set_type="0";
						$set_type2="Client";
					}
				}
			}
			if($_SESSION['user']['rank'] == "Reseller"|| $_SESSION['user']['rank']=="Admin" || $_SESSION['user']['rank'] == "Sub Reseller" || $_SESSION['user']['rank'] == "Sub Admin"){
				if($post_password == $post_password_two){
				$query="INSERT INTO `users`(`full_name`,`user_email`,`location`,`payment`,`contact`,`user_pass`,`user_name`,`is_reseller`,`upline`,`duration`,`vip_duration`,`is_vip`,`is_validated`,`is_active`,`regdate`,`is_admin`,`is_connected`) VALUES('$post_full_name','$post_email','$post_location','$post_payment','$post_contact','$post_password','$post_username',$set_type,".$_SESSION['user']['id'].",7200,3600,1,1,1,NOW(),0,0)";
				//echo $query;
					if($db -> select("SELECT COUNT(*) FROM `users` WHERE `user_name`='$post_username'") == 0){
						$db -> sql_query($query);
						$return_arr["status"]=1;
						$return_arr["message"]=" User Account Created Successfully.";
					}else{
						$return_arr["status"]=0;
						$return_arr["message"]=" Username Already Exists.";
					}
				}else{
					$return_arr["status"]=0;
					$return_arr["message"]=" Password Confirm Mismatched.";
				}
			}
		}else{
			if($post_password == $post_password_two){
				$query="INSERT INTO `users`(`full_name`,`user_email`,`location`,`payment`,`contact`,`user_pass`,`user_name`,`is_reseller`,`upline`,`duration`,`is_validated`,`is_active`,`regdate`,`is_admin`,`is_connected`) VALUES('$post_full_name','$post_email','$post_location','$post_payment','$post_contact','$post_password','$post_username',$set_type,1,0,1,1,NOW()),0,0";
				//echo $query;
				if($db -> select("SELECT COUNT(*) FROM `users` WHERE `user_name`='$post_username'") == 0){
					$db -> sql_query($query);
					$return_arr["status"]=1;
					$return_arr["message"]=" User Created.";
				}else{
					$return_arr["status"]=0;
					$return_arr["message"]=" Username Already Exists.";
				}
			}else{
				$return_arr["status"]=0;
				$return_arr["message"]=" Password Confirm Mismatched.";
			}
		}
	
	}else{
		$return_arr["status"]=0;
		$return_arr["message"]=" Invalid Request. Please try again.";
	}
//}else{
//	$return_arr["message"]=" Unauthorized Action.";
//}
//$return_arr["message"] = $get_uid;
echo json_encode($return_arr);
?>