<?php
include_once("../../cfg/db.php");
$return_arr["status"]=0;
$return_arr["message"]=" No Action.";
if(isset($_SESSION['user'])){
	if(isset($_POST['current'],$_POST['password'],$_POST['password_two'])){	
		$post_current = $db -> escape($_POST['current']);
		$post_password = $db -> escape($_POST['password']);
		$post_password_two = $db -> escape($_POST['password_two']);
		$post_user_id =$db -> escape($_POST['user_id']);
		$data_password = $db -> select("SELECT `user_pass` FROM `users` WHERE `user_id` = ".$post_user_id);
		if($post_current == $data_password || $db -> select("SELECT `upline` FROM `users` WHERE `user_id`=".$post_user_id) == $_SESSION['user']['id'] || $_SESSION['user']['rank']=="Admin"){
			if($post_password == $post_password_two){
				if($_SESSION['user']['id'] == $post_user_id || $db -> select("SELECT `upline` FROM `users` WHERE `user_id`=".$post_user_id) == $_SESSION['user']['id'] || $_SESSION['user']['rank']=="Admin"){
					$db -> sql_query("UPDATE `users` SET `user_pass`='$post_password' WHERE `user_id` = ".$post_user_id);
					$return_arr["status"]=1;
					$return_arr["message"]=" Password Updated.";
				}else{
					$return_arr["status"]=0;
					$return_arr["message"]=" Unauthorized Action.";
				}
			}else{
				$return_arr["status"]=0;
				$return_arr["message"]=" Password Confirm Mismatched.";
			}
		}else{
			$return_arr["status"]=0;
			$return_arr["message"]=" Invalid Password. Please enter your current password.";
		}
	}else{
		$return_arr["status"]=0;
		$return_arr["message"]=" Invalid Request. Please try again.";
	}
}else{
	$return_arr["message"]=" Unauthorized Action.";
}
//$return_arr["message"] = $get_uid;
echo json_encode($return_arr);
?>