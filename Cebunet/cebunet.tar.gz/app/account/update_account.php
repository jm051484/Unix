<?php

include_once("../../cfg/db.php");

$return_arr["status"]=0;

$return_arr["message"]=" No Action.";

if(isset($_SESSION['user'])){

	if(isset($_POST['full_name'],$_POST['email'],$_POST['location'],$_POST['payment'],$_POST['contact'],$_POST['user_id'])){

		$post_full_name = $db -> escape($_POST['full_name']);

		$post_email = $db -> escape($_POST['email']);

		$post_location = $db -> escape($_POST['location']);

		$post_payment = $db -> escape($_POST['payment']);

		$post_contact = $db -> escape($_POST['contact']);

		$post_user_id =$db -> escape($_POST['user_id']);

		

		$set_type="";
		$set_type2="";

		$frozen = "";

		

		if($_SESSION['user']['rank']=="Admin"){

			if(isset($_POST['type'])){

				if($_POST['type']==1){

					$set_type=", `is_reseller`=1 ";
					$set_type2=", `user_rank`='Reseller' ";

				}elseif($_POST['type']==2){

					$set_type=", `is_reseller`=2 ";
					$set_type2=", `user_rank`='Sub Reseller' ";

				}elseif($_POST['type']==3){

					$set_type=", `is_reseller`=3 ";
					$set_type2=", `user_rank`='Sub Admin' ";

				}elseif($_POST['type']==4){

					$set_type=", `is_reseller`=9 ";
					$set_type2=", `user_rank`='Admin' ";

				}else{

					$set_type=", `is_reseller`=0";
					$set_type2=", `user_rank`='Client' ";

				}

			}

			if(isset($_POST['frozen'])){

				if($_POST['frozen']==0){

					$frozen=", `frozen`=0 ";

				}else{

					$frozen=", `frozen`=1 ";

				}

			}

			if(isset($_POST['is_vip'])){

				if($_POST['is_vip']==0){

					$frozen=", `is_vip`=0 ";

				}else{

					$frozen=", `is_vip`=1 ";

				}

			}

		}

				if($_SESSION['user']['rank']=="Sub Admin"){

			if(isset($_POST['type'])){

				if($_POST['type']==1){

					$set_type=", `is_reseller`=1 ";
					$set_type2=", `user_rank`='Reseller' ";

				}elseif($_POST['type']==2){

					$set_type=", `is_reseller`=2 ";
					$set_type2=", `user_rank`='Sub Reseller' ";

						    }elseif($_POST['type']==3){

					$set_type=", `is_reseller`=3 ";
					$set_type2=", `user_rank`='Sub Admin' ";

				}else{

					$set_type=", `is_reseller`=0 ";
					$set_type2=", `user_rank`='Client' ";

				}

			}

			

			if(isset($_POST['frozen'])){

				if($_POST['frozen']==0){

					$frozen=", `frozen`=0 ";

				}else{

					$frozen=", `frozen`=1 ";

				}

			}

			if(isset($_POST['is_vip'])){

				if($_POST['is_vip']==0){

					$frozen=", `is_vip`=0 ";

				}else{

					$frozen=", `is_vip`=1 ";

				}

			}

		}

		if($_SESSION['user']['rank']=="Reseller"){

			if(isset($_POST['type'])){

				if($_POST['type']==2){

					$set_type=", `is_reseller`=2 ";
					$set_type2=", `user_rank`='Sub Reseller' ";

				}else{

					$set_type=", `is_reseller`=0 ";
					$set_type2=", `user_rank`='Client' ";

				}

			}

			

			if(isset($_POST['frozen'])){

				if($_POST['frozen']==0){

					$frozen=", `frozen`=0 ";

				}else{

					$frozen=", `frozen`=1 ";

				}

			}

			if(isset($_POST['is_vip'])){

				if($_POST['is_vip']==0){

					$frozen=", `is_vip`=0 ";

				}else{

					$frozen=", `is_vip`=1 ";

				}

			}

		}

		if($_SESSION['user']['id'] == $post_user_id || $db -> select("SELECT `upline` FROM `users` WHERE `user_id`=".$post_user_id) == $_SESSION['user']['id'] || $_SESSION['user']['rank']=="Admin"){

			$db -> sql_query("UPDATE `users` SET `full_name`='$post_full_name',`user_email`='$post_email',`location`='$post_location',`payment`='$post_payment',`contact`='$post_contact' $set_type $set_type2 $frozen WHERE `user_id` = ".$post_user_id);

			$return_arr["status"]=1;

			$return_arr["message"]=" Profile Updated";

			$return_arr["query"]="UPDATE `users` SET `full_name`='$post_full_name',`user_email`='$post_email',`location`='$post_location',`payment`='$post_payment',`contact`='$post_contact' $set_type $set_type2 $frozen WHERE `user_id` = ".$post_user_id;

		}else{

			$return_arr["status"]=0;

			$return_arr["message"]=" Unauthorized Action.";

		}

		

	}else{

		$return_arr["status"]=0;

		$return_arr["message"]=" Invalid Request. Please try again.";

	}

}else{

	$return_arr["message"]=" Unauthorized Action.";

}

//$return_arr["message"] = $get_uid;

echo json_encode($return_arr);

?>