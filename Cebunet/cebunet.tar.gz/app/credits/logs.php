<?php
header('Content-Type: application/json');
include_once("../../cfg/db.php");


if(isset($_SESSION['user'])){
    if($_SESSION['user']['id']==1)
    {
    if($_SESSION['user']['rank']=="Admin" && $_SESSION['user']['id']==1){
        $query="SELECT `log_id` as 'id',`time_stamp` as 'time_stamp',`credits_used` as 'credits',`user` as 'receiver', `seller` as 'reseller' FROM `credits` as tb1 ORDER BY `time_stamp`" ;
    }
    }
}else{
    $return_arr["message"]=" Unauthorized Action.";
    echo "You are unauthorized to view this page ☺";
}


echo json_encode($db -> return_result($query));
?>