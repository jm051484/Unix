<?php

include_once("../../cfg/db.php");

$return_arr["status"]=0;

$return_arr["message"]=" No Action.";

if(isset($_SESSION['user'])){

	if($_SESSION['user']['rank']=="Admin"){

		if(isset($_POST['credits'],$_POST['user_id'])){

			$post_credits = $db -> escape($_POST['credits']);

			$post_user_id =$db -> escape($_POST['user_id']);

			

			$current_credits = $db -> select("SELECT `credits` FROM `users` WHERE `user_id`=$post_user_id");

			

			

				if($_SESSION['user']['id'] == $post_user_id || $db -> select("SELECT `upline` FROM `users` WHERE `user_id`=".$post_user_id) == $_SESSION['user']['id'] || $_SESSION['user']['rank']=="Admin"){

					

					if($current_credits <> "" && 0 <= ($current_credits + $post_credits)){

						$db -> sql_query("UPDATE `users` SET `credits`=(`credits`+'$post_credits') WHERE `user_id` = ".$post_user_id);

						$return_arr["status"]=1;

						if($post_credits >=0){

							$return_arr["message"]=" $post_credits Credit(s) Successfully Added.";

						}else{

							$return_arr["message"]=" ".($post_credits *-1)." Credit(s) Successfully Removed.";

						}

					}else{

						$return_arr["status"]=0;

						$return_arr["message"]=" Negative credit total is not allowed. Please check your input.";

					}

				}else{

					$return_arr["status"]=0;

					$return_arr["message"]=" Unauthorized Action.";

				}

			

			

		}else{

			$return_arr["status"]=0;

			$return_arr["message"]=" Invalid Request. Please try again.";

		}

	}elseif($_SESSION['user']['rank']=="Reseller"){

		if(isset($_POST['credits'],$_POST['user_id'])){

			$post_credits = $db -> escape($_POST['credits']);

			$post_user_id =$db -> escape($_POST['user_id']);

			

			$current_credits = $db -> select("SELECT `credits` FROM `users` WHERE `user_id`=$post_user_id");

			

			$resellers_credits = $db -> select("SELECT `credits` FROM `users` WHERE `user_id`=".$_SESSION['user']['id']);

			

				if($db -> select("SELECT `upline` FROM `users` WHERE `user_id`=".$post_user_id) == $_SESSION['user']['id']){

					

					if($resellers_credits >= $post_credits && intval($post_credits) > 0){

						$db -> sql_query("UPDATE `users` SET `credits`=(`credits`+'$post_credits') WHERE `user_id` = ".$post_user_id);

						$db -> sql_query("UPDATE `users` SET `credits`=(`credits`-'$post_credits') WHERE `user_id` = ".$_SESSION['user']['id']);

						

						$resellers_credits = $db -> select("SELECT `credits` FROM `users` WHERE `user_id`=".$_SESSION['user']['id']);

						$return_arr["status"]=1;

						if($post_credits >=0){

							$return_arr["message"]=" $post_credits Credit(s) Transferred. Your credit is now $resellers_credits.";

						}

					}else{

						$return_arr["status"]=0;

						$return_arr["message"]=" Invalid / Insuficient Credits.";

					}

				}else{

					$return_arr["status"]=0;

					$return_arr["message"]=" Invalid Action.";

				}

			

			

		}else{

			$return_arr["status"]=0;

			$return_arr["message"]=" Invalid Request. Please try again.";

		}

			}elseif($_SESSION['user']['rank']=="Sub Admin"){

		if(isset($_POST['credits'],$_POST['user_id'])){

			$post_credits = $db -> escape($_POST['credits']);

			$post_user_id =$db -> escape($_POST['user_id']);

			

			$current_credits = $db -> select("SELECT `credits` FROM `users` WHERE `user_id`=$post_user_id");

			

			$resellers_credits = $db -> select("SELECT `credits` FROM `users` WHERE `user_id`=".$_SESSION['user']['id']);

			

				if($db -> select("SELECT `upline` FROM `users` WHERE `user_id`=".$post_user_id) == $_SESSION['user']['id']){

					

					if($resellers_credits >= $post_credits && intval($post_credits) > 0){

						$db -> sql_query("UPDATE `users` SET `credits`=(`credits`+'$post_credits') WHERE `user_id` = ".$post_user_id);

						$db -> sql_query("UPDATE `users` SET `credits`=(`credits`-'$post_credits') WHERE `user_id` = ".$_SESSION['user']['id']);

						

						$resellers_credits = $db -> select("SELECT `credits` FROM `users` WHERE `user_id`=".$_SESSION['user']['id']);

						$return_arr["status"]=1;

						if($post_credits >=0){

							$return_arr["message"]=" $post_credits Credit(s) Transferred. Your credit is now $resellers_credits.";

						}

					}else{

						$return_arr["status"]=0;

						$return_arr["message"]=" Invalid / Insuficient Credits.";

					}

				}else{

					$return_arr["status"]=0;

					$return_arr["message"]=" Invalid Action.";

				}

			

			

		}else{

			$return_arr["status"]=0;

			$return_arr["message"]=" Invalid Request. Please try again.";

		}

	}else{

		$return_arr["status"]=0;

		$return_arr["message"]=" Unauthorized Action.";

	}

}else{

	$return_arr["message"]=" Unauthorized Action.";

}


if ($_POST['credits']){


    $post_user_name=$db->select("SELECT `user_name` FROM `users` WHERE `user_id`=$post_user_id");
    $post_seller_name=$db->select("SELECT `user_name` FROM `users` WHERE `user_id`=".$_SESSION['user']['id']);

    $db -> sql_query("INSERT INTO credits(user_id,reseller_id,time_stamp,credits_used,user,seller) VALUES ('$post_user_id','{$_SESSION['user']['id']}',NOW(),'$post_credits','$post_user_name','$post_seller_name')");
}


//$return_arr["message"] = $get_uid;

echo json_encode($return_arr);

?>