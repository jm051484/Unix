<?php
header('Content-Type: application/json');
include_once("../../cfg/db.php");


if(isset($_SESSION['user'])){
    if($_SESSION['user']['rank']=="Admin"){

        $premium="<span class=\"label bg-red\">Expired</span>";
        $vip="<span class=\"label bg-red\">Expired</span>";

        $query="SELECT `full_name` as 'fullname',`user_name` as 'user',case `is_vip` when 0 then '$premium' when 1 then '$vip' end as 'subscription' FROM `users` as tb1 WHERE `duration`=0" ;
    }else{
        $query="SELECT `full_name` as 'fullname',`time_stamp` as 'time_stamp',`credits_used` as 'credits',`user` as 'receiver', `seller` as 'reseller' FROM `credits` as tb1" ;
    }

}else{
    $return_arr["message"]=" Unauthorized Action.";
}


echo json_encode($db -> return_result($query));
?>