<?php
header('Content-Type: application/json');
include_once("../../cfg/db.php");

$get_type="";
$actions="'N/A'";


function secondsToTime($seconds) {
    $dtF = new \DateTime('@0');
    $dtT = new \DateTime("@$seconds");
    return $dtF->diff($dtT)->format('%a day(s), %h hour(s), %i minute(s)');
}

if(isset($_GET['user'])){
    switch($_GET['user']){
        case "reseller":
            if($_SESSION['user']['id']==1){
                $get_type=" WHERE `is_reseller`=1";
            }else{
                $get_type=" WHERE `is_reseller`=1 and upline='".$_SESSION['user']['id']."'";
            }
            $actions = "CONCAT('<button class=\'btn btn-warning\' onclick=\"view_profile(\'',`user_id`,'\')\">View</button>')";
            break;
        case "subadmin":
            $get_type=" WHERE `is_reseller`=3 ";
            $actions = "CONCAT('<button class=\'btn btn-warning\' onclick=\"view_profile(\'',`user_id`,'\')\">View</button>')";
            break;
        case "sub":
            if(isset($_SESSION['user'])){
                if($_SESSION['user']['rank']=="Reseller"){
                    $get_type=" WHERE `is_reseller`=2 and upline='".$_SESSION['user']['id']."'";
                }else{
                    $get_type=" WHERE `is_reseller`=2 ";
                }
                $actions = "CONCAT('<button class=\'btn btn-warning\' onclick=\"view_profile(\'',`user_id`,'\')\">View</button>')";
                if($_SESSION['user']['rank']=="Reseller" || $_SESSION['user']['rank']=="Sub Admin" || $_SESSION['user']['rank']=="Sub Reseller"){
                    $get_type=$get_type." AND `upline`=" . $_SESSION['user']['id'];
                    $actions = "CONCAT('<button class=\'btn btn-warning\' onclick=\"view_profile(\'',`user_id`,'\')\">View</button> ', ' <button class=\'btn btn-success\' onclick=\"edit_user(\'',`user_id`,'\')\">Edit</button> ', ' <button class=\'btn btn-danger\' onclick=\"delete_user(\'',`user_id`,'\')\">Delete</button> ') ";
                }
            }else{
                $get_type="WHERE `is_reseller`=2 ";
            }

            break;

        case "client":
            $get_type="WHERE `is_reseller`=0";
            if($_SESSION['user']['rank']=="Reseller"){
                $get_type=$get_type." AND `upline`=" . $_SESSION['user']['id'];
                $actions = "CONCAT('<button class=\'btn btn-warning\' onclick=\"view_profile(\'',`user_id`,'\')\">View</button> ', ' <button class=\'btn btn-success\' onclick=\"edit_user(\'',`user_id`,'\')\">Edit</button> ', ' <button class=\'btn btn-danger\' onclick=\"delete_user(\'',`user_id`,'\')\">Delete</button> ') ";
            }
            if($_SESSION['user']['rank']=="Sub Admin"){
                $get_type=$get_type." AND `upline`=" . $_SESSION['user']['id'];
                $actions = "CONCAT('<button class=\'btn btn-warning\' onclick=\"view_profile(\'',`user_id`,'\')\">View</button> ', ' <button class=\'btn btn-success\' onclick=\"edit_user(\'',`user_id`,'\')\">Edit</button> ', ' <button class=\'btn btn-danger\' onclick=\"delete_user(\'',`user_id`,'\')\">Delete</button> ') ";
            }
            if($_SESSION['user']['rank']=="Sub Reseller"){
                $get_type=$get_type." AND `upline`=" . $_SESSION['user']['id'];
                $actions = "CONCAT('<button class=\'btn btn-warning\' onclick=\"view_profile(\'',`user_id`,'\')\">View</button> ', ' <button class=\'btn btn-success\' onclick=\"edit_user(\'',`user_id`,'\')\">Edit</button> ', ' <button class=\'btn btn-danger\' onclick=\"delete_user(\'',`user_id`,'\')\">Delete</button> ') ";
            }
            break;
    }
}


if(isset($_SESSION['user']['rank'])){
    if($_SESSION['user']['rank']=="Admin"){
        if(isset($_GET['user'])){
            if($_GET['user']=="reseller"){
                $monitoring = "";
                if(isset($_GET['monitor'])){
                    if($_GET['monitor']==1){
                        $monitoring = ", ";
                    }
                }
                $actions = "CONCAT(' <button class=\'btn btn-info\' onclick=\"monitor_user(\'',`user_id`,'\')\">Monitor Clients</button> ','<button class=\'btn btn-warning\' onclick=\"view_profile(\'',`user_id`,'\')\">View</button> ', ' <button class=\'btn btn-success\' onclick=\"edit_user(\'',`user_id`,'\')\">Edit</button> ', ' <button class=\'btn btn-primary\' onclick=\"credit_user(\'',`user_id`,'\')\">Credit</button> ', ' <button class=\'btn btn-danger\' onclick=\"delete_user(\'',`user_id`,'\')\">Delete</button> ') ";

            }elseif($_GET['user']=="sub"){
                $actions = "CONCAT(' <button class=\'btn btn-info\' onclick=\"monitor_user(\'',`user_id`,'\')\">Monitor Clients</button> ','<button class=\'btn btn-warning\' onclick=\"view_profile(\'',`user_id`,'\')\">View</button> ', ' <button class=\'btn btn-success\' onclick=\"edit_user(\'',`user_id`,'\')\">Edit</button> ', ' <button class=\'btn btn-primary\' onclick=\"credit_user(\'',`user_id`,'\')\">Credit</button> ', ' <button class=\'btn btn-danger\' onclick=\"delete_user(\'',`user_id`,'\')\">Delete</button> ') ";
            }elseif($_GET['user']=="subadmin"){
                $actions = "CONCAT(' <button class=\'btn btn-info\' onclick=\"monitor_user(\'',`user_id`,'\')\">Monitor Clients</button> ','<button class=\'btn btn-warning\' onclick=\"view_profile(\'',`user_id`,'\')\">View</button> ', ' <button class=\'btn btn-success\' onclick=\"edit_user(\'',`user_id`,'\')\">Edit</button> ', ' <button class=\'btn btn-primary\' onclick=\"credit_user(\'',`user_id`,'\')\">Credit</button> ', ' <button class=\'btn btn-danger\' onclick=\"delete_user(\'',`user_id`,'\')\">Delete</button> ') ";
            }else{

                $actions = "CONCAT('<button class=\'btn btn-warning\' onclick=\"view_profile(\'',`user_id`,'\')\">View</button> ', ' <button class=\'btn btn-success\' onclick=\"edit_user(\'',`user_id`,'\')\">Edit</button> ', ' <button class=\'btn btn-danger\' onclick=\"delete_user(\'',`user_id`,'\')\">Delete</button> ') ";
                if(isset($_GET['user'],$_GET['upline'])){
                    $get_type="WHERE `is_reseller`=0 AND `upline`=". $db -> escape($_GET['upline']);
                }
            }
        } else {
            $actions = "CONCAT(' <button class=\'btn btn-info\' onclick=\"monitor_user(\'',`user_id`,'\')\">Monitor Clients</button> ','<button class=\'btn btn-warning\' onclick=\"view_profile(\'',`user_id`,'\')\">View Profile</button> ', ' <button class=\'btn btn-success\' onclick=\"edit_user(\'',`user_id`,'\')\">Edit</button> ', ' <button class=\'btn btn-primary\' onclick=\"credit_user(\'',`user_id`,'\')\">Credit</button> ', ' <button class=\'btn btn-danger\' onclick=\"delete_user(\'',`user_id`,'\')\">Delete</button> ') ";
        }

    }elseif($_SESSION['user']['rank']=="Reseller"){
        if(isset($_GET['user'])){
            if($_GET['user']=="reseller"){
                $monitoring = "";
                if(isset($_GET['monitor'])){
                    if($_GET['monitor']==1){
                        $monitoring = ", ";
                    }
                }
                $actions = "'N/A'";
            }elseif($_GET['user']=="sub"){
                $actions = "CONCAT(' <button class=\'btn btn-info\' onclick=\"monitor_user(\'',`user_id`,'\')\">Monitor Clients</button> ','<button class=\'btn btn-warning\' onclick=\"view_profile(\'',`user_id`,'\')\">View</button> ', ' <button class=\'btn btn-success\' onclick=\"edit_user(\'',`user_id`,'\')\">Edit</button> ', ' <button class=\'btn btn-primary\' onclick=\"credit_user(\'',`user_id`,'\')\">Credit</button> ', ' <button class=\'btn btn-danger\' onclick=\"delete_user(\'',`user_id`,'\')\">Delete</button> ') ";
            }
        }else{
            $actions = "'N/A'";
        }


    }elseif($_SESSION['user']['rank']=="Sub Admin"){
        if(isset($_GET['user'])){
            if($_GET['user']=="SubAdmin"){
                $monitoring = "";
                if(isset($_GET['monitor'])){
                    if($_GET['monitor']==1){
                        $monitoring = ", ";
                    }
                }
            }elseif($_GET['user']=="sub"){
                $actions = "CONCAT(' <button class=\'btn btn-info\' onclick=\"monitor_user(\'',`user_id`,'\')\">Monitor Clients</button> ','<button class=\'btn btn-warning\' onclick=\"view_profile(\'',`user_id`,'\')\">View</button> ', ' <button class=\'btn btn-success\' onclick=\"edit_user(\'',`user_id`,'\')\">Edit</button> ', ' <button class=\'btn btn-primary\' onclick=\"credit_user(\'',`user_id`,'\')\">Credit</button> ', ' <button class=\'btn btn-danger\' onclick=\"delete_user(\'',`user_id`,'\')\">Delete</button> ') ";

            }elseif($_GET['user']=="reseller"){
                $actions = "CONCAT(' <button class=\'btn btn-info\' onclick=\"monitor_user(\'',`user_id`,'\')\">Monitor Clients</button> ','<button class=\'btn btn-warning\' onclick=\"view_profile(\'',`user_id`,'\')\">View</button> ', ' <button class=\'btn btn-success\' onclick=\"edit_user(\'',`user_id`,'\')\">Edit</button> ', ' <button class=\'btn btn-primary\' onclick=\"credit_user(\'',`user_id`,'\')\">Credit</button> ', ' <button class=\'btn btn-danger\' onclick=\"delete_user(\'',`user_id`,'\')\">Delete</button> ') ";
            }
        }else{
            $actions = "'N/A'";
        }



    }elseif($_SESSION['user']['rank']=="Sub Reseller"){
        if(isset($_GET['user'])){
            if($_GET['user']=="client"){
                /*
                $monitoring = "";
                if(isset($_GET['monitor'])){
                    if($_GET['monitor']==1){
                        $monitoring = ", ";
                    }
                }
                $actions = "'N/A'";

                $actions = "CONCAT(' <button class=\'btn btn-info\' onclick=\"monitor_user(\'',`user_id`,'\')\">Monitor Clients</button> ','<button class=\'btn btn-warning\' onclick=\"view_profile(\'',`user_id`,'\')\">View</button> ', ' <button class=\'btn btn-success\' onclick=\"edit_user(\'',`user_id`,'\')\">Edit</button> ', ' <button class=\'btn btn-primary\' onclick=\"credit_user(\'',`user_id`,'\')\">Credit</button> ', ' <button class=\'btn btn-danger\' onclick=\"delete_user(\'',`user_id`,'\')\">Delete</button> ') ";
                if(isset($_GET['user'],$_GET['upline'])){
                    $get_type=" WHERE `is_reseller`=0 AND `upline`=". $db -> escape($_GET['upline']);
                }
                */
            }
        }else{
            $actions = "'N/A'";
        }
    }
}else{
    $actions="'(Must be logged in)'";
}
$check = 'CONCAT(\'<input data-index="0" name="toolbar1" onclick="checkItem(\',`user_id`,\')" type="checkbox">\')';
//$query="SELECT `user_name`,`full_name`,IF(`is_reseller`=1,'Reseller','Client') as 'type',IF(`duration`>0,'Active','Inactive') as 'status',`payment`,`contact`,(SELECT `full_name` FROM `users` as tb2 WHERE tb2.`user_id`= tb1.`upline`) as 'reseller',$actions as 'action' FROM `users` as tb1 WHERE $get_type";
//$check AS 'state',
$connected="<span class=\"label bg-green\">Connected</span>";
$disconnected="<span class=\"label bg-red\">Disconnected</span>";
$premium="<span class=\"label bg-green\">Premium</span>";
$vip="<span class=\"label bg-red\">VIP</span> <span class=\"label bg-green\">Premium</span>";

if($_SESSION['user']['id']==1){

}else{
if ($get_type == " " or $get_type == ""){
    $get_type="WHERE `user_id` > 1";
} else {
    $get_type = $get_type." AND `user_id` > 1";
}
}

$query = "
SELECT `user_name`,
       `full_name`,
       CASE `is_reseller`
           WHEN 9 THEN 'Admin'
           WHEN 0 THEN 'Client'
           WHEN 1 THEN 'Reseller'
           WHEN 2 THEN 'Sub Reseller'
           WHEN 3 THEN 'Sub Admin'
       END AS 'type',
       CASE `is_active`
           WHEN 0 THEN '$connected'
           WHEN 1 THEN '$disconnected'
       END AS 'stats',
       CASE `is_vip`
           WHEN 0 THEN '$premium'
           WHEN 1 THEN '$vip'
       END AS 'subscription',
       $actions AS 'action',
       `duration` AS 'dur', `duration`,
       `vip_duration` AS 'vipdur',
       `vip_duration`,
       `credits`
FROM `users` AS tb1
$get_type
ORDER BY `duration` ";


$datum = $db -> return_result($query);
//echo $query;
//print_r($db -> query($query) -> fetch_all());
foreach ($datum as $data => $field) {
    $datum[$data]['dur'] = secondsToTime($datum[$data]['dur']);
    $datum[$data]['vipdur'] = secondsToTime($datum[$data]['vipdur']);
}
echo json_encode($datum);