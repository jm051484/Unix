<?php
header('Content-Type: application/json');
include_once("../../cfg/db.php");

$get_type="";
$actions="'N/A'";