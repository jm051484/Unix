<!DOCTYPE html>

<html>



<?php

include('components/header.php');
include('components/bodytop.php');

?>



<?php

include('components/nav.php');

include("components/sidebar.php");



$delete_message="";

$get_type="";

	if($current_rank<>"Admin"){

		header("location: users.php?user=reseller");

	}else{

	}

?>	

	

	<div class="content-wrapper">

        <section class="content-header">
            <h1>
                Ranking
                <small>Reseller Ranking</small>
            </h1>
            <ol class="breadcrumb">
                <li><a href="profile.php"><i class="fa fa-dashboard"></i> Home</a></li>
                <li class="active">Ranking</li>
            </ol>
        </section>

		<?php

		$users = "";

		if(isset($_GET['user'])){

			if($_GET['user']=="reseller"){

				$users="Reseller ";

			}elseif($_GET['user']=="client"){

				$users="Client ";

			}else{

				$users="All ";

			}

		}else{

			$users="All ";

		}

		?>

		<br>

        <div class="content">

		<div class="row">

			<div class="col-lg-12">

				<div class="panel panel-default">

					

					<div class="panel-heading">Resellers List</div>

					<div class="panel-body">

						<table class="table table-bordered table-hover dataTable" data-toggle="table" data-url="app/rank/rank.php"  data-show-refresh="true" data-show-toggle="true" data-show-columns="true" data-search="true" data-select-item-name="toolbar1" data-pagination="false" data-sort-name="name" data-sort-order="desc">

						    <thead>

						    <tr>

						        <!--th data-field="state" data-checkbox="true" >Item ID</th-->

						        <th data-field="user_name" data-sortable="true">Username</th>

						        <th data-field="full_name"  data-sortable="true">Name</th>

						        <th data-field="referral"  data-sortable="true">Clients This Month</th>

								<th data-field="generatedmonth" data-sortable="true">Generated Voucher This Month</th>

						        <th data-field="usedmonth" data-sortable="true">Vouchers Sold This Month</th>

						        <th data-field="unused" data-sortable="true">Remaining Vouchers</th>

						        <th data-field="credits" data-sortable="true">Remaining Credits</th>

						    </tr>

						    </thead>

						</table>

					</div>

				</div>

			</div>

		</div><!--/.row-->	

        </div>

	</div>	<!--/.main-->



<?php 

include("components/js.php");

?>



	<script src="js/bootstrap-table.js"></script>

	<?php
include('components/footer.php');
?>	

</body>

<script>

function view_profile(id){

	window.location="profile.php?user="+id;

}



function edit_user(id){

	window.location="account.php?user="+id;

}





function credit_user(id){

	window.location="credits.php?user="+id;

}



function delete_user(id){

	var r = confirm('Delete User?');

	if (r == true) { 

		window.location="users.php?user=client&id="+id+"&delete=0";

	}

}

setTimeout(function () { <?php echo $delete_message;?>}, 1000);

</script>

</html>

