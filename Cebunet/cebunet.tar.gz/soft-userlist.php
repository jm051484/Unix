<!DOCTYPE html>
<html>

<?php
include('components/header.php');
include('components/bodytop.php');
?>

<div class="wrapper">
<?php
include('components/nav.php');
include("components/sidebar.php");
?>

    <div class="content-wrapper">
        
            <section class="content-header">
                <h1>
                    Users
                    <small>Management</small>
                </h1>
                <ol class="breadcrumb">
                    <li><a href="#"><i class="fa fa-dashboard"></i> Home</a></li>
                    <li class="active">Soft-userlist</li>
                </ol>
            </section>
            
            <div class="content">

            <?php
		$users = "";
		if(isset($_GET['user'])){
			if($_GET['user']=="reseller"){
				$users="Reseller ";
			}elseif($_GET['user']=="client"){
				$users="Client ";
			}elseif($_GET['user']=="sub"){
				$users="Sub Reseller ";
			}elseif($_GET['user']=="subadmin"){
				$users="Sub Admin ";
			} else {
				$users="All ";
			}
		} else {
			$users="All ";
		}
		?>
        <br>
        
      
    
		<div class="row">
			<div class="col-xs-12">
				<div class="box box-primary">
                    <div class="box-header">Softether Users List / <?php echo $users;?></div>
					<div class="box-body table-responsive">
						<table class="table table-bordered table-hover dataTable-responsive" role="grid" data-toggle="table" data-url="app/soft/list.php<?php echo $get_type;?>"  data-show-refresh="true" data-show-toggle="true" data-show-columns="true" data-search="true" data-select-item-name="toolbar1" data-pagination="true" >
						    
						    <div class="alert bg-primary" role="alert" id="error-alert" style="display:none;">

									<span class="glyphicon glyphicon-exclamation-sign"></span><span id="alert-message"> </span></a>

								</div>
						    
						    <thead>
						    <tr>
						        <!--th data-field="state" data-checkbox="true" >Item ID</th-->
						            <th data-field="fullname"  data-sortable="true">Name</th>
						            <th data-field="user" data-sortable="true">Username</th>
						            <th class="text-center" data-field="type" data-sortable="true">Subscription</th>
                                    <th data-field="expiry" data-sortable="true">Expiration Date</th>
                                    <th data-field="actions" data-sortable="true">Action</th>
						    </tr>
						    </thead>
						</table>
					</div>
				</div>
			</div>
		</div><!--/.row-->	
        </div>
	</div>	<!--/.main-->

<?php 
include("components/js.php");
?>

	<script src="js/bootstrap-table.js"></script>

<?php
include('components/footer.php');
?>
    <div class="control-sidebar-bg"></div>
</div>

<div class="modal fade" role="dialog" tabindex="-1" id="showinfo" aria-labelledby="showinfo" aria-hidden="true">
    <div class="modal-dialog">
        <div class="modal-content">
            <div class="modal-header">
                <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                    <span aria-hidden="true">&times;</span></button>
                <h4 class="modal-title">Trial Generator</h4>
            </div>
            <div class="modal-body">
                <data>
                </data>
            </div>
            <div class="modal-footer">
                <button class="btn btn-primary generate-trial">Generate Trial</button>
                <button class="btn btn-warning" data-dismiss="modal">Close</button>
            </div>
        </div>
        <!-- /.modal-content -->
    </div>
    <!-- /.modal-dialog -->
</div>

</body>
<script>

function edit_user(id){
	window.location="account.php?user="+id;
}

function delete_user(id){
	var r = confirm('Are you sure you want to delete this user account? It may take a few seconds.');
	if (r == true) {
	  function remove_alert_bg(){
	    $('#error-alert').removeClass("alert-success");
	    $('#error-alert').removeClass("alert-primary");
	    $('#error-alert').removeClass("alert-danger");
      }

	    remove_alert_bg();
        $('#error-alert').addClass("bg-primary");
        $('#error-alert').fadeIn();
        $('#alert-message').text(" Deleting Account Please Wait...");
         
		$.ajax({
		    beforeSend: function(xhr) {
			    xhr.setRequestHeader("X-AUTH-TOKEN", "<?php echo $_SESSION['user']['token']; ?>")
			},
		    type: 'POST',
		    url: 'https://ayos-vpn.softetherapi.ml/api/1.0/server/delete_user',
		    data: {username: id},
		    success: function (result) {
						if (!result.success) { 
							remove_alert_bg();
							$('#error-alert').addClass("alert-danger");
							$('#alert-message').text(' ' + result.error);
							setTimeout(function () { $('#error-alert').fadeOut()}, 4000);
						}else{
							remove_alert_bg();
							$('#error-alert').addClass("alert-success");
				    		$('#alert-message').text(" " + result.success);
							setTimeout(function () { $('#error-alert').fadeOut()}, 4000);
						}

					}
		    
		})
	}
} 


setTimeout(function () { <?php echo $delete_message;?>}, 1000);
</script>
</html>