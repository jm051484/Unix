<!DOCTYPE html>
<html>

<?php
include('components/header.php');
include('components/bodytop.php');
?>

<div class="wrapper">
<?php
include("components/nav.php");
include("components/sidebar.php");
//$current_uid= $_SESSION['user']['id'];

if(!(isset($_SESSION['user']))){
    header ("Location: login.php");
}

$get_id=0;
if(isset($_GET['user'])){
	$get_id = $db -> escape($_GET['user']);
	if($db -> select("SELECT `user_id` FROM `users` WHERE `user_id`=$get_id") == ""){
		header("location: profile.php");
	}
}else{
	$get_id = $current_uid;
}

	$profile_info = $db -> select_row("SELECT * FROM `users` WHERE `user_id`=$get_id");
	//print_r($profile_info);
	$dur = $db -> calc_time($profile_info[0]['duration']);
	//print_r($dur);
	$premium_duration = $dur['days'] . " day(s), " . $dur['hours'] . " hour(s) and " . $dur['minutes'] . " minute(s)";

$vip_dur = $db -> calc_time($profile_info[0]['vip_duration']);
//print_r($dur);
$vip_duration = $vip_dur['days'] . " day(s), " . $dur['hours'] . " hour(s) and " . $dur['minutes'] . " minute(s)";

$pri_dur = $db -> calc_time($profile_info[0]['vip_duration']);
$pri_duration = $pri_dur['days'] . " day(s), " . $dur['hours'] . " hour(s) and " . $dur['minutes'] . " minute(s)";
	
    $status = $db -> select_row("SELECT is_active FROM `users` WHERE `user_id`=$get_id");

    $date = date_create(date('Y-m-d H:i:s'));
	date_add($date, date_interval_create_from_date_string($profile_info[0]['duration'].' seconds'));
	$expiration = date_format($date, 'm/d')."/".substr(date_format($date, 'Y'),2,2);

	$premium_status="<span class=\"label bg-green\">Active</span>";
	if($profile_info[0]['duration']==0){
		$premium_status="<span class=\"label bg-red\">Inactive</span>";
		$expiration="--";
	}

$vip_status="<span class=\"label bg-green\">Active</span>";
if($profile_info[0]['vip_duration']==0){
    $vip_status="<span class=\"label bg-red\">Inactive</span>";
    $expiration="--";
}


$pri_status="<span class=\"label bg-green\">Active</span>";
if($profile_info[0]['private_duration']==0){
    $pri_status="<span class=\"label bg-red\">Inactive</span>";
    $expiration="--";
}
	
	$con_status="<span class=\"label bg-green\">Connected</span>";
	if($profile_info[0]['is_active']==1){
		$con_status="<span class=\"label bg-red\">Disconnected</span>";
	}
	
	$user_rank="";
	if($profile_info[0]['is_reseller']==1){
		$user_rank="Reseller";
	}elseif($profile_info[0]['is_reseller']==3){
		$user_rank="Sub Admin";		
	}elseif($profile_info[0]['is_reseller']==2){
		$user_rank="SubRS";
	}else{
		$user_rank="Client";
	}
	
	if($profile_info[0]['is_admin']==1){
		$user_rank="Admin";
	}

$users_count = $db -> select("SELECT COUNT(is_validated) AS 'All Users' FROM users WHERE is_validated=1");
$online_count = $db -> select("SELECT COUNT(is_active) AS 'OL Users' FROM users WHERE is_active=0");
$res_count = $db -> select("SELECT COUNT(is_reseller) AS 'Res Users' FROM users WHERE is_reseller=1");
$subad_count = $db -> select("SELECT COUNT(is_reseller) AS 'SubAd Users' FROM users WHERE is_reseller=3");
$clients_count = $db -> select("SELECT COUNT(is_validated) AS 'Clients' FROM users WHERE is_validated=1 AND upline=$get_id");
$active_clients = $db -> select("SELECT COUNT(is_validated) AS 'Active Clients' FROM users WHERE is_validated=1 AND upline=$get_id AND is_active=0");
$my_resellers = $db -> select("SELECT COUNT(is_reseller) AS 'Resellers' FROM users WHERE is_reseller=1 AND upline=$get_id");
$my_subresellers = $db -> select("SELECT COUNT(is_reseller) AS 'Sub Resellers' FROM users WHERE is_reseller=2 AND upline=$get_id");

?>	
	
<div class="content-wrapper">
	<section class="content-header">
      <h1>
        Profile
        <small>Main Profile</small>
      </h1>
      <ol class="breadcrumb">
        <li><a href="#"><i class="fa fa-dashboard active"></i> Dashboard</a></li>
      </ol>
    </section>

    <!-- Main content -->
    <section class="content">
      <!-- Info boxes -->

        <?php

        $notice = $db -> select_row("SELECT `show_info` FROM `message_info`");

        if (($notice[0]['show_info'])==1){
        ?>

            <div class="row">
                <div class="col-xs-12">
                    <div class="alert bg-blue alert-dismissible">
                        <button type="button" class="close" data-dismiss="alert" aria-hidden="true">×</button>
                        <h4><i class="icon fa fa-info"></i> Greetings! <?php echo $current_user; ?></h4>
                        <?php

                        $msgs = $db -> select_row("SELECT `info` FROM `message_info`");
                        echo $msgs[0]['info'];

                        ?>
                    </div>
                </div>
            </div>
            <!-- /.row -->

        <?php }
        else{

        }?>
        
        
        <!-- USER PANEL STATUS -->
        <div class="row">
            <div class="col-lg-3 col-xs-6">
                <!-- small box -->
                <div class="small-box bg-aqua">
                    <div class="inner">
                        <h4><?php echo $users_count;?></h4>
                        <p>Total Users</p>
                    </div>
                    <div class="icon">
                        <i class="ion-ios-people-outline"></i>
                    </div>
                    <a href="#" class="small-box-footer">More info <i class="fa fa-arrow-circle-right"></i></a>
                </div>
            </div>
            <!-- ./col -->
            <div class="col-lg-3 col-xs-6">
                <!-- small box -->
                <div class="small-box bg-green">
                    <div class="inner">
                        <h4><?php echo $online_count;?></h4>

                        <p>Online Users</p>
                    </div>
                    <div class="icon">
                        <i class="ion-ios-people-outline"></i>
                    </div>
                    <a href="#" class="small-box-footer">More info <i class="fa fa-arrow-circle-right"></i></a>
                </div>
            </div>
            <!-- ./col -->
            <div class="col-lg-3 col-xs-6">
                <!-- small box -->
                <div class="small-box bg-purple">
                    <div class="inner">
                        <h4><?php echo $res_count;?></h4>

                        <p>Registered Reseller/s</p>
                    </div>
                    <div class="icon">
                        <i class="ion-ios-people-outline"></i>
                    </div>
                    <a href="#" class="small-box-footer">More info <i class="fa fa fa-arrow-circle-right"></i></a>
                </div>
            </div>
            <!-- ./col -->
            <div class="col-lg-3 col-xs-6">
                <!-- small box -->
                <div class="small-box bg-red">
                    <div class="inner">
                        <h4><?php echo $subad_count;?></h4>

                        <p>Registered Sub-Admin/s</p>
                    </div>
                    <div class="icon">
                        <i class="ion-ios-people-outline"></i>
                    </div>
                    <a href="#" class="small-box-footer">More info <i class="fa fa-arrow-circle-right"></i></a>
                </div>
            </div>
            <!-- ./col -->
        </div>
        <!-- /.row -->
        <!-- /. USER PANEL STATUS -->

 <div class="row">

     <div class="col-md-4">

         <!-- Profile Image -->
         <div class="box box-primary">
             <div class="box-body box-profile">
                 <img class="profile-user-img img-responsive img-circle" src="images/logo.jpg" alt="User profile picture">

                 <?php
                 /*$prof_picture = $db -> select_row("SELECT picture FROM `users` WHERE `user_id`=$get_id");
                 echo
                 '<img src="data:image/jpeg;base64,'.base64_encode($prof_picture[0]['picture'] ).'" class="profile-user-img img-responsive img-circle" />'
                 */
                 ?>


                 <h3 class="profile-username text-center"><?php echo $profile_info['0']['full_name']; ?></h3>
                 <h5 class="text-muted text-center">User Type: <?php echo htmlspecialchars($db -> select("SELECT `user_rank` FROM `users` WHERE `user_id`=".$profile_info[0]['user_id']));?></h5>

                 <ul class="list-group list-group-unbordered">
                     <li class="list-group-item">
                         <b><i class="fa fa-at"></i> Email</b> <a class="pull-right"><?php echo $profile_info[0]['user_email']; ?></a>
                     </li>
                     <li class="list-group-item">
                         <b><i class="fa fa-home"></i> Location</b> <a class="pull-right"><?php echo $profile_info[0]['location']; ?></a>
                     </li>
                     <li class="list-group-item">
                         <b><i class="fa fa-phone"></i> Contact Number</b> <a class="pull-right"><?php echo $profile_info[0]['contact']; ?></a>
                     </li>
                     <li class="list-group-item">
                         <b><i class="fa fa-money"></i> Payment Method</b> <a class="pull-right"><?php echo $profile_info[0]['payment']; ?></a>
                     </li>
                 </ul>

                 <a href="account.php" class="btn btn-primary btn-block"><b>Update Profile</b></a>
                 <a href="#confirmation-form" class="btn btn-warning btn-block" data-toggle="modal" data-target="#confirmation-form"><i class="fa fa-spin fa-refresh"></i>&nbsp; Refresh VPN Connection</a>
             </div>
         </div>
     </div>

        <div class="col-md-8">
            <div class="box box-primary">

                <!-- /.box-header -->
                <div class="box-body table-responsive">
                    <table class="table table-bordered">
                        <tbody><tr>
                            <th>Information</th>
                            <th style="width: 50%">Data</th>
                        </tr>
                        <td><i class="fa fa-credit-card"></i> My Vouchers/Credits</td>
                        <td><?php echo $profile_info[0]['credits'];?></td>
                        </tr>
                        <tr>
                            <td><i class="fa fa-check-square"></i> Premium Status</td>
                            <td>
                                <?php echo $premium_status; ?>
                            </td>
                        </tr>
                        <tr>
                            <td><i class="fa fa-check-square"></i> VIP Status</td>
                            <td>
                                <?php echo $vip_status ?>
                            </td>
                        </tr>
                        <tr>
                            <td><i class="fa fa-check-square"></i> Private Status</td>
                            <td>
                                <?php echo $pri_status ?>
                            </td>
                        </tr>
                        <tr>
                            <td><i class="fa fa-clock-o"></i> Premium Duration</td>
                            <td>
                                <?php echo $premium_duration; ?>
                            </td>
                        </tr>
                        <tr>
                            <td><i class="fa fa-clock-o"></i> VIP Duration</td>
                            <td>
                                <?php echo $vip_duration; ?>
                            </td>
                        </tr>
                        <tr>
                            <td><i class="fa fa-clock-o"></i> Private Duration</td>
                            <td>
                                <?php echo $pri_duration; ?>
                            </td>
                        </tr>
                        <tr>
                            <td><i class="fa fa-check-circle"></i> My VPN Status</td>
                            <td>
                                <?php echo $con_status; ?>
                            </td>
                        </tr>
                        <?php
                        if($current_rank=="Admin" || $current_rank=="Reseller" || $current_rank=="Sub Reseller" || $current_rank=="Sub Admin"){
                        ?>
                        <tr>
                            <td><i class="fa fa-users"></i> Total Clients</td>
                            <td>
                                <?php echo $clients_count; ?>
                            </td>
                        </tr>
                            <tr>
                                <td><i class="fa fa-users"></i> My Resellers</td>
                                <td>
                                    <?php echo $my_resellers; ?>
                                </td>
                            </tr>
                        <tr>
                                <td><i class="fa fa-users"></i> My Sub-Resellers</td>
                                <td>
                                    <?php echo $my_subresellers; ?>
                                </td>
                        </tr>
                        <tr>
                            <td><i class="fa fa-users"></i> Clients Connected</td>
                            <td>
                                <?php echo $active_clients; ?>
                            </td>
                        </tr>
                        <?php } ?>
                        <tr>
                            <td><i class="fa fa-user"></i> Upline</td>
                            <td>
                                <?php echo htmlspecialchars($db -> select("SELECT `full_name` FROM `users` WHERE `user_id`=".$profile_info[0]['upline']));?>
                            </td>
                        </tr>
                        </tbody></table>

                    <br/>

                    <?php

                    $name_info = $db->select_row("SELECT `full_name` FROM `users` WHERE `user_id`=$get_id");
                    $cur_name = $name_info[0]['full_name'];

                    if (($profile_info[0]['duration'])=='259200' || $profile_info[0]['vip_duration']=='259200'){
                    ?>


                            <div class="alert bg-blue alert-dismissible">
                                <button type="button" class="close" data-dismiss="alert" aria-hidden="true">×</button>
                                Greetings! <?php echo $cur_name; ?>
                                You only have <b>3 days left</b> on your account!
                            </div>

                    <!-- /.row -->
                   <?php }?>
                </div>
                <!-- /.box-body -->
            </div>
        </div>
        </div>

        <div class="modal fade" role="dialog" tabindex="-1" id="confirmation-form">
            <div class="modal-dialog">
                <div class="modal-content">
                    <div class="modal-header">
                        <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                            <span aria-hidden="true">&times;</span></button>
                        <h4 class="modal-title">Refresh Account</h4>
                    </div>
                    <div class="modal-body">
                        <p>By clicking Yes this vpn account will be refresh or will be disconnected from our vpn server/s,
                            click Yes to continue or Close to cancel.
                        </p>
                    </div>
                    <div class="modal-footer">
                        <button class="btn btn-default pull-left" data-dismiss="modal">Close</button>
                        <button class="btn btn-primary btn-ok" onclick="<?php $db -> sql_query ("UPDATE users SET is_active=1 WHERE `user_id`=$get_id"); ?>" >Yes</button>
                    </div>
                </div>
                <!-- /.modal-content -->
            </div>
            <!-- /.modal-dialog -->
        </div>


</div>	<!--/.main-->

<?php 
include('components/footer.php');
include("components/js.php");
?>
<div class="control-sidebar-bg"></div>
</div>
</body>
<script>

    $(function(){
        $('#confirmation-form').click(function(e){
            e.preventDefault();
            window.location.reload();
            $('#confirmation-form').modal('hide')
        });
    });

</script>

</html>