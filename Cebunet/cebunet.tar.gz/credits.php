<!DOCTYPE html>

<html>



<?php

include('components/header.php');
include('components/bodytop.php');
?>

<div class="wrapper">
<?php

include('components/nav.php');

include("components/sidebar.php");



if(!isset($_SESSION['user'])){

	header("location: login.php");

}





$get_id=0;

if($_SESSION['user']['rank']=="Admin"){

	if(isset($_GET['user'])){

		$get_id = $db -> escape($_GET['user']);

		if($db -> select("SELECT `user_id` FROM `users` WHERE `user_id`=$get_id") == ""){

			header("location: account.php");

		}else{

			if($db -> select("SELECT `upline` FROM `users` WHERE `user_id`=$get_id") <> $_SESSION['user']['id'] && $current_rank <> "Admin"){

				header("location: account.php");

			}

		}

	}else{

		$get_id = $current_uid;

	}

}elseif($_SESSION['user']['rank']=="Reseller"){

	if(isset($_GET['user'])){

		$get_id = $db -> escape($_GET['user']);

		if($db -> select("SELECT `user_id` FROM `users` WHERE `user_id`=$get_id") == ""){

			header("location: account.php");

		}else{

			if($db -> select("SELECT `upline` FROM `users` WHERE `user_id`=$get_id") <> $_SESSION['user']['id']){

				header("location: account.php");

			}

		}

	}else{

		$get_id = $current_uid;

	}

	}elseif($_SESSION['user']['rank']=="Sub Admin"){

	if(isset($_GET['user'])){

		$get_id = $db -> escape($_GET['user']);

		if($db -> select("SELECT `user_id` FROM `users` WHERE `user_id`=$get_id") == ""){

			header("location: account.php");

		}else{

			if($db -> select("SELECT `upline` FROM `users` WHERE `user_id`=$get_id") <> $_SESSION['user']['id'] && $current_rank <> "Sub Admin"){

				header("location: account.php");

			}

		}

	}else{

		$get_id = $current_uid;

	}

}else{

	header("location: account.php");

}

$profile_info = $db -> select_row("SELECT * FROM `users` WHERE `user_id`=$get_id");



?>	

	

	<div class="content-wrapper">

        <section class="content-header">
            <h1>
                Credits
                <small>Credits Management</small>
            </h1>
            <ol class="breadcrumb">
                <li><a href="profile.php"><i class="fa fa-dashboard"></i> Home</a></li>
                <li class="active">Credits</li>
            </ol>
        </section>


		<br>

     <div class="content">
		<div class="row">

			<div class="col-lg-12">

				<div class="box">

					<div class="box-header">Credits Management Form</div>

					<div class="box-body">

							<div class="col-md-6">

								<div class="form-group">

									<label>Full Name</label>

									<input class="form-control" placeholder="Enter Full Name" name="full_name" value="<?php echo htmlspecialchars($profile_info[0]['full_name']);?>" readonly>

								</div>

								

								<div class="form-group">

									<label>Email</label>

									<input class="form-control" type="email" name="email" placeholder="email@example.com" value="<?php echo htmlspecialchars($profile_info[0]['user_email']);?>" readonly>

								</div>

								<div class="form-group">

									<label>Location</label>

									<input class="form-control" placeholder="Enter Location" name="location" value="<?php echo htmlspecialchars($profile_info[0]['location']);?>" readonly>

								</div>

								<div class="form-group">

									<label>Mode of Payment (Reseller)</label>

									<input class="form-control" placeholder="For Resellers" name="payment" value="<?php echo htmlspecialchars($profile_info[0]['payment']);?>" readonly>

								</div>

								<div class="form-group">

									<label>Contact Info</label>

									<input class="form-control" placeholder="Contact Info" name="contact" value="<?php echo htmlspecialchars($profile_info[0]['contact']);?>" readonly>

								</div>

								<!--button type="submit" class="btn btn-primary">Update Profile</button-->

							</div>

							<div class="col-md-6">

								<form id="credits_form" role="form">

									<input type="hidden" name="user_id" value="<?php echo $get_id;?>" >

									<div class="form-group">

										<label>Current Credits</label>

										<input type="number" id="current_credits" class="form-control" value="<?php echo htmlspecialchars($profile_info[0]['credits']);?>" readonly>

									</div>

									<div class="form-group">

										<label>Add Credits (Set negative value to remove credits)</label>

										<input id="credits" class="form-control" name="credits" type="number" placeholder="Amount" required>

									

									</div>

									<button type="submit" class="btn btn-primary">Submit</button>

									<br /><br />

									<div class="callout callout-info" role="alert" id="error-alert" style="display:none;">

										<span class="fa fa-exclamation-circle"></span><span id="alert-message"> </span></a>

									</div>

								</form>	

							</div>

					</div>

				</div>

			</div><!-- /.col-->

		</div><!-- /.row -->

		

		
     </div> <!--/.class-content-close-->
		

	</div>	<!--/.main-->



<?php 

include("components/js.php");

?>

<script>

$("#credits_form").submit(function(event){

	event.preventDefault();

	remove_alert_bg();

	$('#error-alert').addClass("bg-primary");

	$('#error-alert').fadeIn();

	$('#alert-message').text(" Please wait...");

		$.ajax({

			url: "app/credits/add_credits.php", data: $('#credits_form').serialize(), type: "POST",  dataType: 'json',

			success: function (result) {

						console.log(result.status + " " + result.message);

						if (result.status!=1) { 

							remove_alert_bg();

							$('#error-alert').addClass("callout-danger");

							$('#alert-message').text(result.message);

							setTimeout(function () { $('#error-alert').fadeOut()}, 3000);

						}else{

							remove_alert_bg();

							$('#error-alert').addClass("callout-success");

							$('#alert-message').text(result.message);

							$('#current_credits').val(parseInt($('#current_credits').val())+parseInt($('#credits').val()));

							//setTimeout(function () { window.location.assign("index.php");}, 1000);

							setTimeout(function () { $('#error-alert').fadeOut()}, 3000);

						}

					}

		});

		

	console.log('clicked');

});



function remove_alert_bg(){

	$('#error-alert').removeClass("callout-success");

	$('#error-alert').removeClass("callout-primary");

	$('#error-alert').removeClass("callout-danger");

}	

</script>

<?php
include('components/footer.php');
?>
<div class="control-sidebar-bg"></div>
</div>

</body>



</html>

