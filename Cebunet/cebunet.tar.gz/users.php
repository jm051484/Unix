<!DOCTYPE html>
<html>

<?php
include('components/header.php');
include('components/bodytop.php');
?>

<div class="wrapper">
<?php
include('components/nav.php');
include("components/sidebar.php");

$delete_message="";
$get_type="";
if(isset($_GET['user'])){
	switch($db -> escape($_GET['user'])){
		case "sub":
			$get_type="?user=sub";
			break;
		case "reseller":
			$get_type="?user=reseller";
			break;
		case "subadmin":
			$get_type="?user=subadmin";
			break;
		case "client":
			if($current_rank=="Reseller" || $current_rank=="Admin" || $current_rank=="Sub Reseller" || $current_rank=="Sub Admin" ){
			}else {
                header("location: users.php?user=reseller");
            }
			$get_type="?user=client";
			break;
		case "all":
			if($current_rank<>"Admin"){
				header("location: users.php?user=reseller");
			}
			break;
		default:
			header("location: users.php?user=reseller");
			break;
	}

	if(isset($_GET['delete'])){
		if($_GET['id']<>1){
			if($_GET['delete']==0){
				if( $db -> select("SELECT `upline` FROM `users` WHERE `user_id`=".$db -> escape($_GET['id'])) == $_SESSION['user']['id'] || $_SESSION['user']['rank']=="Admin"){
					$db -> sql_query("DELETE FROM `users` WHERE `user_id`=".$db -> escape($_GET['id']));
					if(isset($_GET['users'])){
						header("location: users.php?user=".$db -> escape($_GET['user'])."&delete=1");
					}else{
						header("location: users.php?delete=1");
					$delete_message="alert('Unauthorized Action.');";
					}
					
				}else{
				}
			}elseif($_GET['delete']==1){
				$delete_message="alert('User Deleted!');";
			}
		}else{
			$delete_message="alert('Action Denied!');";
		}
	}
}else{
	if($current_rank<>"Admin"){
		header("location: users.php?user=reseller");
	}else{
		if(isset($_GET['delete'])){
			if($_GET['delete']==1){
				$delete_message="alert('User Account Successfully Deleted!');";
			}
		}
	}
}
?>

    <div class="content-wrapper">
        
            <section class="content-header">
                <h1>
                    Account
                    <small>Update / Edit Profile</small>
                </h1>
                <ol class="breadcrumb">
                    <li><a href="#"><i class="fa fa-dashboard"></i> Home</a></li>
                    <li class="active">Account</li>
                </ol>
            </section>
            
            <div class="content">

            <?php
		$users = "";
		if(isset($_GET['user'])){
			if($_GET['user']=="reseller"){
				$users="Reseller ";
			}elseif($_GET['user']=="client"){
				$users="Client ";
			}elseif($_GET['user']=="sub"){
				$users="Sub Reseller ";
			}elseif($_GET['user']=="subadmin"){
				$users="Sub Admin ";
			} else {
				$users="All ";
			}
		} else {
			$users="All ";
		}
		?>
        <br>
        
        <?php 
        $active_count = $db -> select("SELECT COUNT(is_active) AS 'Active Users' FROM users WHERE is_active=0");
        
        $offline_count = $db -> select("SELECT COUNT(is_active) AS 'Active Users' FROM users WHERE is_active=1");
        
        $act_count = $db -> select("SELECT COUNT(is_validated) AS 'All Users' FROM users WHERE is_validated=1");
        
        $res_count = $db -> select("SELECT COUNT(is_reseller) AS 'Active Reseller' FROM users WHERE is_reseller=1");
        
        $subr_count = $db -> select("SELECT COUNT(is_reseller) AS 'Active SubRes' FROM users WHERE is_reseller=2");
        
        $suba_count = $db -> select("SELECT COUNT(is_reseller) AS 'Active SubAdmin' FROM users WHERE is_reseller=3");
        
        
        
        ?>
        
        <!-- USER PANEL STATUS -->
        
        <div class="row">
            <div class="col-lg-2 col-xs-4">
                <!-- small box -->
                <div class="small-box bg-green">
                    <div class="inner">
                        <h4><?php echo $active_count;?></h4>

                        <p>Online Users</p>
                    </div>
                </div>
            </div>
            <!-- ./col -->

            <div class="col-lg-2 col-xs-4">
                <!-- small box -->
                <div class="small-box bg-green">
                    <div class="inner">
                        <h4><?php echo $act_count;?></h4>

                        <p>All Users</p>
                    </div>
                </div>
            </div>
            <!-- ./col -->
            <div class="col-lg-2 col-xs-4">
                <!-- small box -->
                <div class="small-box bg-red">
                    <div class="inner">
                        <h4><?php echo $res_count; ?></h4>

                        <p>Reseller/s</p>
                    </div>
                </div>
            </div>
            <!-- ./col -->
            <div class="col-lg-2 col-xs-4">
                <!-- small box -->
                <div class="small-box bg-red">
                    <div class="inner">
                        <h4><?php echo $suba_count;?></h4>

                        <p>Sub Admin</p>
                    </div>
                </div>
            </div>
            <!-- ./col -->
            <div class="col-lg-2 col-xs-4">
                <!-- small box -->
                <div class="small-box bg-blue">
                    <div class="inner">
                        <h4><?php echo $subr_count;?></h4>

                        <p>Sub Reseller</p>
                    </div>
                </div>
            </div>
            <!-- ./col -->
            <div class="col-lg-2 col-xs-4">
                <!-- small box -->
                <div class="small-box bg-blue">
                    <div class="inner">
                        <h4><?php echo $offline_count;?></h4>

                        <p>Offline Users</p>
                    </div>
                </div>
            </div>
            <!-- ./col -->
        </div>
        <!-- /.row -->
        <!-- /. USER PANEL STATUS -->

		<div class="row">
			<div class="col-xs-12">
				<div class="box box-primary">
                    <div class="box-header">Users List / <?php echo $users;?></div>
					<div class="box-body table-responsive">
						<table class="table table-bordered table-hover dataTable-responsive" role="grid" data-toggle="table" data-url="app/users/list.php<?php echo $get_type;?>"  data-show-refresh="true" data-show-toggle="true" data-show-columns="true" data-search="true" data-select-item-name="toolbar1" data-pagination="true" data-sort-name="name" data-sort-order="desc">
						    <thead>
						    <tr>
						        <!--th data-field="state" data-checkbox="true" >Item ID</th-->
						        <th data-field="user_name" data-sortable="true">Username</th>
						        <th data-field="full_name"  data-sortable="true">Name</th>
						        <th data-field="type" data-sortable="true">User Type</th>
						        <th data-field="subscription" data-sortable="true">Subscription</th>

						        <?php if(isset($_GET['user'])){
									if($_GET['user']=="reseller" || $_GET['user']=="sub" || $_GET['user']=="SubAdmin"){
								?>
								<th data-field="credits" data-sortable="true">Credits</th>
								<?php }else{
								if($_SESSION['user']['rank']=="Admin"){
								?>
									<th data-field="dur" data-sortable="true">Premium Duration</th>
                                    <th data-field="vipdur" data-sortable="true">VIP Duration</th>
								<?php }} }else{
								?>
									<th data-field="dur" data-sortable="true">Premium Duration</th>
                                    <th data-field="vipdur" data-sortable="true">VIP Duration</th>
								<?php }?>
								<th data-field="stats" data-sortable="true">VPN Status</th>
						        <th data-field="action" data-sortable="true">Action</th>
						    </tr>
						    </thead>
						</table>
					</div>
				</div>
			</div>
		</div><!--/.row-->	
        </div>
	</div>	<!--/.main-->

<?php 
include("components/js.php");
?>

	<script src="js/bootstrap-table.js"></script>

<?php
include('components/footer.php');
?>
<div class="control-sidebar-bg"></div>
</div>

<div class="modal fade" role="dialog" tabindex="-1" id="showinfo" aria-labelledby="showinfo" aria-hidden="true">
    <div class="modal-dialog">
        <div class="modal-content">
            <div class="modal-header">
                <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                    <span aria-hidden="true">&times;</span></button>
                <h4 class="modal-title">Trial Generator</h4>
            </div>
            <div class="modal-body">
                <data>
                </data>
            </div>
            <div class="modal-footer">
                <button class="btn btn-primary generate-trial">Generate Trial</button>
                <button class="btn btn-warning" data-dismiss="modal">Close</button>
            </div>
        </div>
        <!-- /.modal-content -->
    </div>
    <!-- /.modal-dialog -->
</div>

</body>

<script>
function view_profile(id){
	window.location="profile.php?user="+id;
}

function edit_user(id){
	window.location="account.php?user="+id;
}


function credit_user(id){
	window.location="credits.php?user="+id;
}

function monitor_user(id){
	window.location="clients.php?id="+id;
}

function delete_user(id){
	var r = confirm('Are you sure you want to delete this User?');
	if (r == true) { 
		window.location="users.php?user=client&id="+id+"&delete=0";
	}
}


$('.generate-trial').click(
    function(){
        $.ajax({
            type: 'GET',
            url: 'generate-trial.php',
            dataType: 'json',
            success: function (data) {
                $.each(data, function (i, data) {
                    if(i === "alert") {
                        $("data").append(data);
                    }
                    if(i === "username"){
                        $("data").append("<p>Username: <strong>" + data + "</strong></p>");
                    }
                    if (i === "password") {
                        $("data").append("<p>Password: <strong>" + data + "</strong></p>");
                    }
                    if (i === "duration") {
                        $("data").append("<p>Duration: <strong>" + data + "</strong></p>");
                    }
                });

            }})
        $('.generate-trial').attr('disabled', true);
    });

setTimeout(function () { <?php echo $delete_message;?>}, 1000);
</script>
</html>