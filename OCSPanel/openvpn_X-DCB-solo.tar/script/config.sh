#!/bin/bash
##Dababase Server
HOST='2.2.2.2'
#Default port = 3306
PORT='3306'
#Username
USER='root'
#Password
PASS='onethree'
#database name
DB='openvpn'
