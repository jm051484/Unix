<?php  require "stats.php";?>
<!DOCTYPE html>
<html>
<head>
<title>X-DCB (Monitoring)</title>
  <link rel="stylesheet" type="text/css" href="styles.css">
  <meta name="viewport" content="width=device-width">
</head>
<body>
  <h2>OPENVPN SERVER STATISTICS</h2>
  <table>
    <tr>
      <th>User ID</th>
      <th>Sent</th>
      <th>Received</th>
    </tr>
    <tr>
    </tr>
      <?php load_table_stats(); ?>
  </table><br>
  <div><?php show_stats();?></div>
</body>
</html>