#!/bin/bash
# Script restart service dropbear, webmin, squid3, openvpn, openssh
systemctl restart {dropbear,ssh,openvpn@465}
docker container restart squidX