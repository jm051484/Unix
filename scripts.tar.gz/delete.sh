#!/bin/bash
#Script to remove SSH & OpenVPN users
users=($@)
if [ "${#users[@]}" = 0 ]; then
 echo "Another way: $0 user1 user2 user3 ... userN";
 read -p "User/s: " users; fi
for user in $users; do
	echo "Removing user: $user"
	if getent passwd $user > /dev/null 2>&1; then
        userdel $user
        echo -e "User $user was removed."
     else
        echo -e "FAILED: there is no such user, $user."; fi
done