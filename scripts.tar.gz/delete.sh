#!/bin/bash
#Script to remove SSH & OpenVPN users
users=($@)
if [ "${#array[@]}" = 0 ]; then
 echo "Usage: echo.sh echo1 echo2 echo3 ... echoN"; exit 1; fi
for user in $users; do
	echo "Removing user: $user"
	if getent passwd $Users > /dev/null 2>&1; then
        userdel $Users
        echo -e "User $Users was removed."
     else
        echo -e "FAILED: there is no User $Users ."
done