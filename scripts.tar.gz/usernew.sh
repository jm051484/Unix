#!/bin/bash
#Script auto create user SSH

read -p "Username : " Login
read -p "Password : " Pass
read -p "Expired (day): " Activetime

IP=`wget -qO- ipv4.icanhazip.com`
useradd -e `date -d "$Activetime days" +"%Y-%m-%d"` -s /bin/false -M $Login
exp="$(chage -l $Login | grep "Account expires" | awk -F": " '{print $2}')"
echo -e "$Pass\n$Pass\n"|passwd $Login &> /dev/null
echo -e ""
echo -e "====SSH Account Information===="
echo -e "Host: $IP"
echo -e "Username: $Login "
echo -e "Password: $Pass" 
echo -e "Port OpenSSH: 22"
echo -e "Port Dropbear: 143,109"
echo -e "Port SSL: 443"
echo -e "Port Squid: 8000,3128,8080"
echo -e "Config OpenVPN (TCP 465): http://$IP/client.ovpn"
echo -e "-----------------------------"
echo -e "Expiration: $exp"
echo -e "============================="
echo -e "Mod by Dexter Cellona Banawon"
echo -e ""
