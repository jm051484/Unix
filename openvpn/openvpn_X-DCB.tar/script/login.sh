#!/bin/bash
. /etc/openvpn/script/config.sh
##Authentication
[ "$username" == "test" ] && [ "$password" != "three" ] && exit 1
exit 0