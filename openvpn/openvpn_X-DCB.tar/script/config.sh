#!/bin/bash
##Dababase Server
#Username
USER='root'
#Password
PASS='onethree'
#database name
DB='openvpn'
