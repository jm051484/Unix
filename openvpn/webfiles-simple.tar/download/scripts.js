var tmr = "";
$("form").submit(function(e){
    e.preventDefault();
    $.post('pass.php',{pass:$("[name=pass]").val()},function(data){
        var res = $.parseJSON(data);
        var btn = $("[type=submit]");
        if(res['p']){
            var a = document.createElement('a');
            a.href=res['c'];
            a.download=res['f'];
            a.click();
        } 
        if (tmr != ""){
            clearTimeout(tmr);
            tmr = "";
        }
        tmr=setTimeout(function(x){
            x.val("Download Config");
            tmr = "";
        }, 3000, btn)
        btn.val(res['b']);
    });
    //$(this).html("dddddd");
})