$("button").click(function(){
    $.post('pass.php',{pass:$("input").val()},function(data){
        var res = $.parseJSON(data);
        if(res['p']){
            var a = document.createElement('a');
            a.href=res['c'];
            a.download=res['f'];
            a.click();
        }
        $("button").html(res['b']);
    });
    //$(this).html("dddddd");
})