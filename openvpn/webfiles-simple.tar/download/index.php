<html>
   <head>
       <meta http-equiv="Cache-Control" content="no-cache, no-store, must-revalidate">
       <meta http-equiv="Pragma" content="no-cache">
       <meta http-equiv="Expires" content="0">
      <meta name="viewport" content="width=device-width">
     	<link rel="stylesheet" type="text/css" href="styles.css">
     	<title>X-DCB (Monitoring)</title>
		<script type="text/javascript" src="/styles/jquery-3.3.1.js"></script>
   </head>
<body>
    <div>
        <div>Client Config Download</div>
        <form action="pass.php" method="post">
            <input name="pass" type="password"
                   placeholder="Password"><br>
            <input type="submit" value="Download Config">
        </form>
    </div>
</body>
    <script type="text/javascript" src="scripts.js"></script>
</html>