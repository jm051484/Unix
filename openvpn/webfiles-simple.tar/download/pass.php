<?php
    require_once '../vars/var_manip.php';
    $locz = (PHP_OS == "Linux" ? 
    "/etc/openvpn/script" : "../vars");
    $cpass = get_varx("$locz/config.sh");
    if($_POST['pass'] == $cpass['CPASS'] && $_SERVER['REQUEST_METHOD'] == 'POST'){
        $client = preg_replace(
            "/xxxx/",
            $_SERVER['SERVER_ADDR'],
            file_get_contents("$locz/client.ovpn"));
        echo json_encode([
            'p'=>true,
            'b'=>"Downloading...",
            'c'=>"data:application/octet-stream;base64,". base64_encode($client)]);
    } else {
        echo json_encode([
            'p'=>false,
            'b'=>"Wrong password."]);
    }
?>