<?php
   require_once '../vars/var_manip.php';
   $locz = (PHP_OS == "Linux" ? 
   "/etc/openvpn/script" : "../vars");
   $cpass = get_varx("$locz/config.sh");
   if($_POST['pass'] == $cpass['CPASS'] && $_SERVER['REQUEST_METHOD'] == 'POST'){
      if (preg_match("/(\d{2,3}(.)){4,4}/", $_SERVER['HTTP_HOST'], $ipxx) == 1){
         $ipx = "client-".explode('.', $ipxx[0])[3];
      } else $ipx = $_SERVER['HTTP_HOST'];
      $client = preg_replace(
         "/xxxx/",
         $ipx,
         file_get_contents("$locz/client.ovpn"));
      echo json_encode([
         'p'=>true,
         'b'=>"Downloading...",
         'f'=>"$ipx.ovpn",
         'c'=>"data:application/octet-stream;base64,". base64_encode($client)]);
   } else {
      echo json_encode([
         'p'=>false,
         'b'=>"Wrong password."]);
   }
?>