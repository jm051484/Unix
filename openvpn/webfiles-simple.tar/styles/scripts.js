// SCRIPT LOADING
$.getScript('/styles/script.js');
// ANIMATION CONTROL
var main = $("#blue"),
		texx = $("#txt"),
		hdr = $("#tbox ,#tbox *"),
		cnt = $("#contents"),
		maxw = parseInt(main.css("max-width")),
		maxt = parseInt(texx.css("max-width")),
		maxx = $(window).width(),
		minxy = 10,
		leftmax = (maxx/2) - (maxw/2),
		leftmaxt = (maxx/2) - (maxt/2),
		minf = 22,
		topmax = parseInt($("#max").css("top")),
		texc = $("#creator");

$(window).scroll(function() {
	var srl = $(window).scrollTop();
	var rato = ratio(srl,maxw,0,100);
	var nrat = 100;
	var rat = ratio(srl,maxw,80);
	var rt = ratio(srl,maxw,50);
	main.css({
		"width" : maxw * rato, 
		"height" : maxw * rato,
		"left" : nval(leftmax * rato, minxy),
		"top" : nval(100 * rato, minxy)
	});
	//main.text(rato);
	texx.css({
		"font-size" : nval(35 * rato, minf),
		"top" : nval(450 * rato, 10),
		"left" : nval(leftmaxt * rato, 55 * (1-rato)),
		"width" : maxx * rato
	});
	texc.css({
		"top" : nval(430 * rato, 32),
		"left" : nval(leftmaxt * rato, 55 * (1-rato)),
		"width" : maxx * rato
	});
	hdr.css({
		"opacity" : rat == 0 ? 1 : 1-rat
	});
	cnt.css({
		"opacity" : rato == 0 ? 1 : 1-rato
	});
})

function ratio(delta, max, sub = 0, subx = 0){
	var newr = 1-(delta - sub < max - subx ? (delta - sub)/(max - subx) : 1);
	return newr < 1 ? newr : 1;
}
function nval(cval, minval, extra = 0,gmax = 0){
	return cval > minval + extra ? cval : (gmax == 1 ? 0 : minval + extra);
}
// PHP DATA PROCESSING
function php_ajax(file, desc, datax) {
	var fdata = new FormData();
	fdata.append(desc, datax);
	return $.ajax({
		url: '/styles/' + file,
		data: fdata,
		type: 'POST',
		dataType: 'text',
		contentType : false,
		cache : false,
		processData : false,
		async: false
	}).responseText
}
$("form").submit(function(e) {
    e.preventDefault();
    var targ = $("tr:nth-child(4) input");
    targ.attr("disabled", "true");
    targ.css({"border" : "1px solid black", "background-color" : "transparent", "color" : "black"});
    targ.val('Please wait...');
    //alert(targ.parent().html());
})
$("#foot a").on("click",function(){
    alert('gg');
})