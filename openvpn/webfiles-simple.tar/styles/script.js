
// DENY SPECIAL CHARACTERS ON KEYPRESS
var banner = $("#banner"),
		av = $("#avatar *"),
		imgc = $("#av"),
		imgg = $("#avatar img");
var regex = new RegExp("^[a-zA-Z0-9]+$|\r");
$("input").on('invalid', function(event) {
	var 	vald = this.validity
			minl = $(this).attr('minlength')
			ibox = $(this).attr('placeholder') ;
	var msg = 	vald.patternMismatch ? " - ALPHANUMERICS ONLY" : 
					vald.valueMissing ? " is required." : 
					vald.tooShort ? " must have " + minl + " or more charachters." : 
					'';
	banner.text(ibox + msg);
	banner.css({"display" : "inline-table"});
	var tm = '';
	clearTimeout(tm);
	tm = setTimeout(function() { banner.css({"display" : "none"}); },3200);
	event.preventDefault();
});
// IMAGE CHANGING
av.on('click', function() {
	imgc.click();
});
$("#av").change(function() {
	var file = this.files[0];
	if(file.name != '') {
		php_ajax('upload.php','u_file', file);
		change_img();
	}
});
$(function() {
	//= $("script")[0].src.substr(0, $("script")[0].src.lastIndexOf('/') + 1);
	
	//alert(php_ajax('image.php'));
	change_img();
})
function change_img() {
    var ssrc = "url('/styles" + php_ajax('image.php') + "')";
	imgg.css({"background-image" : ssrc });
    $("#blue").css({"background-image" : ssrc});
	//alert(php_ajax('image.php'));
}
$("*").on('contextmenu', function(event) {
	event.preventDefault();
	return false;
})
$("input").tooltip('hide');