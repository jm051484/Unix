<?php
	if($_SERVER['REQUEST_METHOD'] == 'POST')
	{
		$file = @file_get_contents('imgsource.txt');
		echo $file != '' ? $file : "icon.png";
	}
?>