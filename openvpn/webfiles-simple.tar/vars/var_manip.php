<?php
	function get_varx($loc,$rvar='') {
		$varx = preg_split("/\n/", file_get_contents($loc));
		$arrx = [];
		foreach ($varx as $vr) {
			$pre = preg_replace("/^set\s/i", "", $vr);
			$getvals = preg_split("/=/",$pre);
			$f_varx = preg_replace("/\s/", "", $getvals[0]);
			if(preg_match("/\w(=)/", $vr) && preg_match("/^$f_varx/", $pre)) {
				$arrx += ["$f_varx" => preg_replace("/\s$|\'/", "", $getvals[1])];
			}
		}
		return $arrx;//'<br>count : ' . count($arrx) . var_dump($arrx);
	}
	function cha_varx($loc,$rvar,$tvar) {
		$varx = preg_split("/\n/", file_get_contents($loc));
		foreach ($varx as $vr) {
			$pre = preg_replace("/^set/i", "", $vr);
			$getvals = preg_split("/=/",$pre);
			if(preg_match("/^$rvar\z/i", $getvals[0])){
				$f_var = "$rvar=$getvals[1]";
				$c_vars = preg_replace("/^$vr/i", "$rvar=$tvar", file_get_contents($loc));
				file_put_contents($loc, $c_vars);
			}
		}
	}
?>
