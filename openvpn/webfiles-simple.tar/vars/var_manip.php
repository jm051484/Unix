<?php
	function get_varx($loc,$rvar='') {
		$varx = preg_split("/\n/", file_get_contents($loc));
		$arrx = [];
		foreach ($varx as $vr) {
			$pre = preg_replace("/^set\s/i", "", $vr);
			$getvals = preg_split("/=/",$pre);
			$f_varx = preg_replace("/\s/", "", $getvals[0]);
			if(preg_match("/\w(=)/", $vr) && preg_match("/^$f_varx/", $pre)) {
				$arrx += ["$f_varx" => preg_replace("/\s$|\'/", "", $getvals[1])];
			}
		}
		return $arrx;//'<br>count : ' . count($arrx) . 
        //var_dump($arrx);
	}
    function chvar($file,array $arrx){
        $cont = file_get_contents($file);$arx = [];$fnl='';
        $xa = preg_split("/\n/",$cont);
        foreach($arrx as $aa){
            $kk = key($arrx);$$kk = $aa;$fnl='';
            foreach($xa as $r){
                $fnl .= preg_replace("/^$kk.*/","$kk=$aa",$r) . "\n";
            }
            $xa = preg_split("/\n/",$fnl);
            next($arrx);
        } file_put_contents($file,preg_replace("/\n{3,}/","\n",$fnl));
    }
?>
