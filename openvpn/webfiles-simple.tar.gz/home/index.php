<html>
   <head>
       <meta http-equiv="Cache-Control" content="no-cache, no-store, must-revalidate">
       <meta http-equiv="Pragma" content="no-cache">
       <meta http-equiv="Expires" content="0">
      <meta name="viewport" content="width=device-width">
     	<link rel="stylesheet" type="text/css" href="/styles/styles.css">
     	<title>X-DCB (Monitoring)</title>
		<script type="text/javascript" src="/styles/jquery-3.3.1.js"></script>
   </head>
   <body>
		<div id="blue">BACKGROUND</div>
		<div id="contents">
			<table align="center">
				<caption>OPENVPN SERVER STATISTICS</caption>
				<tr>
					<th id="numx">#</th>
					<th id="usr">User ID</th>
					<th>Sent</th>
					<th>Received</th>
				</tr>
			</table>
			<div id="foot">
                Usage/<a href="/download/">Connect</a>ions : 
                <span id="stx"></span>
            </div>
		</div>
		<div id="tbox"></div>
		<span id="txt">Dexter Cellona Banawon</span>
		<span id="creator">CREATOR</span>
  	</body>
   <script type="text/javascript" src="/styles/scripts.js"></script>
</html>