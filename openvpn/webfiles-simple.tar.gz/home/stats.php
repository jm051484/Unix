<?php
  require_once "../vars/var_manip.php";
  $locz = (PHP_OS == "Linux" ? 
  "/etc/openvpn/script" : "../vars");
  $CONF = get_varx("$locz/config.sh");
  mysql_connect($CONF['HOST'],$CONF['USER'],$CONF['PASS']) or die(mysql_error());
	mysql_select_db($CONF['DB']) or die("Cannot connect to the database.");
  function show_records(){
      $query = mysql_fetch_array(mysql_query(
        "
          select 
            sum(log_send <> 0) as conns,
            sum(log_send) as received
            from log"));
      $query['conns'] = $query['conns'] == '' ? "0" : $query['conns'];
      return $query;
  }
  function show_stats(){
      // BTYES RECEIVED
      return get_byte_text("", show_records()['received']).
      // CONNECTIONS
      "/" . show_records()['conns'];
  }
  function load_table_stats(){
       global $CONF;
      $queryx = mysql_query(
        "
          select distinct
            user_id as id
            from log");
      $cc = 1; $resx = ["owner"=>$CONF['OWNER'],"Users"=>0,"srv_stat"=>show_stats(),"all_stat"=>[]];
      while ($hh = mysql_fetch_array($queryx)) {
            $stat = get_user_stats($hh['id']);
            array_push($resx["all_stat"], [
                'num' => $cc++,
                'name' => $hh['id'],
                'n_stat' => ($stat['o'] ? "(on)" : "(off)"),
                'sent' => get_byte_text('',$stat['s']),
                'recv' => get_byte_text('', $stat['r'])
            ]);
      }
      $resx["Users"] = count($resx["all_stat"]);
      return json_encode($resx);
  }
  function get_user_stats($id){
    $bytes_r = mysql_fetch_array(mysql_query(
              "select
              sum(log_received) as received,
              sum(log_send) as sent
              from log where user_id='". $id . "'"));
	$active = mysql_fetch_array(mysql_query(
	"select user_online as o from user where user_id='". $id . "'"))['o'];
    return array('s' => $bytes_r['received'], 'r' => $bytes_r['sent'],'o' => $active);
  }
  // FUNCTIONS
  function write($txt){
    print($txt . "<br>");
  }
  function get_byte_text($txt='',$bytes){
    $arrt = array(0,1,2,3,4);
    $arrg = array("B","KB","MB","GB","TB");
    foreach ($arrt as $gg) {
      if(round($bytes/pow(1024, $gg),2) < 1024)
        {
          return $txt . round($bytes/pow(1024, $gg),2) . " " . $arrg[$gg];
        }
      }
    }
http_response_code(200);
echo load_table_stats();
header("Server: X-DCB");
header("Content-Type: application/json; charset=utf-8");
header("Content-Length:". strlen(load_table_stats()));
header('Access-Control-Allow-Origin: *');
?>